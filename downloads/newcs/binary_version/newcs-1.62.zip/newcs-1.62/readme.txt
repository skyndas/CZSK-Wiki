--- ------- ---  -- - - -
 NewCS readme
- -- ---  -- - - -

We have no politics.. this is just for fun - blame yourself..

 "How should I know if it works? That's what beta testers are for. I only coded it."
  -Linus Torvalds


--- Index ------- ---  -- - - -

1.  Chameleon v2 - the newcs P2P
2.  File Descriptions
3.  Runtime Arguments
4.  Configfile
5.  TCP-Commands
6.  FAQ
7.  Changelog
8.  Troubleshooting
9.  Special Notes
10. Known Bugs
11. Greets


1.-- Chameleon v2 - the newcs P2P ------- ---  -- - - -

Chameleon has been completely rewritten.
We now use our own encryption algorithm, instead of ssl. It seemed that the embedded libraries meant for small devices, just arent
stable enough for our use. With this change we removed 90% of the segfaults in newcs.

Chameleon and Chameleon2 is *NOT* compatible, config section has changed to <chameleon2> to reflect that.

The principles is *almost* the same as in Chameleon v1. We no longer have distributed card lists though, a client has to scan the net
for a given caid/provider. ATM. _only_ mgcamd works with chameleon, you have to set <cardlevel>1</cardlevel> in the newcamd user, and it
will get a bunch of virtual cards that it can use. (the autoscan and more dynamic way of doing this is beeing worked on).

This is still a work in progress :o)
We will be happy for any feedback :)

2.-- File Descriptions ------- ---  -- - - -

newcs.ppc			->	NewCS binary for dreambox, tripledragon and other powerpc machines.
newcs.ppc.pcsc			->	NewCS with support for the PC/SC for powerpc machines.
newcs.ppc.usb			->	NewCS with support for the Infinity-USB programmer for powerpc machines.
newcs.mips			->	NewCS binary for the 7025 dreambox.
newcs.mips.pcsc			->	NewCS binary with support for PC/SC for the 7025 dreambox.
newcs.mips.usb			->	NewCS binary with support for the Infinity-USB programmer for the 7025 dreambox.
newcs.i686			->	32bit NewCS binary for linux on Intel compatible machines.
newcs.i686.pcsc			->	32bit NewCS binary for linux on Intel compatible machines, with PC/SC support.
newcs.i686.usb			->	32bit NewCS binary with support for the Infinity-USB programmer for Intel compatible machines.
newcs.x86_64			->	64bit NewCS binary for linux on AMD64.
newcs.x86_64.pcsc		->	64bit NewCS binary for linux on AMD64, with PC/SC support.
newcs.x86_64.usb		->	64bit NewCS with support for the Infinity-USB programmer on AMD64.
newcs.openwrt			->	NewCS binary for OpenWRT-kamikaze (this only support phoenix as type)
newcs.openwrt.pcsc		->	NewCS binary with support for PC/SC for OpenWRT-kamikaze. (this only support phoenix and pcsc as type)
newcs.openwrt.usb		->	NewCS binary with support for the Infinity-USB programmer for OpenWRT-kamikaze. (this only support phoenix and infinity as type)
newcs.nslu2   			->	NewCS binary for NSLU2. (this only support phoenix as type)
newcs.nslu2.pcsc   		->	NewCS binary with support for PC/SC for NSLU2. (this only support phoenix and pcsc as type)
newcs.nslu2.usb   		->	NewCS binary with support for the Infinity-USB programmer for NSLU2. (this only support phoenix and infinity as type)
newcs.exe			->	NewCS binary for 2K/XP/2003/Vista. (this only support pcsc, phoenix and sc8 as type)
newcs.cris			->	NewCS binary for the Axis Etrax 100LX.
newcs.cris.pcsc			->	NewCS binary with support for PC/SC for the Axis Etrax 100LX.
newcs.cris.usb			->	NewCS binary with support for the Infinity-USB programmer for the Axis Etrax 100LX.
newcs.st40			->	NewCS binary for the Kathrein box..
newcs.st40.pcsc			->	NewCS binary with support for PC/SC for the Kathrein.
newcs.st40.usb			->	NewCS binary with support for the Infinity-USB programmer for the Kathrein.
newcs.qnap			->	NewCS binary with support for the QNAP NAS.
newcs.qnap.usb			->	NewCS binary with support for the Infinity-USB programmer for the QNAP NAS.
newcs.qnap.pcsc			->	NewCS binary with support for the PC/SC for the QNAP NAS.
newcs.freetz			->	NewCS binary with support for the Freetz Routers.
newcs.freetz.usb		->	NewCS binary with support for the Infinity-USB programmer for the Freetz Routers.
newcs.freetz.pcsc		->	NewCS binary with support for the PC/SC for the Freetz Routers.
newcs.xml			->	The configfile that NewCS reads, should be placed in /var/tuxbox/config.
readme.txt			->	This file you smartass :P


5.-- Runtime Arguments ------- ---  -- - - -

NewCS can be run with some arguments when you start it, here are some of them explained:

-c configfile, here you can specify the path to a configfile.
-h help, will show something similar to this.
-v version, this will show when the binary is compiled and which version it is.
-nd this is will prevent NewCS from forking.
example:
/var/newcs -c /etc/newcs-usb.xml (you give full path to configfile)

6.-- Configfile ------- ---  -- - - -

Remember to always close the tags, there is a beginner tag "<tag>" and a end tag "</tag>", if the tag start
with a "<!-- " and ends with a " -->" it is a comment. More info about xml you will find on google..

Look in the configfile for explanations on what the different sections are.
Configfile isnt case-sensitive and shouldnt care about dos/unix crlf differences.


7.-- TCP-Commands ------- ---  -- - - -

Telnet to the tcp-port (default is 1001) and write the commands hit enter to execute it:
PS! In windows the standard telnet client doesnt work, try using f.ex Putty as a client instead (raw mode).

.----------------------------------------------------------------------------.
| Command       |   Parameters   \   Description                             |
|---------------|------------------------------------------------------------'
|           help| None                          Displays help text.
|           keys| None                          Display AU/SA serialnumbers from card.
|          users| None                          Displays stats about users.
|        readers| None                          Displays readers and their status.
|          cards| None                          Displays readers and their status.
|         uptime| None                          Displays NewCS's uptime.
|          stats| None                          Displays Statistics.
|          cache| None                          Displays Statistics.
|        version| None                          Displays NewCS's version, and configfile used.
|        restart| None                          Reinit all your cards.
|          reset| [reader number]               Reset Cards.
|         reset2| [reader number]               Reset Cards.
|            ban| [user id]                     Ban a user from NewCS.
|          unban| [user id]                     Unban a user from NewCS.
|            sub| [reader number]               Display Entitlements from your cards.
|           sids| (add/remove/clear)            Display and change your sid-lists.
|               | (reader number)(sid)(allow/deny)
|        adduser| [username][password]          Add a newcamd user to your NewCS.
|               | [spider][au][sidoverride][rate]
|        blocker| (reader number)(ua/sa/ga)(yes/no)     Display and change the blocker status in your NewCS.
|          level| (None/Normal/Verbose/Spam/Internal)   Set the loglevel in this telnet session.
|           type| (General/Init/ECM/EMM/Net/IO/All)     Set the logtype in this telnet session.
|            osd| [username][message]           Send a message to one of your connected clients.
|     statsreset| None                          Reset the statistics on your newcamd users.
|           exit| None                          Disconnect this telnet session.
|            bye| None                          Disconnect this telnet session.
|           quit| None                          Disconnect this telnet session.
|    cham2status| None                          Chameleon2 Status Summary
|  cham2sessions| None                          Chameleon2 Sessions Summary
|     cham2cards| None                          Chameleon2 Cards Summary
|  cham2discover| None                          Chameleon2 Discover cards
|           halt| None                          Stop NewCS
|       shutdown| None                          Stop NewCS
.----------------------------------------------------------------------------.
| Parameters in [] is mandatory, () is optional                              |
'----------------------------------------------------------------------------'

PS! if logging bothers you when using tcp-commands, please set loglevel to 0 to stop logging.


8.-- FAQ ------- ---  -- - - -

Q: Who are you, and why are you doing this?
A: we are a group that tries to have some fun, during our spare time we have satellite-studying as
   a hobby - and since newcamd project has its own strange politics, gbox project isnt public and
   the rest of the available isnt quite like we wanted to have it - we wrote our own :o)

Q: Why NewCS as project name?
A: Since newcamd already "stole" the cardserver name - we found out to differ it from newcamd project's
   cardserver, we made another name for it.. NewCS - "New CardServer"
   If you find out another nice name for it, just let us know, we rather code a little as to think about names :o)

Q: Which protocols are supported, and why that new one?
A: Both radegast and newcamd protocol are 100% supported, this to be compatible with any of the current
   clients out there.. eg. mgcamd, evocamd, newcamd and so on.. The reason we made a new protocol is
   because we wanted something of our own - this we can extend and do whatever we want with, the others
   is in the hands of their respective authors.. and can be changed without us kinda "approving" it..

Q: So, which cards are supported?
A: well.. good question :) (since i asked it myself it must be faboulous :p)
   At this moment the following cards are supported:
    *- Conax       (ecm&emm)   *- Seca        (ecm&emm)
    *- Irdeto      (ecm&emm)   *- Cryptoworks (ecm&emm&ecm w/mosc & camcrypt(arena))
    *- Betacrypt   (ecm&emm)   *- Viaccess    (ecm&emm)
    *- Dreamcrypt  (ecm&emm)   *- Videoguard  (ecm&emm)
    *- D2mac       (ecm&emm)   *- Nagravision 2&3(ecm&emm)
    *- DGCrypt     (ecm&emm)
    (all needs to be tested ofc, we dont have the opportunity to do extensive tests).

Q: Where can i find the sourcecode for NewCS?
A: The sourcecode wont be released as we have done alot of work to design it, and really not much help around
   .. personally i can deeply recommend starting on your own project, you'll learn much - i promise :o)

Q: Help? It DOESNT work - where can i reach you?
A: Well.. we hope that when NewCS gets public, there will be a few experts around on the different
   forums and irc channels all around the globe.. you cant reach us, but if you post your questions,
   or if you got errorlog, etc. - on a english-speaking or german-speaking forum, we will probably see it :o)

Q: I Want to donate money to your project, where do i send them?
A: We do this just for fun, and have no commercial interest what-so-ever, we suggest that you send
   the money to a help-organization like f.ex the red-cross, or something similar :)

Q: Why cant newcamd connect to my card?
A: Well, newcamd guys have some strange politics.. some cards cant be used in newcamd with the standard
   protocol.. for some reasons newcamd can only use that with betad and some bloody *nix socket..
   To watch these cards, you have to use the NewCS compliant camds (evocamd or mgcamd) - or maybe some others that havent got limitation.

Q: Why cant gbox connect to my card?
A: Gbox isnt a public project, and "only a few" ppl can get updated versions.. and so on (we all know its BS though).
   anyway.. the protocol used in gbox are unknown at this moment, they change it everytime someone figures it out,
   so we wont support it unless gbox should find out that they would like to use NewCS.. then they can make support :)
   (cs2gbox could work, but who knows or cares :P)

Q: Whats the "node" for Infinity-USB programmer?
A: The USB-port is "only" used to set the programmer to phoenix-mode, all communication with reader goes through serial, so to get it to work
   you have to specify the serialport it is connected to as "node".

Q: Why doesnt my card work with NewCS in windows when it works with NewCS on linux?
A: There can be many reasons, the code for handling communication with the card is 100% different, timeing can be very different too, also
   some devices seems to have better drivers in linux then in windows, and vice versa.

9.-- Changelog ------- ---  -- - - -

v.1.62
   Fixed reset and reinit of cards. (should be alot better now)
   Irshitto EMM and init fixes. ;)
   Reverted Win32 Version back to Console window. (poll was 19% to keep window, 26% to get console back, rest didnt care :p)
   Fixed NDS cards could sometimes give fake cw instead of returning "cant decode".
   Now tries to read 64 entitlements from NDS cards.

  PS!
   Forgot to mention on last release the addition of the <blockC0> tag, to block those emm's on Irshitto.


v.1.61
   Fixed alot of instability problems in Chameleon2.
   Added the possibility to run multiple Chameleon2 servers. (just add more server sections)
   Added realm on running server *NB* Config needs to be modified!
   Added alternative EMM method for oz. (irdetomode in config)
   Updated CDK for freetz to use uClibc 0.29.

  PS!
   Sadly we havent had time to fix win32-related bugs, there seems to be a few who have had problems with it,
   even though we cant reproduce them. (logs people..)
   Are the "minimize to tray" feature important enough to keep the window-based version of newcs? Or should we
   go back to the old console version? (will put up a poll on the forum later..)


v.1.60 *beta*
   Fixed ECM/EMM Cache, should now be OK again. (strange noone noticed this one long time ago?!)
   Added support for DM800 Sci. (needs more testing though..)
   Completely rewritten Chameleon, now called Chameleon2.
   Removed support for the Feynman protocol as its wasnt a success, and we dont have time to maintain it.
   Fixed bug to address comports higher then com9 on win32.
   Fixed EMM bug on irdeto.
   Fixed bug where user would be disabled when changing the users through WEB-console.
   Added provider 0106 and 0907 in nagra2.
   Added support for the QNAP NAS's.
   Added support for the Freetz routers.
   Now using Kamikaze env. for compiling OpenWRT binaries.
   Fixed -march=i386 on i686, should now be i386 compatible.
   Added boxdetect for more platforms. If your box isnt detected ok, please post your /proc/cpuinfo.
   Fixed WEB-console on win32, added it on all archs.
   Added backup of configfile before writing to it. (/tmp for linux, and C:\temp for win32)
   +++ maaany other bugfixes and cosmetic fixes.


v.1.50
   Fix to reconize newest NDS cards.
   Added more functions to the WEB-console.
   Fixed stats functions on WEB-console.
   First betatest of Chameleon P2P-network (look at pt.1).
   First release of Feynman opensource client-server protocol (look at pt.2).
   Updated ezxml to latest version, it IS more sensitive for errors in xml (use a xml validator if needed).
   Removed WEB-console from win32 (win32 is a limited version, without feynman, chameleon and web-console).


v.1.31
   Added support for Nagra "3" (Rom 142 cards).
   Brand spanking new Web-console (look at httpd section in default config).
   Completely rewritten tcp-console.
   Added manual ecm/emm sending.
   Fixed timeing on ATR (should be alot faster for slow cards!).
   Increased timeout on SCI commands, should fix some Big Conax EMM's.
   Default config for x86&/i686 is now /etc/newcs.xml.
   Fixed uptime should be correct on win32 now!
   Added "advanced" mode for tcp-console - to hide possibly scary manual ecm/emm sending.
   Fixed so it increase reset-counter on manual reset.
   Fixes for some Irdeto cards in SCI.
   Fixes to Irdeto EMM-AU code.
   Fixed should now send Issuer Ident for Viaccess again.


v.1.3 -Stable Release
   Okay, first of all we want to apologise for the looong wait.. we have been working hard though, honest! :)
   This is just a minor release though, was time for some bugfixes - and so you know that we're still alive!

   Changes from previous release are too many to mention here (tbh. we have lost control over the changelog :p)
   There have been alot of fixes, hopefully its bit more stable now then before..
   Can also mention that we have added DGcrypt (wherever thats used..)
   Also we have compiled support for the Kathrein box, even though it might not be quite useful (seems awfully buggy) :)

   The big changes and features are planned for the next major release (v1.5 series)


v.1.20 -Release Candidate 13:
   Fixed timeings again.. think it should be faster now.
   Added binary for the Axis Etrax 100LX.
   Added Kaffeine CS client id.
   Modified sending PIN-code for Conax Cards, also now use <pincode> tag to specify your code.
   Added putting EMM in queue (note. if priority == fifo, emm is processed as fifo too, else they processed only if there is no ecm in queue)
   Will now keep ECM in queue even if card needs to reinit, maybe u still get answer within timout-period.
   Fixed misc bugs in NDS code, especially regarding GA-EMM's that made newcs reinit card.
   Fixed cosmetic bug, now showing 6 numbers in provider.
   Added new frequency for phoenix - 1,53mhz.
   Fixed cosmetics, dont flood log when card reinit.
   Added extensions to newcamd code to send sid-list/emm-block mask to mgcamd.
   Added <cardlevel> option for readers, to restrict access for clients with cardlevel.
   Fixed misc bugs in the ECM/EMM-queue.
   Added Entitlement adjustment on caid 092F.
   Added possiblity to force newcs to bind only to one specific ip (only on linux versions).
   Set loglevel to 0 if tcp-password is set.
   Fixed default port on newcamd, if no port is set in device - it will now be 15000+readernumber (instead of 15050 for all readers).
   Fixed Windows Vista should now be reconized.


v.1.19 -Release Candidate 12:
   Fixed Viasat and Misc other cards on sc8 and phoenix. (huge rewrite, will affect all cards on all devices)
   Hopefully fixed NDS code. (huge rewrite)
   Added Alex CS client id.
   Added more errorchecking on config, counting opening and closing tags.
   Added possibility to overclock TD sci.
   Fixed bug where error string wasnt shown on x86/amd64.
   Now sending PIN-code 1234 for Conax cards. (will be configurable later on..)


v.1.18 -Release Candidate 11:
   BEV nagra2 provider fixed.
   Fixed entitlements for BoomTV.
   Added support for viaccess confidential EMM's.
   Fixed bug in Seca UA ins.
   Added possibility to read camkey/camkey-data from config as requested.
   Radegast server will resolve hostname on each new connect. (fix for dynhosts).
   Added support for Arena cryptoworks cards.
   Alot of bugfixes, errorchecks and cleanups.
   Added statreset tcp-command.
   Improved ATR-parsing.
   Fixed bug that used 100% cpu on freeBSD.
   Fixed bug in logging, when using different levels on tcp/file/console.
   Added rate-check for users, possibility to limit ecms/minute from user.
   Fixed conax with different CAID then 0B00.
   Added slovak language indikator on Conax cards.
   Fixed Betacrypt EMM again.
   Fixed bug one certain Irdeto EMM.
   Fixed bug that gave echo mismatch from Betacrypt cards on SC8.
   Added random distribution of card traffic, kind of loadbalancing.
   Fixes in newcamd server for better stability.
   Fixed longer timeout after ATR.
   Fixed Theme-level on viaccess entitlements.

   NB!
   Filenames in release HAVE changed, please use readme for description.


v.1.17 -Release Candidate 10:
   NDS now read boxkey from config and override the automatic detection if the config element exists.
   Fixed Betacrypt EMM.
   Fixed Cryptoworks Bios5 cards on most boxes.
   Fixed entitlements for TotalTV.
   Fixed dreamcrypt on dragon.
   Added Conax PPV-entitlement events.
   Misc. fixes.

   NB!
   If you have a wrong boxkey in config for NDS, it WONT work - so remove the boxkey element if you dont need to override what NewCS
   detects automatically. (It IS needed for TotalTV)


v.1.16 -Release Candidate 9:
   Fixed version numbering, seems we skipped v.1.15 in binary.. *blush*
   More commands available from webinterface.
   Fixed problem (we think) with SID-filter if no static or autosid where enabled.
   Now own option for users to override the SID-filter (instead of AU-user).
   Removed the support for users in own .txt file, the "addusers" are now written directly into the xml configfile.
   Fixed misc debug messages.
   Fixed some bugs with PC/SC reader.
   Fixed a problem with xml-tags in config beeing case-sensitive. (they are now case-insensitive!)
   Added debug when missing config elements in user-sections.
   Fixed bug in cryptoworks entitlements, thanks for proper debug/logs ;)
   Fixed humongus bug in the ban tcp-command.
   Fixed Nagra blocker for EMM-G, thanks for proper debug/logs ;)

   NB!
   pcsc-lite is only needed on linux, on windows it should go automatic :)


v.1.15 -Release Candidate 8:
   Fixed delete newcs.pid when using shutdown tcp-command.
   Added possibility to overclock the dreambox readers. (be careful..)
   Added client-detection for all known clients, look in special notes for more info.
   Fixed recieving client-id on reverse login.
   Added HTTP interface, point the browser to the tcp-port. (http://ip:port/)
   Fixed SID-handling again, now AU-users are free of the SID-filter.
   Added support for SC8 on windows, atleast some CAS (we need logs of those which dont work).
   Fixed Adduser tcp-command, users couldnt login.
   Added Nagra2 entitlements.
   Added Conax PPV entitlements.
   Misc. bugfixes.
   Added PC/SC support.

   NB! For PC/SC support you have to install pcsc-lite and configure it.


v.1.14 -Release Candidate 7:
    Fixed bug in N2 EMM on phoenix/sc8.
    Hopefully fixed bug in tcp-console where data was sendt faster then windows could handle.
    More and better error-handling.
    Added tcp-console password protection.
    Better compability for the Relook box.
    Fixed bug in sid-handling, now sid-lists also apply for AU-users though.
    Added osd tcp-command to send osd messages to clients which support it.
    Fixed Session-key renewal for cards that use dt08.
    Added spider/au option to the adduser command. (old userfile is now incompatible)
    Fixed bug in irdeto EMM handling.
    Misc. cleanups.
    Compiled new binary for the new dreambox 7025.

    NB! tcp-console protection is plain and simple, probably easily hackable..
        You are Warned!


v.1.13 -Release Candidate 6:
    Fixed bug in Nagra2, for cards that use dt08.
    Better info in users tcp-command, also for radegast users now. (show tcp-connections to rdgd)
    Fixed bug in Nagra2 sessionkey implementation.
    Fixed bug in config-reading, some options was case-sensitive.
    Fixed 3.57mhz in infinity reader.
    Added Nagra2 EMM (needs support in camd).
    Added <deny> for readers in <user>-tag.
    Added dynamic ECM cache. (uses less ram)
    Optimize N2 on all devices.


v.1.12 -Release Candidate 5:
    Added Nagra2 support!! Read Special notes! (Nagra1 still not supported, funny eyh? :P)
    Fixed bug that made radegast server hang.
    Added numbering to sids in tcp-command.
    Fixed bug in dreamcrypt, sorry..
    Misc. bugfixes etc.
    Added support for multiple Infinity-usb devices.


v.1.11 -Release Candidate 4:
    Added Auto-sid feature. (see special notes)
    Changed cosmetics on most of the tcp-commands.
    Changed cards command to readers instead, added some more info.
    Added sids command, statistics for sids, and you can add/remove sids with correct parameters.
    Added blocker command, show status for blocker, and you can open/block with correct parameters.
    Added seca-pin option.
    Fixed Cryptoworks Bios5 cards should work ok, opos as a sideeffect :)
    Fixed Irdeto EMM's - thanks to all for pointing that out!
    Fixed irdeto in Dragon.
    Fixed potential bug in ecm-queue.
    Removed PIN on Cryptoworks.
    Fixed Seca EMM, yet again.
    Fixed Viaccess EMM, yet again.
    Misc. bugfixes etc.
    
    NB!
    Removed cw-cache, this was specially made so that newcamd should work with channels that only has 1 cw (NDS),
    please use other client which actually support a single cw, newcamd _WILL_ glitch.
    
    NB2!
    DT special is broken in this release!
    

v.1.10 -Release Candidate 3 -bugfix:
		Fixed bug in NDS on phoenix.
		Remove port from the newcamd-section, should of course be in reader now.
		Fixed Cryptoworks blocker.


v.1.09	-Release Candidate 3:
		Added Entitlements to Viaccess, Seca, Conax, Cryptoworks, irdeto and Videoguard.
		Added tcp-command sub to show entitlements from cards.
		Added some more valid frequencies: 10.71MHz, 10.00MHz and 8.00MHz.
		Fixed EMM-blocker on NDS.
		Added config-option for PTShandshake(look iso 7816 for details). (used on viaccess, cryptoworks and Conax-CAS7 cards)
		Changed ECM-queue per card.
		LOTS of error-handling, but its still a work in progress.
		Added warning message when overclocking card.
		Fixed infinity reader, should now only need the parity/mhz parameters like phoenix.
		Fixed reset tcp-command, should now work ok.
		Optimized keys command, show reader.
		Fixed Viaccess EMM.
		Changed SID-filter to be per-reader, instead of per-caid.
		Changed enabled, exported and rdgd server config options to be yes & no like the rest.
		Added sids tcp-command.
		Fixed irdeto for new version5 cards, should now work with some odd versions too. (thnx to FMalibu for figuring that one out)

		NB!
		Config file has changed, you HAVE!!!!!! to change it! sorry.. :D


v.1.08	-Release Candidate 2:
		Fixed serious bug in newcamd server.
		Optimized speed on some CAS.
		Optimized speed in INIT of Cryptoworks and Viaccess.
		Changed debug print of client detection, some confusion around unknown clients, they are now Generic clients.


v.1.07	-Release Candidate 1:
		Fixed some potential bad filedescriptor bugs. (we have never seen one though, and we miss good logs from those who claim to have them ;)
		Added SC8in1 on Dbox2!!
		Changed ALL devices to use <mhz> + ATR to set Baud/Parity. (<parity> is still used for pre-ATR parity) (be careful with overclocking :)
		Removed <baud> and <databits> from config (not needed anymore).
		Misc cosmetic changes on tcp-commands.
		Added more specific help in tcp-commands.
		Added one more priority type, "round" - look in config for example, possible to select between the 3 different ones.
		Added newcamd client detection (hopefully will be supported by most clients with time, look in special notes).
		Misc newcamd fixes.
		Fixed double resets on some cards in Sci.
		Added <spider> option, possiblity to deny spider to login to useraccount.
		Fixed Crypto-special after attack.
		Fixed Viaccess EMM bugs.
		Added Cryptoworks EMM.
		Added "keys" tcp-command, to show keys from card.
		Made reverse login better.
		Added Win32 binary.
		Fixed a nasty bug in tcp-debug.
			

v.1.06	-Public Beta:
		Fixed NDS EMM with Newcamd (we hope - if not, use mgcamd/evocamd).
		Added ECM Queue, low-id users' ECM gets through first.
		Added EMM cache to dont stress the card with Identical emms. (suggest high EMM cache for this to work good)
		Fixed  VR3 UPC in conax mode.
		Fixed some cosmetic logviewing in telnet ++.
		Crosscompiled for NSLU2 (yet again, we do NOT know if this will ever work).
		Other misc. fixes.
		Added new commands: cache & version.
		Added D2MAC support.
      
		NB!!
		IF you want to report a bug, PLEASE include some log samples and config file.. we're not mindreaders ;)


v.1.05	-Public Beta:
		Added Conformance logic 1.1 (this fixes the spider issues).
		Improved Sci-handling.
		Improved timeing.
		Dbox2 fixed nds in slot for 3.5 and 6mhz.
		Crosscompiled for OpenWRT routers (mips). (absolutely no idea if it will ever work though :o))
		Fixed rdgd server.
		Fixed NDS Skyitaly in phoenix. (we hope)
		Lots of bugfixes..
      

v.1.04	-Public Beta:
		Fixed Viaccess on Dbox (tested on 6Mhz multicam)
		Added option to allow users to only access specified card. (look for changes in configs)
		Added option to specify port for each card. (look for changes in configs)
		Fixed segfault when some options(thats not needed on these) was missing for sci/dragon.
		Changed alot of debug levels.
		Fix baudrate for YES cards.
		Added logging of tcp-commands.
		New tcp-command: uptime.
		Newcamd server close connection if user is unknown.
		Fixed rare login problems.


v.1.03	-Public Beta:
		Fixed Viaccess-init in dbox.
		Fixed Seca-init.
		Made carddetect faster.
		Removed SID checking on irdeto/beta.
		
		NB!!
		Disable carddetect on dbox, it doesnt work.. none of us in the dev-team has access to one, so we
		program in blind. If anyone got info on how to do carddetect on Dbox, please point us in the right
		direction by posting it on boards or something like that.


v.1.02	-Public Beta:
		Fixed Skyitaly ATR (seems they have two different ones, one has same starting bytes as nagra :O)
		Fixed Digital ALB unknown nano.
		Added missing Dbox-type in commented config.
			
		NB!! We have recieved info that Newcamd Cardspider has additional checks for NDS cards, it seems that
		the cards are added to the spider as normal, but the cw's wont reach the other peers (it works locally)..
		In general newcamd dont support 1 single cw, so to have it 100% stable use mgcamd or evocamd.


v.1.01	-Public Beta:
		Reached beta-stage.
		Documentation should be nearly done.


8.-- Troubleshooting ------- ---  -- - - -



9.-- Special Notes ------- ---  -- - - -

Cache (ECM/EMM):
  What can i say, have no idea how to explain this so _everyone_ can understand what the hell it is.. but
  lets have another go.. as with default config, lets assume there is dynamic cache configured:
  Imagine an ECM comes to the server, this NewCS have never seen before, it sends it to the card, the card
  responds with the decrypted control words, the dynamic cache know that this is a good response, and is valid
  for a certain period of time. So it puts it into a storage which is compared with every new ECM sendt to NewCS.
  Now lets imagine there is another client that sends the exactly same ECM within a few seconds, then NewCS compare
  this new ECM to the cache, and finds that the card already have decrypted this ECM, so it just sends the decrypted
  control words to the client, without sending the ECM to the card.
  Since the ECM is only valid for a certain period of time, there isnt need to store them for a longer period (it is
  not very likely that the provider sends the same ECM twice -without there beeing a big bug in their software).
  Regarding EMM cache, it checks the cache if EMM has been sendt to the card before, if it hasnt, then its sendt,
  else its ignored.


Auto-SID:
  If you enable this, NewCS will learn which channels your cards can decode, and deny the others,
  this will hopefully lower the load on your card, giving it a longer life and faster decryption.
  The Configfile options will override the auto-sid feature, so think through your setup.
  A valid EMM will reset the denied auto-sids.


User numbering:
  There has been ALOT of suspicions etc. around the fact that our userid's start at number 2.
  First of all, if we wanted to make a backdoor, you really think we would make it that obvious?
  The REAL reason for userid's starting at 2 is that newcamd always assumes that userid 1 has AU-rights,
  we dont like this policy, so ALL newcs-users has to have <au>on</au> to get AU-rights.
  Simple as that :)


Client Detection:
  The two custom-bytes in login is used for identifying the client, the following are assigned by us:

    #define CL_VDRSC  0x5644 - VDR-SC
    #define CL_LCE    0x4C43 - LinCardEMU
    #define CL_CAMD3  0x4333 - Camd3
    #define CL_RDGD   0x7264 - Radegast
    #define CL_GBOX   0x6762 - Gbox
    #define CL_WINCSC 0x7763 - WinCSC


ECM Queue:
 There are 3 types supported:
  Hard:
  low-id users' ECM gets through first,that mean first user in config will have the highest priority.
 Round:
  All users have equal chance of getting theire ECM through, its called "Round Robin"-algoritm.
 FIFO:
  First in, First out - as the name says, the one who sendt first, gets answer first.

   
USB2Serial:
  Well, this is some tricky stuff..
  There seems to be adapters that emulate almost 100% and works with all CAS, we have seen them in both pl2303 adapters and ftdi adapters.
  And then we have the adapters that work on conax, seca, viaccess, cryptoworks, dreamcrypt, irdeto - and if your are lucky, videoguard -
  or maybe only a few of them.. seems some adapters are really really slow, or just dont read/write all bytes :(

Infinity USB burner:
  There seems to be some slight problems if the usb isnt put in before the machine is booted, you can always check manually if its detected,
  just do: cat /proc/bus/usb/devices | grep "wbe" - if you get anything then all probably should go very well :)

Mp35 burner: 
  The timing on this device seems to be a little strange - works on some CAS and not on others, not much to do about it..
  


10.-- Known Bugs ------- ---  -- - - -

*sending ECM/EMM with spaces in them from tcp-console, doesnt work..


11.-- Thanks guys, You ROCK! ------- ---  -- - - -

Much precious time has been spent on the project, remember its all about fun, not about money..
We are against all commercial cardsharing, and will do as much as we can to prevent it - without
limiting the "normal" user..
