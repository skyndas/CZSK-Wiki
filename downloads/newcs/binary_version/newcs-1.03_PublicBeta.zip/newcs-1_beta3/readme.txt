--- ------- ---  -- - - -
 NewCS readme
- -- ---  -- - - -

We have no politics.. this is just for fun - blame yourself..

 "How should I know if it works? That's what beta testers are for. I only coded it."
  -Linus Torvalds


--- Index ------- ---  -- - - -

1. File Descriptions
2. Runtime Arguments
3. Configfile
4. TCP-Commands
5. FAQ
6. Changelog
7. Troubleshooting
8. Special Notes
9. Greets


1.-- File Descriptions ------- ---  -- - - -

newcs.ppc			->	NewCS binary for dreambox, tripledragon and other powerpc machines.
newcs-infinity.ppc	->	NewCS with support for the Infinity-USB programmer for powerpc machines.
newcs.x86			->	32bit NewCS binary for linux on Intel compatible machines.
newcs-infinity.x86	->	NewCS with support for the Infinity-USB programmer for Intel compatible machines.
newcs.xml			->	The configfile that NewCS reads, should be placed in /var/tuxbox/config.
libusb-0.1.so.4.ppc	->	libusb for powerpc machines. (needed by newcs-infinity.ppc)
libusb-0.1.4.x86	->	libusb for Intel compatible machines. (needed by newcs-infinity.x86)
readme.txt	->	This file you smartass :P


2.-- Runtime Arguments ------- ---  -- - - -

NewCS can be run with some arguments when you start it, here are some of them explained:

-c configfile, here you can specify the path to a configfile.
-h help, will show something similar to this.
-v version, this will show when the binary is compiled and which version it is.
example:
/var/newcs -c /etc/newcs-usb.xml (you give full path to configfile)

3.-- Configfile ------- ---  -- - - -

Remeber to always close the tags, there is a beginner tag "<tag>" and a end tag "</tag>", if the tag start
with a "<!-" and ends with a "->" it is a comment. More info about xml you will find on google..

Look in the configfile for explanations on what the different sections are.
Configfile isnt case-sensitive and shouldnt care about dos/unix crlf differences.


4.-- TCP-Commands ------- ---  -- - - -

Telnet to the tcp-port (default is 1001) and write the commands hit enter to execute it:
PS! In windows the standard telnet client doesnt work, try using f.ex Putty as a client instead.

help		  -  shows the current commands, and use - available in this binary.
users		  -  shows users, and their stats.
cards		  -  shows cards, caid, port etc.
reset <num>	  -  to reset the card manually, <num> is the card number showed in cards command
ban <num>	  -  to ban(block) user, <num> is number showed in users.
unban <num>	  -  to unban the user banned above.
adduser 	  -  add a temporary user.
level <new level> -  log level in the current tcp connection, if you give a number it will be set as new loglevel.
type <new type>	  -  log type in the current tcp connection, if you give a number it will be set as new type.
shutdown	  -  shutdown NewCS.
exit		  -  exit tcp interface.

PS! if logging bothers you when using tcp-commands, please set loglevel to 0 to stop logging.


5.-- FAQ ------- ---  -- - - -

Q: Who are you, and why are you doing this?
A: we are a group that tries to have some fun, during our spare time we have satellite-studying as
   a hobby - and since newcamd project has its own strange politics, gbox project isnt public and
   the rest of the available isnt quite like we wanted to have it - we wrote our own :o)

Q: Why NewCS as project name?
A: Since newcamd already "stole" the cardserver name - we found out to differ it from newcamd project's
   cardserver, we made another name for it.. NewCS - "New CardServer"
   If you find out another nice name for it, just let us know, we rather code a little as to think about names :o)

Q: Which protocols are supported, and why that new one?
A: Both radegast and newcamd protocol are 100% supported, this to be compatible with any of the current
   clients out there.. eg. mgcamd, evocamd, newcamd and so on.. The reason we made a new protocol is
   because we wanted something of our own - this we can extend and do whatever we want with, the others
   is in the hands of their respective authors.. and can be changed without us kinda "approving" it..

Q: So, which cards are supported?
A: well.. good question :) (since i asked it myself it must be faboulous :p)
   At this moment the following cards are supported:
    *- Conax       (ecm&emm)   *- Seca        (ecm&emm)
    *- Irdeto      (ecm&emm)   *- Cryptoworks (ecm&ecm w/mosc)
    *- Betacrypt   (ecm&emm)   *- Viaccess    (ecm&emm)
    *- Dreamcrypt  (ecm&emm)   *- Videoguard  (ecm&emm)
    *- Nagravision (init not done yet)
    (all needs to be tested ofc, we dont have the opportunity to do extensive tests).

Q: Where can i find the sourcecode for NewCS?
A: The sourcecode wont be released as we have done alot of work to design it, and really not much help around
   .. personally i can deeply recommend starting on your own project, you'll learn much - i promise :o)

Q: Help? It DOESNT work - where can i reach you?
A: Well.. we hope that when NewCS gets public, there will be a few experts around on the different
   forums and irc channels all around the globe.. you cant reach us, but if you post your questions,
   or if you got errorlog, etc. - on a english-speaking or german-speaking forum, we will probably see it :o)

Q: I Want to donate money to your project, where do i send them?
A: We do this just for fun, and have no commercial interest what-so-ever, we suggest that you send
   the money to a help-organization like f.ex the red-cross, or something similar :)

Q: Why cant newcamd connect to my card?
A: Well, newcamd guys have some strange politics.. some cards cant be used in newcamd with the standard
   protocol.. for some reasons newcamd can only use that with betad and some bloody *nix socket..
   To watch these cards, you have to use the NewCS compliant camds (evocamd or mgcamd) - or maybe some others that havent got limitation.

Q: Why cant gbox connect to my card?
A: Gbox isnt a public project, and "only a few" ppl can get updated versions.. and so on (we all know its BS though).
   anyway.. the protocol used in gbox are unknown at this moment, they change it everytime someone figures it out,
   so we wont support it unless gbox should find out that they would like to use NewCS.. then they can make support :)
   (cs2gbox could work, but who knows or cares :P)

Q: Is the xml protocol available?
A: Yes! :) will be documented here ASAP!


6.-- Changelog ------- ---  -- - - -

v.1.03	-Public Beta:
			Fixed Viaccess-init in dbox.
			Fixed Seca-init.
			Made carddetect faster.
			Removed SID checking on irdeto/beta.
			
			NB!!
			Disable carddetect on dbox, it doesnt work.. none of us in the dev-team has access to one, so we
			program in blind. If anyone got info on how to do carddetect on Dbox, please point us in the right
			direction by posting it on boards or something like that.

v.1.02	-Public Beta:
			Fixed Skyitaly ATR (seems they have two different ones, one has same starting bytes as nagra :O)
			Fixed Digital ALB unknown nano.
			Added missing Dbox-type in commented config.
			
			NB!! We have recieved info that Newcamd Cardspider has additional checks for NDS cards, it seems that
			the cards are added to the spider as normal, but the cw's wont reach the other peers (it works locally)..
			In general newcamd dont support 1 single cw, so to have it 100% stable use mgcamd or evocamd.

v.1.01	-Public Beta:
			Reached beta-stage.
			Documentation should be nearly done.


7.-- Troubleshooting ------- ---  -- - - -

There are problems?


8.-- Special Notes ------- ---  -- - - -

USB2Serial:
  Well, this is some tricky stuff..
  There seems to be adapters that emulate almost 100% and works with all CAS, we have seen them in both pl2303 adapters and ftdi adapters.
  And then we have the adapters that work on conax, seca, viaccess, cryptoworks, dreamcrypt, irdeto - and if your are lucky, videoguard -
  or maybe only a few of them.. seems some adapters are really really slow, or just dont read/write all bytes :(

Infinity USB burner:
  There seems to be some slight problems if the usb isnt put in before the machine is booted, you can always check manually if its detected,
  just do: cat /proc/bus/usb/devices | grep "wbe" - if you get anything then all probably should go very well :)

Mp35 burner: 
  The timing on this device seems to be a little strange - works on some CAS and not on others, not much to do about it..
  
  

9.-- Thanks guys, You ROCK! ------- ---  -- - - -

Much precious time has been spent on the project, remember its all about fun, not about money..
We are against all commercial cardsharing, and will do as much as we can to prevent it - without
limiting the "normal" user..


