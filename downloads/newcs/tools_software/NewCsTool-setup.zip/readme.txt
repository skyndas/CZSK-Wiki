NewCsTool is a telnetclient for NewCsTool.

Since Windows built in telnetclient doesn�t work with NewCs and I find it a pain in th *ss to open Putty each time I need to log in to my NewCs-server I�ve made this little tool.

It�s still quite beta but try it if you like.

First time you run the program it asks for Ip, Port and password(Auth) to the server. 
Enter the correct values in the boxes and click ok.
Notice.: if you wan�t to change theese values, close down NewCsTool and delete the file "settings.ini". Restart NewCsTool and enter the new values.

When program opens first click connect and wait a few secons.

Then you are ready to click the other functions.

Have Phun.

funburner@mailme.dk
