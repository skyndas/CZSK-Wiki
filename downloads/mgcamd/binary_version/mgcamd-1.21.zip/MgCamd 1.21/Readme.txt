2007/03/11
v1.21
internal cw keys updated.
tps "au" fix.
pw sharing fix.
async connections to newcamd servers (not fully tested). 
