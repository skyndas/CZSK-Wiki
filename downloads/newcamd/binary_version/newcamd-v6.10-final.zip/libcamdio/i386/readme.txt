libcamdio.so for i386

- to be used together with szap-patch
- does support decoding of one channel at a time only, no elementary pids
  are necessary
- no OSD, the OSD api functions exist of course, but do nothing
- pmt update watch has to be done by camd
- sid, pmtpid and apid are given to camd_service_add/update, pmt will always
  be NULL, camd has to demux the pmt from the given pmtpid
