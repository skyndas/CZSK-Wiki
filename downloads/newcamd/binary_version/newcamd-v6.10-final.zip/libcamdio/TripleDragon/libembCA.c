#include <stdlib.h>
#include <unistd.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <stdio.h>

#define VERSION "CA"
#define DESCRIPTION "Conditional Access"
#define NAME "embCA"
#define CAMD_UDS_SOCKET "/tmp/camd.socket"

typedef struct plugin_functions_struct
{
	unsigned char* (*plugin_version)();
	unsigned char* (*plugin_description)();
	void (*unused1)();
	void* (*plugin_menu)();
	void (*unused2)();
	void (*plugin_cleanup)();
	void (*plugin_init)();
	unsigned int (*plugin_start)();
	void (*unused3)();
} plugin_functions_t;

typedef int (*TD_signal_callback)();
extern void TD_signal_connect(int signal, TD_signal_callback callback);
extern void TD_signal_disconnect(int signal, TD_signal_callback callback);
extern void liyahtv_register_plugin(unsigned char *pluginName, unsigned int someInteger /* 3 */, plugin_functions_t *pluginFunctions);
extern unsigned char *current_raw_pmt;
extern unsigned int current_raw_pmt_len;
extern struct td_state_struct
{
	unsigned char unknown[0x50];
	unsigned int doing_satscan;
} TD_STATE;

static int udsFd = -1;
static unsigned char harddisk_playback = 0;
static unsigned char harddisk_recording = 0;

static void cardserver_power(unsigned char power)
{
	int conn;
	struct sockaddr_un servaddr;
	unsigned char idx = 0, dummy;
	static unsigned char devname[30] = "/tmp/cardserver-powersocket";

	while(idx < 100)
	{
		sprintf(devname+27, "%u", idx);
		if (access(devname, F_OK) < 0) return;
		servaddr.sun_family = AF_UNIX;
		strcpy(servaddr.sun_path, devname);
		if ((conn = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) return;
		if (connect(conn, (struct sockaddr*) &servaddr, sizeof(servaddr)) < 0) { close(conn); idx++; continue; }
		if (write(conn, &power, 1) != 1) { close(conn); return; }
		read(conn, &dummy, 1);
		close(conn);
		idx++;
	}
}

static unsigned char *plugin_version()
{
	static unsigned char version[] = VERSION;
	return version;
}

static unsigned char *plugin_description()
{
	static unsigned char description[] = DESCRIPTION;
	return description;
}

static int channel_deactivate()
{
	if (udsFd >= 0) { close(udsFd); udsFd = -1; }	// close the connection to camd.socket to signal deactivation
	return 0;
}

static int channel_activate()
{
	static unsigned short current_sid = 0;
	static unsigned short current_pcr = 0;
	unsigned short sid, pcr;

	if (TD_STATE.doing_satscan || (harddisk_playback && !harddisk_recording) || current_raw_pmt_len < 12 || (((current_raw_pmt[1] & 0x0f) << 8) | current_raw_pmt[2]) + 3 != current_raw_pmt_len) return channel_deactivate();
	sid = (current_raw_pmt[3] << 8) | current_raw_pmt[4];
	pcr = ((current_raw_pmt[8] & 0x1f) << 8) | current_raw_pmt[9];
	if (udsFd >= 0 && (current_sid != sid || current_pcr != pcr)) channel_deactivate();	// treat it like a channel change and deactivate the old channel first
	current_sid = current_pcr = 0;
	if (udsFd >= 0) // try to read connection to determine if other side has closed it
	{
		int selectResult;
		struct timeval selectWaitTime = { 0, 0 };
		fd_set fds;

		FD_ZERO(&fds);
		FD_SET(udsFd, &fds);
		selectResult = select(FD_SETSIZE, &fds, NULL, NULL, &selectWaitTime);
		if (selectResult) channel_deactivate();		// error or data from other side
	}
	if (udsFd < 0)	// need to open a new connection to camd.socket
	{
		struct sockaddr_un servaddr;

		if ((udsFd = socket(PF_UNIX, SOCK_STREAM, 0)) < 0) return 0;
		servaddr.sun_family = AF_UNIX;
		strcpy(servaddr.sun_path, CAMD_UDS_SOCKET);
		if (connect(udsFd, (struct sockaddr*) &servaddr, sizeof(servaddr)) < 0) { close(udsFd); udsFd = -1; return 0; }
	}
	if (write(udsFd, current_raw_pmt, current_raw_pmt_len) != current_raw_pmt_len) return channel_deactivate();
	current_sid = sid; current_pcr = pcr;		// remember current channel data
	// keep connection to camd.socket open for as long as the current channel is watched by the user
	return 0;
}

static int harddisk_playback_start()
{
	harddisk_playback = 1;
	if (harddisk_recording) return 0;
	return channel_deactivate();
}

static int harddisk_playback_stop()
{
	harddisk_playback = 0;
	if (harddisk_recording) return 0;
	return channel_deactivate();
}

static int harddisk_recording_start() { harddisk_recording = 1; return 0; }

static int harddisk_recording_stop() { harddisk_recording = 0; return 0; }

static void plugin_cleanup()
{
	TD_signal_disconnect(0x40, channel_activate);		// pmt update
	TD_signal_disconnect(0x60, harddisk_playback_start);
	TD_signal_disconnect(0x61, harddisk_playback_stop);
	TD_signal_disconnect(0x62, harddisk_recording_start);
	TD_signal_disconnect(0x63, harddisk_recording_stop);
	TD_signal_disconnect(0x70, channel_deactivate);		// sat scan started
	TD_signal_disconnect(0x71, channel_deactivate);		// sat scan stopped
	channel_deactivate();
	cardserver_power(0);
}

static void plugin_init()
{
	cardserver_power(1);
	TD_signal_connect(0x40, channel_activate);		// pmt update
	TD_signal_connect(0x60, harddisk_playback_start);
	TD_signal_connect(0x61, harddisk_playback_stop);
	TD_signal_connect(0x62, harddisk_recording_start);
	TD_signal_connect(0x63, harddisk_recording_stop);
	TD_signal_connect(0x70, channel_deactivate);		// satscan started
	TD_signal_connect(0x71, channel_deactivate);		// satscan stopped
}

static void *plugin_menu() { return NULL; }
static unsigned int plugin_start() { return 0; }

static plugin_functions_t pluginFunctions =
{
	.plugin_version		= plugin_version,
	.plugin_description	= plugin_description,
	.plugin_menu		= plugin_menu,
	.plugin_cleanup		= plugin_cleanup,
	.plugin_init		= plugin_init,
	.plugin_start		= plugin_start,
	.unused1		= NULL,
	.unused2		= NULL,
	.unused3		= NULL,
};

static void __attribute__ ((constructor)) init_ca() { liyahtv_register_plugin("embCA", 3, &pluginFunctions); }
