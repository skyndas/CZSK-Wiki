Polsat Au... Newcamd v5.20

Unzip and copy file in directory Dreambox

/var/bin/*.*

rewrite all old file

atribute 755

enjoy !

   