This is a small dyndns client to run from behind a NAT router if the router does
not support dyndns. If your router has a dyndns client, use that one instead.

Two modes of operation

- single update:
  dyndnscd test.dyndns.org test:test
- running in server mode updating every time IP changes:
  dyndnscd -d test.dyndns.org test:test

Replace test.dyndns.org with your real dyndns hostname of course and test:test
by your username:password.
