libcamdio.so for dbox2

- designed for and tested with recent yadi images
- does support decoding of one channel at a time only, no elementary pids
  are necessary
- OSD works, for both enigma & neutrino, enigma is the default, neutrino
  will be used, if a file /var/etc/.neutrino exists in the image, on yadi,
  this file is created, if you boot neutrino and turn off the enigma/neutrino
  boot menu in the neutrino settings
- when using enigma, pmt_update_watch is done by enigma, camd will be updated 
  each time the pmt changes
- when using neutrino (/var/etc/.neutrino exits), libcamdio.so will check for
  a file /var/etc/.pmt_update, if it exists, it will assume neutrino is doing
  the pmt update watch, if not, it will tell camd to do it, file
  /var/etc/.pmt_update is created on yadi images, if you set pmt update = yes
  in the neutrino settings
- support for both external (0) and internal serial (multicam) port (1)
- sid and "fake"-pmt are given to camd_service_add/update, the "fake"
  pmt is build from the ca pmt which is sent by enigma or neutrino to
  camd.socket, the apid function parameter will always be 0, when using enigma
  pmtpid is also given, when using neutrino, pmtpid will always be 0. This
  means, the user either has to use pmt update in neutrino or camd must demux
  the pmtpid from the transponder pat and the sid parameter to get the pmtpid,
  so it can do pmt update watch
