libcamdio.so for Dreambox 500/7000/7020

- support for 500, 7000 and 7020 tested, others should work, but untested
- supports decoding of multiple channels at a time, descrambler slots
  will be allocated dynamically by the library, the camd does not have
  to bother about this, newcamd however doesn't support multiple channels
  at the same time, so it will only work when another camd uses libcamdio
- elementary pids are necessary
- OSD works, expects the user to use enigma
- pmt update watch is done by enigma, camd will be updated each time the
  pmt changes
- support for both internal cardreaders (0=upper/500, 1=lower)
- serial port (7000/7020: 2, 500: 1) confirmed working,
  but you have to set "Don't open serial port" option on Enigma.
  Unfortunately the 7020 hangs in the Second Stage Bootloader
  on boot when a Phoenix interface is connected to the serial port,
  with the "*** SERIAL MODE ***" being displayed on the LCD display.
- usb->rs232 work (SERIAL_PORT = 3 and higher), tested with Prolific PL-2303
  USB->RS232 adapters (7000/7020 only)
- sid, pmtpid and "fake"-pmt are given to camd_service_add/update, the "fake"
  pmt is build from the ca pmt which is sent by enigma to camd.socket, the
  apid function parameter will always be 0
- when the camd is first started and calls camd_trigger_init() libcamdio.so
  tries to get the current channel from /tmp/.listen.camd.socket if possible
  this is a new enigma feature and requires a cvs image build after Dec 26th,
  2005, Auto reconnect cahandler option is not required for this to work, in
  fact, it's better to leave it off, otherwise enigma tries to open camd.socket
  all the time, which isn't there as long as libcamdio.so uses
  .listen.camd.socket
- if /tmp/.listen.camd.socket fails for any reason (image from before Dec 26th,
  2005, you restart enigma or enigma isn't started yet when you start your camd)
  libcamdio.so automatically falls back on using camd.socket and keeps using it
  until camd calls camd_trigger_release() and then camd_trigger_init()
  (usually only when you restart your camd)
- cardserver port assignment
                    7000 & 7020      500
  SERIAL_PORT = 0   upper slot       card slot
  SERIAL_PORT = 1   lower slot       RS-232
  SERIAL_PORT = 2   RS-232           N/A
  SERIAL_PORT = 3   /dev/usb/tts/0   N/A
