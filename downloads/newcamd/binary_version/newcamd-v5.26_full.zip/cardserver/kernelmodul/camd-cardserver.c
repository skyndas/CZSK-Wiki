#include <linux/module.h>
#include <linux/devfs_fs_kernel.h>
#include <asm/uaccess.h>
#include <asm/8xx_immap.h>

#define MAJOR_NUMBER 241
#define MINOR_NUMBER 0
#define DEVNAME "rtscts"
#define SET_RTS_0	_IOW('o', 0, unsigned int)
#define GET_RxD_0	_IOR('o', 1, unsigned int)
#define SET_RTS_1	_IOW('o', 2, unsigned int)
#define GET_RxD_1	_IOR('o', 3, unsigned int)
#define SET_DTR_0	_IOW('o', 4, unsigned int)
#define SET_DTR_1	_IOW('o', 5, unsigned int)
#define GET_PCDAT	_IOR('o', 6, unsigned int)
#define SETBAUDRATE_0	_IOW('o', 7, unsigned int)
#define SETBAUDRATE_1	_IOW('o', 8, unsigned int)
#define GETBAUDRATE_0	_IOR('o', 9, unsigned int)
#define GETBAUDRATE_1	_IOR('o', 10, unsigned int)

#define PROGNAME "camd-cardserver.o"

static devfs_handle_t devfs_handle;
static int camd_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
static immap_t *immap;
static iop8xx_t *ioport;
static cpm8xx_t *commproc;
static spinlock_t spinlock = SPIN_LOCK_UNLOCKED;
static unsigned long irqflags;

static struct file_operations fops = {
        owner:    THIS_MODULE,
        read:     NULL,
        write:    NULL,
        ioctl:    camd_ioctl,
        open:     NULL,
        release:  NULL,
        poll:     NULL,
};

MODULE_AUTHOR("nobody <nobody@nobody.net>");
MODULE_DESCRIPTION("newcamd additional serial line driver");
MODULE_LICENSE("GPL");

/* This function is called on insmod */
int init_module(void)
{
	immap = (immap_t *) (mfspr(IMMR) & 0xffff0000);

	ioport = &(immap->im_ioport);
	commproc = &(immap->im_cpm);
	devfs_handle = devfs_register(NULL, DEVNAME, DEVFS_FL_DEFAULT, MAJOR_NUMBER, MINOR_NUMBER,
				      S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH,
				      &fops, NULL);
	if (!devfs_handle) return -1;
	printk("[%s] compiled %s, %s\n", PROGNAME, __DATE__, __TIME__);
	printk("[%s] ioport   base = %p\n", PROGNAME, ioport);
	printk("[%s] commproc base = %p\n", PROGNAME, commproc);
	spin_lock_irqsave(&spinlock, irqflags);
	ioport->iop_pcdat |= 0x0910;
	ioport->iop_pcdir |= 0x0910;
	commproc->cp_pbdat |= 0x4000;
	commproc->cp_pbdir |= 0x4000;
	spin_unlock_irqrestore(&spinlock, irqflags);
	return 0;
}

/* This function is called on rmmod */
void cleanup_module(void)
{
	devfs_unregister(devfs_handle);
}

int camd_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	void *parg = (void *) arg;
	switch (cmd)
	{
		case SET_RTS_0:
		{
			if ((unsigned int) arg)
			{
				spin_lock_irqsave(&spinlock, irqflags);
				ioport->iop_pcdat &= 0xffef;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			else
			{
				spin_lock_irqsave(&spinlock, irqflags);
				ioport->iop_pcdat |= 0x0010;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			break;
		}
		case SET_RTS_1:
		{
			if ((unsigned int) arg)
			{
				spin_lock_irqsave(&spinlock, irqflags);
				ioport->iop_pcdat &= 0xf7ff;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			else
			{
				spin_lock_irqsave(&spinlock, irqflags);
				ioport->iop_pcdat |= 0x0800;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			break;
		}
		case SET_DTR_0:
		{
			if ((unsigned int) arg)
			{
				spin_lock_irqsave(&spinlock, irqflags);
				ioport->iop_pcdat &= 0xfeff;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			else
			{
				spin_lock_irqsave(&spinlock, irqflags);
				ioport->iop_pcdat |= 0x0100;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			break;
		}
		case SET_DTR_1:
		{
			if ((unsigned int) arg)
			{
				spin_lock_irqsave(&spinlock, irqflags);
				commproc->cp_pbdat &= 0xffffbfff;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			else
			{
				spin_lock_irqsave(&spinlock, irqflags);
				commproc->cp_pbdat |= 0x4000;
				spin_unlock_irqrestore(&spinlock, irqflags);
			}
			break;
		}
		case GET_RxD_0:
		{
			unsigned int value;

			spin_lock_irqsave(&spinlock, irqflags);
			value = (commproc->cp_pbdat & 0x80) ? 0 : 1;
			spin_unlock_irqrestore(&spinlock, irqflags);
			if (copy_to_user(parg, &value, sizeof(value)))
			{
				return -EFAULT;
			}
			break;
		}
		case GET_RxD_1:
		{
			unsigned int value;

			spin_lock_irqsave(&spinlock, irqflags);
			value = (ioport->iop_padat & 0x40) ? 0 : 1;
			spin_unlock_irqrestore(&spinlock, irqflags);
			if (copy_to_user(parg, &value, sizeof(value)))
			{
				return -EFAULT;
			}
			break;
		}
		case GET_PCDAT:
		{
			unsigned int value;
			spin_lock_irqsave(&spinlock, irqflags);
			value = (~(ioport->iop_pcdat)) & 0xffff;
			spin_unlock_irqrestore(&spinlock, irqflags);
			if (copy_to_user(parg, &value, sizeof(value)))
			{
				return -EFAULT;
			}
			break;
		}

		case GETBAUDRATE_0:
		{
			unsigned int value;
			spin_lock_irqsave(&spinlock, irqflags);
			value = commproc->cp_brgc1;
			spin_unlock_irqrestore(&spinlock, irqflags);
			if (copy_to_user(parg, &value, sizeof(value)))
			{
				return -EFAULT;
			}
			break;
		}

		case GETBAUDRATE_1:
		{
			unsigned int value;
			spin_lock_irqsave(&spinlock, irqflags);
			value = commproc->cp_brgc2;
			spin_unlock_irqrestore(&spinlock, irqflags);
			if (copy_to_user(parg, &value, sizeof(value)))
			{
				return -EFAULT;
			}
			break;
		}

		case SETBAUDRATE_0:
			spin_lock_irqsave(&spinlock, irqflags);
			commproc->cp_brgc1 = (((unsigned int) arg) << 1) | 0x10000;
			spin_unlock_irqrestore(&spinlock, irqflags);
			break;

		case SETBAUDRATE_1:
			spin_lock_irqsave(&spinlock, irqflags);
			commproc->cp_brgc2 = (((unsigned int) arg) << 1) | 0x10000;
			spin_unlock_irqrestore(&spinlock, irqflags);
			break;

		default:
			return -ENOTSUPP;
			break;
	}
	return 0;
}
