These packages can be installed on the official 1.00 DMM image,
dated February 12th, 2005

The Dreambox 7020 has a very nice software package handling system, just as
regular Linux distributions for your PC do. You should never just copy any
standalone files onto the Dreambox 7020 root filesystem. Instead use the package
handling system, which will automaticially copy all the necessary files to the
correct locations, changes the boot skripts to start the additional software
automatically at boot time, etc. For the Dreambox 7020, we made a seperate set
of distribution files, using the package handling system. All you need to do, is
upload the ipk files to some temporary directory (/tmp for example) and then
install the software using ipkg. Only install the packages you intend to use of
course:

ipkg install libcamdio_0.0.0_dreambox.ipk (always needed)
ipkg install newcamd_6.01_dreambox.ipk
ipkg install newcamd-cardserver_6.01_dreambox.ipk
ipkg install newcamd-cardspider_6.01_dreambox.ipk

In case, other camd authors decide to start using the api, libcamdio is put in
a seperate package.

After the installation, just edit the config files, and restart the software:
/etc/init.d/newcamd restart
/etc/init.d/cardserver restart
/etc/init.d/cardspider restart
