#ifndef LIBCAMDIO_H
#define LIBCAMDIO_H

typedef         unsigned char		uint8;
typedef         unsigned short		uint16;
typedef         unsigned int		uint32;
typedef         unsigned long long	uint64;

#include <stdlib.h>

/* structures used to set demux filters, compatible to LinuxTV API 2 */

#define DMX_FILTER_SIZE 16
#define DMX_CHECK_CRC       1
#define DMX_ONESHOT         2
#define DMX_IMMEDIATE_START 4

typedef struct dmx_filter_struct
{
	uint8 filter[DMX_FILTER_SIZE];
	uint8 mask[DMX_FILTER_SIZE];
} dmx_filter_t;

typedef struct dmx_sct_filter_params_struct
{
	uint16			pid;
	dmx_filter_t		filter;
	uint32			timeout;
	uint32			flags;
} dmx_sct_filter_params_t;

/* camd trigger functions - need to be called from your camd's main idle loop *
 *                                                                            *
 * the trigger mechanism is the interface between the normal firmware of a    *
 * supported platform (like neutrino, enigma or dvb2001) and the conditional  *
 * access software (for example to tell camd about a channel change by the    *
 * user)                                                                      */

// call once when your camd starts - this will create and initialize
// libcamdio's trigger port (/tmp/camd.socket or similar)
// returns <0 on error
int camd_trigger_init(uint8 adapterNo);
// call once when your camd quits - this will remove libcamdio's
// trigger port
void camd_trigger_release();
// usually you will have a main idle loop on your camd that calls select()
// on a number of file descriptors (demuxers, network connections, etc) to
// see if there's activity on any of them
// camd_trigger_fd_add will add file descriptors that needs to be checked
// for activity regularly to make the trigger mechanism work
// camd_trigger_handler checks if there was activity on any of the trigger
// related file descriptors and starts the appropriate actions, for example
// call camd_service_add or camd_service_release (see below)
void camd_trigger_fd_add(fd_set *fds);
int camd_trigger_handler(fd_set *fds);

/* for operation of the trigger mechanism, you would put something like  *
 * this into your camd's main loop:                                      *
 *                                                                       *
 * while(1)                                                              *
 * {                                                                     *
 *   fd_set fds;                                                         *
 *   FD_ZERO(&fds);                                                      *
 *   camd_trigger_fd_add(&fds);                                          *
 *   // add your own file descriptors that need to be checked as well    *
 *   select(FD_SETSIZE, &fds, NULL, NULL, NULL);                         *
 *   camd_trigger_handler(&fds);                                         *
 *   // check fds for activity on your own file descriptors and call the *
 *   // appropriate actions                                              *
 * }                                                                     */

/* camd trigger functions - camd callbacks                             *
 * the following functions have to exist on your camd in order to link *
 * correctly with libcamdio.so (so called callbacks)                   */

// start decoding a new service or update an existing one
// channelId: a unique number for this service, camd has to remember this
// number and use it on calls to libcamdio functions
// sid         = service id (or program number)
// pmt         = byte array with the raw pmt as received from the demuxer
// active_apid = the audio pid currently chosen by the user
// pmtpid, pmt and active_apid are not always given, parameters that are
// not available are set to 0, camd must check for this
// currently libcamdio.so for Dreambox provides pmtpid and pmt
// currently libcamdio.so for TripleDragon provides only pmt
// currently libcamdio.so for dbox2 provides only pmt (pmtpid also if
// enigma is used)
// sid and channelId parameters are always given, the camd has to rely on this
void camd_service_add(uint8 channelId, uint16 sid, uint16 pmtpid, uint8 *pmt, uint16 active_apid);
void camd_service_update(uint8 channelId, uint16 sid, uint16 pmtpid, uint8 *pmt, uint16 active_apid);

// remove decoding of a particular service
void camd_service_release(uint8 channelId);

/* OSD related functions */

// set the authentication string for logins to the http webserver,
// for example: string = "root:dbox2"
void osd_set_http_login(uint8 *string);

// show a pop window on neutrino/enigma
void osd_popup_message(uint8 *header, uint8 *body, uint8 timeout);

/* demux related functions */

// open a demux device, associated with channelId
// channelId: is important for decoding multiple services, each service
// might use a different demux device, especially if you use services from
// different transport streams in dual-tuner boxes, always call libdemux_open
// with the channelId, given to camd_service_add earlier, so the library
// can open the correct demuxer
// adapterNo: for i386 only, if on a Linux server, you have more than one
// DVB-S card, you can pick the one to use, this applies only to Linux PC's,
// for all currently known Linux set-top-boxes (dbox2, Dreambox, TD), this is
// always 0
// flags: O_RDWR, O_NONBLOCK, ... (as required)
// returns positive identification number for the device or < 0 if error
int libdemux_open(int adapterNo, uint8 channelId, int flags);

// close the demux device with identification number fd, please use this instead
// of calling close(fd); directly, fd might not always be a file descriptor on
// all supported platforms
void libdemux_close(int fd);

// start a preset demux filter on device with identification number fd
int libdemux_dmx_start(int fd);

// stop a demux filter on device with identification number fd
int libdemux_dmx_stop(int fd);

// set buffer size for a demux device
void libdemux_set_buffer_size(int fd, uint32 bufferSize);

// set a new demux filter, the demux filter (dmx_sct_filter_params_t) is of
// LinuxTV API 2 type (the native type to Dreambox and dbox2 cvs rel branch)
// see above for a declaration of dmx_sct_filter_params_t
int libdemux_dmx_set_filter(int fd, dmx_sct_filter_params_t *flt);

// read from a demuxer, please use this instead of calling read(fd, ...)
// directly, fd might not always be a file descriptor on all supported
// platforms, also, libcamdio for Triple Dragon tries to mimic the DMX_ONESHOT
// option of the LinuxTV API, for which the TD doesn't seem to have native
// support, but this only works, if you use this call to read
ssize_t libdemux_read(int fd, void *buffer, size_t size);
// tells the camd, if it should do its own pmt update watch, if 0 is returned,
// camd can rely on getting calls to camd_service_update automatically when
// the pmt changes, if 1 is returned, camd must monitor the pmt for updates by
// itself
uint8 libdemux_pmt_update_watch();

/* cadev related functions */

// open the conditional access device
// adapterNo: for i386 only, if on a Linux server, you have more than one
// DVB-S card, you can pick the one to use, this applies only to Linux PC's,
// for all currently known Linux set-top-boxes (dbox2, Dreambox, TD), this is
// always 0
uint8 libscce_open(int adapterNo);
// close the conditional access device
void libscce_close();
// informs the camd, if it needs to provide a list of elementary pids
// (vpids+apids) in combination with the control words for successful
// conditional access device operation, returns 1, if elementary pids
// are needed, returns 0, if not needed
uint8 libscce_need_elempids();
// set control words and elementary pids to decode, the ecmpid that your
// camd was using to obtain the control words is important: libcamdio.so (on
// Dreambox at least), does a fancy resource administration of descrambler
// slots in the ca devices, the ecmpid is necessary to decide when to use
// a new slot or when to reuse an existing slot
// cw = byte array (16 elements) with the control words, even first, then odd
// pidlist = 16-bit array with the elementary (video/audio pids) this control
// word is to be used on
// noPids = number of elements in the pidlist array
// returns < 0 if error
int libscce_cw_elempid_set(uint8 channelId, uint16 ecmpid, uint8 *cw, uint16 *pidlist, uint8 noPids);
// returns the maximum number of services that can be decoded simultaniously
uint8 libscce_number_of_channels_capability();
// returns the maximum number of descrambler slots on conditional access
// device caDevIdx, this is for information only, libscce_cw_elempid_set will
// automatically return -1 if you try to set to many control words at the same
// time
uint8 libscce_cadev_number_of_slots(uint8 caDevIdx);

#endif
