Installation

These instructions apply to the official March 31st 2005 image. The first two
steps require you to repack the squashfs filesystem on /dev/mtd/2.
1. make a new directory /var/bin, copy /stb/bin/run-dvb2001 to /var/bin,
   finally replace /stb/bin/run-dvb2001 by a softlink to the copy in /var/bin
2. replace /stb/lib/dvb2001/libembCA.so by a link to /var/lib/libembCA.so
3. copy the necessary binaries newcamd, cardserver, etc to /var/bin
4. make a new directory /var/lib and copy libcrypto.so.0.9.7, libcamdio.so.0
   (for Triple Dragon) and libembCA.so to it
4. make a new directory /var/tuxbox/config/newcamd and copy the necessary
   config files to it, edit the config files for your setup
5. make a new directory /var/tuxbox/scce and copy and edit the necessary key
   files
6. edit /var/bin/run-dvb2001 to start the binaries in /var/bin before starting
   dvb2001


libcamdio.so for Triple Dragon

- to be used together with libembCA.so
- does NOT work on 2004 images and older (tested on March 31st 2005 image)
- does support decoding of one channel at a time only, no elementary pids
  are necessary
- no OSD, the OSD api functions exist of course, but do nothing
- pmt update watch is done by dvb2001, camd will be updated each time
  the pmt changes
- support for both internal cardreaders (0=upper, 1=lower)
- no CI slot support
- serial port might work (2), but it's rather difficult to remove all other
  applications that use it (getty etc), so it's really untested
- usb->rs232 might work (SERIAL_PORT = 3 and higher) but untested
- sid, and real pmt are given to camd_service_add/update, pmtpid and apid
  will always be 0, because dvb2001 does the pmt update watch the actual
  pmtpid is not really needed by the camd, if for some reason you need it
  anyway, your camd has to demux the pat and extract the pmtpid from there
  and the sid parameter.
- because the Triple Dragon has the really nasty habit of powering down the
  internal cardreaders when in standby mode, a couple of additions were
  necessary for cardserver/betad: when starting those, you'll only get a
  message, that the cards will not be powered up until cardserver is told to
  do so, powerup is done when during its startup dvb2001 loads libembCA.so,
  the cards are powered down each time dvb2001 unloads libembCA.so (for
  example when going into soft-standby) and powered up and reinitialised
  each time dvb2001 loads libembCA.so (when coming out of soft-standby),
  unfortunately, because of this, the cards in the internal cardreaders of the
  Triple Dragon can not be accessed from other STBs via network while the
  Triple Dragon is in soft-standby
- One other particular problem is the Triple Dragon always sending the pmt
  of a harddisk recording to libembCA.so during playback of that recording, we
  don't really know, why dvb2001 is doing that. Decryption apparently is done
  while recording, so the recording doesn't need decryption when being played
  back, so what is dvb2001 sending the pmt of the recorded service for? Anyway,
  our libembCA.so is doing its best to ignore those. However, there's one
  additional bug when using timeshift: dvb2001 as usual in harddisk playback
  sends the pmt of the recorded stream but it stops to send any pmt updates from
  the live stream that is being recorded. This means that decryption will fail
  during timeshift, if the channel changes ecm pids, adds or removes CA systems
  or switches from fta mode to encrypted. There is nothing we can do about it
  the Triple Dragon developers have to change this incorrect behaviour of
  dvb2001. To give everyone the opportunity to adapt libembCA.so to any changes
  the Triple Dragon developers might make in the communication between dvb2001
  and libembCA.so, we've included the source code to our libembCA.so. You'll
  never know, maybe someone even makes support for the CI slot :)
