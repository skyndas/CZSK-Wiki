Official release newcamd v6.10

check recent.txt for answers to questions asked recently in forums

please use drivers and libs from the last full release 6.08

-------------------------------------------------------------------------------

Some news services indicated the European Union thinking about forcing Pay-
TV providers to offer their services beyond national borders to anyone who wants
a subscription. We strongly support such a move and we pledge that the emu and
cardsharing facilities in newcamd would be discontinued if Pay-TV providers
would start to offer their services internationally under the same conditions
they offer it to national residents. In particular:

1. same choice and contents of all channel packages (no stripped-down
international subscriptions like Digiturk Euro).
2. same prices as for national customers

It was never the intention of the newcamd Team that people would use it to steal
the services of their national Pay-TV provider (or any other provider they could
officially subscribe to). If and when everyone would be able to officially
subscribe to any Pay-TV package he wants to, under the same conditions as
everyone else and regardless of where he lives, we would feel newcamd becoming
kind of obsolete. The only reason why we make newcamd support emu and card
sharing is to overcome this discrimination by Pay-TV providers to offer official
subscriptions to national residents only.

-------------------------------------------------------------------------------

Welcome to newcamd V6

This package is freeware. Distribution and usage is allowed only if you
agree and comply to the following rules:

1. For standalone (outside of flash images) distribution, you are NOT allowed
to make any changes to the original ZIP archive whatsoever. Distributions of
newcamd must not include any keys or Nagra ROMs.
2. Distribution of newcamd inside flash images is allowed, if no keys or
Nagra ROMs are included in the same flash image. Full documentation must be
provided in the flash image. Files keylist, rsakeylist, tpscrypt, ppua,
readme.txt and nagraAU.txt must be present in /var/tuxbox/scce
(/var_init/tuxbox/scce on Dreambox 7000), files newcamd.conf, cardserv.cfg and
betad.cfg must be present in directory /var/tuxbox/config/newcamd
(/var_init/tuxbox/config/newcamd on Dreambox 7000).
Files in scce must be copied from the original Zip archive, they may not be
changed. Options in config files may be changed, but all the comments must be
left unchanged.
3. Distribution of patched newcamd, cardserver, betad and/or dcd binaries is
strictly prohibited.

Dieses Paket ist Freeware. Weiterverbreitung ist nur unter Einhaltung der
folgenden Regeln gestattet:

1. Das Original ZIP Archiv darf NICHT veraendert werden. Insbesondere duerfen
keine Keys oder Nagra ROMs enthalten sein.
2. Die Weiterverbreitung in Flash-Images ist nur erlaubt, wenn keine Keys oder
Nagra ROMs im Image enthalten sind. Die komplette Dokumentation muss im Image
vorhanden sein. Die Dateien keylist, rsakeylist, tpscrypt, ppua, readme.txt
und nagraAU.txt muessen in unveraenderter Form ins Verzeichnis /var/tuxbox/scce
im Image kopiert werden (/var_init/tuxbox/scce in Dreambox Images), die Dateien
newcamd.conf, cardserv.cfg und betad.cfg muessen ins Verzeichnis
/var/tuxbox/config/newcamd (bzw. /var_init/tuxbox/config/newcamd bei Dreambox
Images) kopiert werden. Konfigurationsoptionen duerfen angepasst werden, aber
die Kommentare muessen unveraendert bleiben.
3. Die Weitergabe von gepatchten newcamd, cardserver, betad und/oder dcd
Binaries ist ausdruecklich untersagt.

What new in V6?

We've introduced a documented, set-top-box independent api. This way, the 
newcamd binary has become independent of the set-top-box it is running on.
All the set-top-box dependent i/o calls (to the demuxer, ca or cardreader
device) have been placed into a shared library libcamdio.so. This way, you
are able to use the same newcamd binary on (currently) dbox2, Dreambox and
(new!) Triple-Dragon. All you have to do is pick the correct libcamdio.so
library for your box to go with the generic newcamd binary.

The api itself is documented for other camd developers. That means, other
camd developers, that choose to use the api, can implement their camd on
one of the supported set-top-box and their binary will automatically be
working on the other supported STBs as well. 

But that's not all, if some new linux based STB is released in the future,
independent developers can write their own libcamdio.so for the new STB,
and newcamd as well as all the other emus, that use this api, will
automatically run on their box, without the need to change anything in
the newcamd (or other camd's) binary. Of course only as long as the new
STB uses the same processor architecture for which a camd binary is already
available, but even if it's not, it's much easier just request to compile
a binary for a different processor architecture than to request a whole
bunch of little changes to support the new STB's demux or ca dev apis.

For api documentation see file libcamdio/libcamdio.h


History:

v6.10: cryptoworks emu
       keys needed in keylist and for providers with superencryption in
       rsakeylist

v6.09: nagra2 au
       cardserver conax: add dump of ppv events on entitlement port

v6.08: newcamd: 3des algo for nagra2 polsat
       cardserver/cardspider: fix bug with missing Seca2 idents on some cards
       dyndnscd: improved version

v6.07: newcamd: "fix" showing of "can't decode" message, we actually wanted to
                show it all the time in v6.06, because when there's no picture,
		the message don't hurt anybody, however, we didn't realize,
                people using ci cams in parallel to newcamd (we don't really
		know why, using cardserver/betad would have many advantages over
		using a cam), anyway, OSD_TIMEOUT = 0 know suppresses all
		messages again, OSD_TIMEOUT = 1 will show "Can't decode"
		messages only, any value >1 will show all messages
       libcamdio.so: (Dreambox) complete rewrite of the .listen.camd.socket and
                     camd.socket code, see readme for details

v6.06a: newcamd: allow multiple tpscrypt2 keys in tpscrypt file, all of them
		 must have the same key index:
		 007c00:01:01 02 ... (key1)
		 007c00:01:11 12 ... (key2)
		 ... (more keys)
		 there is no new binary for newcamd, this update is already in
		 the v6.06 version, we just forgot to mention it
		 there will be no client to update tpscrypt keys over the
		 internet, you never know, who runs such a server (could be TPS
		 themselves, collecting IP addresses), and if you don't want to
		 learn how to use a text editor to add keys to the tpscrypt file
		 then newcamd is for you anyway

v6.06: newcamd: behaviour when requested to decrypt two channels at once changed
                will now continue to decrypt the recorded channel instead of
                starting to decrypt the new (2nd) channel
       newcamd: fix swapped control words for MTV+VH1 ESP
       newcamd: fix Cabo AU nagra1
       newcamd: fix nagra2 ecm nano parser for Cabo
       cardserver: err, changed something weeks ago, forgot what exactly
       libcamdio.so.0: (Dreambox) tries to get current channel from
                       /tmp/.listen.camd.socket when first starting
		       this means newcamd starts to decrypt immediately
		       when started after enigma (or later restarted)
		       needs cvs image compiled Dec 26th, 2005 or later 

v6.05: cardserver: fix viaccess class entitlement dump
       cardspider: fix a particular nasty bug, that occasionally caused control
                   words to be matched to a different ecm request than they
                   originated from, this might have caused occasional black
		   screens, emergency shutdown requests or in very rare
		   circumstances segfaults in cardspider (obviously they must
		   have been very rare, because noone ever complained about
		   them)
       cardspider: changed strategy when local users access local cards through
                   spider, these will now be preferred using user id as the sort
                   key and will be handled before any ecm requests coming from
		   external peers
       cardspider: added ECM_RESEND feature, if after 3-4 seconds cardspider
                   hasn't received a response to an ecm request, it will repeat
		   the request to external peers, this is intended to smooth
		   over the unreliableness of the udp protocol, but it might
		   increase the data rate used, if you are concerned about this,
		   the old behaviour can be restored by setting ECM_RESEND = no
                   in cardspider.cfg
       cardspider: update avoidDropoutsHowto.txt, this is REQUIRED READING if
                   you want to run a stable network

       although, we have not increased the protocol version number in this
       release of cardspider which would've made it incompatible with the older
       versions, we ABSOLUTELY RECOMMEND to upgrade everyone in your network
       immediately, especially because of the bug fix above

v6.04: cardserver: "Auto-PIN" for Conax cards
       newcamd: Canal Digitaal code added, Motors TV and Mezzo only
       newcamd: priority feature completely rewritten, needs changes in
                config file /var/tuxbox/scce/priority
       newcamd: Cabo AU fix
       newcamd: fix a bug in the config file parser regarding CWS options

v6.03: newcamd: new feature "constant" control word
       some channels (BISS encrypted for example) use always the same
       control word, these can now be set /var/tuxbox/scce/constantcw
       libcamdio.so for Dreambox: add a workaround for the "no picture after
                                  newcamd restart" problem
       ppua: new syntax for this keyfile, newcamd will convert old files
             automatically
       cardserver: add an "Auto-PIN" feature for Cryptoworks cards, new option
                   CARD_PIN in cardserv.cfg, please read the warning in
                   cardserv.cfg about what happens when you enter an incorrect
                   pin code

v6.02: move all config files to its own directory
       /var/tuxbox/config/newcamd for ppc versions
       /etc/newcamd               for i386
cardserver: improve entitlement dump for Cryptoworks cards
newcamd.conf: changed meaning of the passive option in CWS lines,
              newcamd will not connect to these servers when first
              started, but will connect when receiving a wanon command
              from camdcmd and the connection is configured "wan"
newcamd: added Digital+ Nagra2 (1801) emu support, enter keys in
         /var/tuxbox/scce/keylist
         /var/tuxbox/scce/rsakeylist
removed DMM7020 ipk, nobody was using them anyway

v6.01:

cardserver/cardspider/camdcmd: add swap services command
newcamd: polsat nagra rom 10 fix, delete old /var/tuxbox/scce/strom3.bin and
         put /var/tuxbox/scce/strom.bin into your image (the file is modified)
newcamd: increase timeout value for getting nds control words, shouldn't logout
         anymore from the server while recording, if the server manages to reset
         the card, internal optimations in newcamd done for it, because the
         timeout is now greater than the time between different ecms arriving
         from satellite
         will still logout from betad, if it doesn't manage to reset the card, 
         done to protect your card from damage!
newcamd: some other optimations
cardserver/viaccess: stop switching back and forth of current ident when EMMs
                     are blocked
Dreambox/libcamdio.so: added autodetection of the number of internal cardreaders

v6.00b: fixed i386 card servers

v6.00:
all binaries: use libcamdio - check for config files, especially newcamd.conf,
              a lot of the old options don't exist any longer
all binaries: support Triple-Dragon
cardserver/cardspider: improve ecm handling, on old versions it was possible
                       for one cardspider client to cause dropouts for all
                       others, when zapping very fast (each zap would have 
                       sent a new ecm request to the cardspider network,
                       possibly blocking requests from others), now new
                       request are sent only after 3 seconds or after the last
                       request from the same client is answered, whatever event
                       occurs first
cardspider: increased the protocol version number, so that network admins can
            force all participants to upgrade to the improved version
cardserver.dreamTriple: add powerup/powerdown modes for Triple Dragon, see
betad.dreamTriple:      readme in the libcamdio/TripleDragon directory
betad: added NDS for Sky Italia and BSkyB
newcamd: changed the path for the scce directory from /var/scce to
         /var/tuxbox/scce (/var/scce would be in the ram disk on Dreambox 7020)
         added via2.4 algo
cardserver/Conax: fix handling of cards that have some maturity rating enabled,
                  cardserver still answers "Can't decode" on protected channels,
                  because there is no way for the user to enter the pin and send
                  this information back to cardserver, but contrary to the old
                  version, at least the card will continue to work now on all
                  unprotected channels after zapping over a protected channel
scce/ecmoverride: removed pmt pid from the config lines
scce/mappings: added mapping for Seca2 SCT

Installation for Triple Dragon:
Please see the readme in the libcamdio/TripleDragon directory.

Installation for other STB's:

Copy newcamd.conf to /var/tuxbox/config/newcamd (dbox2/Dreambox) or
/etc/newcamd (i386).
Copy lib/libcrypto.so.0.9.7 to /lib or /var/lib directory
Copy the correct libcamdio.so.0 for your box to /lib or /var/lib
Check the config file and alter it for your needs.
Copy keylist, rsakeylist, ppua, tpscrypt, priority, mappings, nagra*.bin to
/var/tuxbox/scce
Enter keys into the keyfiles.
For i386 install DVB-S driver with changed root file.
Dreambox & dbox2 don't need an additional driver. 

dbox2 users should deactivate hardware section filtering on API3 drivers, for
some reason, which illudes me, the demuxer keeps crashing from time to time
when using newcamd with hardware section filtering turned on.

Changes to Zapit/Enigma:

No changes are necessary in recent Zapit or Enigma sources. Just use newcamd
instead of camd2 or dccamd. In fact newcamd is designed specifically for use
with unchanged zapit/Enigma. Any complaints about newcamd problems when running
in so-called emu images which feature other emus will be ignored. If newcamd
works with unchanged zapit/enigma, it works period. Everything else is the
problem of the image builders.

Killing newcamd

This seems to be a big problem, from what I can read in certain Internet
forums (Posts like "newcamd never saves any AU keys", well if you kill it
with the -9 option, you're not giving newcamd a chance to save anything).
So, this is, how it's done right: newcamd, during startup, always creates a 
file /tmp/newcamd.pid. Kill that pid (pid = process id) and newcamd will
shut down orderly. For example: kill `cat /tmp/newcamd.pid`

vdr-Anpassung:

Mitgeliefert wird ein Patch fuer szap aus dem linuxtv-dvb-1.0.1.tar.gz
Treiberpaket. Die darin enthaltenen camd_stop() und camd_start() Routinen
koennen auch in den vdr uebernommen werden. Saemtliche Funktionalitaet, die
auf das ca-Device zugreift, ist im vdr zu deaktivieren, newcamd benoetigt
exklusiven Zugriff auf das ca-Device. Anstatt der PMT Pid kann auch 0
uebergeben werden, da mein vdr Beta-Tester meinte, die PMT Pid sei an der
Stelle im vdr Code, an dem man den newcamd nach dem Zappen starten moechte,
etwas schwierig zu ermitteln. In diesem Fall versucht newcamd die PMT Pid aus
der Transponder PAT anhand der uebergebenen Service Id zu ermitteln. Nicht
vergessen, einen Treiber mit gepatchtem Root File zu verwenden.

mehrere DVB-S Karten:

Ist mehr als eine DVB-S Karte im Rechner eingebaut, muss fuer jede Karte ein
eigener newcamd gestartet werden. Fuer diesen Fall kann in der Kommandozeile
Pfad+Name des newcamd.conf Files und die Adapternummer angegeben werden (0-3).
"newcamd /etc/newcamdAdapter1.conf 1" startet zum Beispiel einen newcamd fuer
die zweite Karte im Rechner und nutzt /etc/newcamdAdapter1.conf als Konfigfile.
Angesprochen werden die einzelnen newcamd dann ueber /tmp/camd.socket0 bis
/tmp/camd.socket3 (siehe szap Patch).

Faq:

Question: On Dreambox cardserver never (or seldom) detects inserted cards.
I have to reboot box with cards inserted for cardserver to detect anything.
Answer: Early Dreambox mainboards have a design flaw, resistances R5003 and
R5007 have been fitted with 10 kOhm resistances instead of the correct 2.2 kOhm
resistances. You need to replace them both with the correct ones. You find them
just behind the card readers.

Question: Why is there no (or: Will there ever be) emu for Neotioncrypt porn
channels?
Answer: No. Those porn channels can be subscribed from every country, so bugger
off :) (maybe first take a look at newcamd policies at the top of this file)

Question: Why is the NDS support in betad only for BSkyB and Sky Italia? I
live in America/Australia and would like support for our local providers too.
Answer: Unfortunately all NDS cards from different providers use different 
communication parameters (different ATRs, different baudrates, etc). We don't
have NDS cards from your provider, so we can't implement them. Also the EMM
handling seems to be different for different NDS systems. We can't make newcamd 
support systems, we can't receive.

Question: Our Romanian Conax card doesn't work with cardserver, apparently the
ATR is different from other cards and cardserver doesn't recognize it.
Answer: We've actually read such postings on satellite tv related boards. While
it is nice, that you've noticed some difference, we never saw any posting
talking about what exactly the difference is. Without posting a log of the card
being used in a working cam or stb (and make sure to include all from ATR to
the first ECM and EMM being sent, but remove your card number), it's the same
problem as in the FAQ above. We don't have the card and without any logs we
surely can't and won't implement it.

Question: Can you add something like reverse lookup for users that is based on
DNS to verify the user is who he says he is?
Answer: No. Such a feature does not increase security whatsoever. Any user,
who can share his cardserver access account with other people, can just as 
well share username/password of a dyndns account with other people. Since
those accounts are free, they can even create an extra account for that very
purpose. So, trying to check the identity of a user by doing a DNS lookup really
is useless, it just wastes network bandwidth.

Question: Can you create a client that is based on PC that drives Season
interface?
Answer: No. Why not? Because we don't personally use it. That's why we made the
protocol specification available. You can program such a client yourself, if you
need it, all the necessary information is available.

Question: After a connection to a card server is lost, I have to restart
newcamd to reestablish it. This sux. Do something about it!
Answer: No, we won't. YOU do something about it! There is camdcmd provided
in the official newcamd.zip distribution, the wanon command will do exactly
that, rebuild all the connections that are designated as "wan" in newcamd.conf
(cardserv.cfg, cardspider.cfg). Start using it! Go make a plugin if calling it
via telnet is too much to ask.

Question: But, I want it to reconnect automatically without user interaction.
Answer: That makes no sense. newcamd<->cardserver uses the tcp protocol,
which means, if a connection is lost, there is something seriously wrong with
your network between newcamd and the cardserver. So an immediate reconnect would
almost certainly fail. A reconnect attempt after say X minutes makes no sense
either, the user will have long zapped to another channel or attempted the
reconnect manually by then. And if you did record something unattended it
certainly makes no difference, if only X minutes or the whole remaining
part of the program are lost. The recording is screwed up either way.
Bottom line, there will be no automatic reconnect for direct newcamd to
cardserver connections.

Question: But, if I restart cardserver, I always have to restart newcamd as
well or use camdcmd to reconnect.
Answer: No, you don't. Setup reverse login for the cardserver<->newcamd
connection.

Question: You're a bunch of idiots, I still WANT my automatic reconnect.
Answer: Then use cardspider to bridge the connection that logs out all the
time. cardspider does attempt to reconnect to peers, but only after ALL peers
are lost (offline). It also uses udp protocol which means in bad internet
connections, you will loose only single control words, but not the connection,
the picture will come back after the communication between the peers works
again.

Question: If I connect a Phoenix interface to the serial port of my Dreambox
7020, the box won't boot any more, it always stops, the display reads 
"*** SERIAL MODE ***".
Answer: We've tracked this behaviour to the 2nd stage bootloader, since its
source is available, we're sure, someone will patch it sooner or later :)

Frage: Gehen mit cardserver die neuen Premiere oder Dreamcrypt Karten?
Antwort: Nein. newcamd enthaelt auch weiterhin keinerlei Funktionen, die das
Entschluesseln von Premiere ohne gueltiges Abo ermoeglichen, also auch kein
Control Word Sharing ueber Internet fuer Premiere. Gleiches gilt auch fuer
Dreamcrypt. In der dbox2 werden die neuen Premiere Karten selbstverstaendlich
im normalen CAM unterstuetzt.

Frage: Wie kann ich dann mit der Dreambox oder einer DVB-S Karte und vdr mein
Premiere Abo nutzen?
Antwort: Es gibt eine spezielle betad Version, die die neuen Premiere Karten
unterstuetzt. Diese kommuniziert im Gegensatz zu cardserver nicht ueber
TCP/IP. Also auch hier kein Control Word Sharing ueber Internet.

Frage: Welche Kartentypen werden von betad unterstuetzt?
Antwort: Getestet wurde betad mit S01 und S02 Karten. Prinzipiell sollten alle
01er und 02er Typen funktionieren, also auch K01, K02, P01, P02, A01, A02.
betad ist nicht geeignet fuer die 03er Kartentypen S03, K03, P03, A03.

Frage: Kann ich mit Hilfe von betad und Multicam auch eine S01 (K01, P01, A01)
Karte an der dbox2 benutzen?
Antwort: Ja.

Frage: Ich habe zwei Premiere Abos mit unterschiedlichen Paketen. Kann ich diese
kombinieren?
Antwort: Ja. Mehrere betad auf unterschiedlichen seriellen Ports starten und
alle Server in newcamd.conf anmelden (uds 0, uds 1, ...). dbox2: Erste Karte
in dbox CAM einlegen, zweite Karte in Multicam mit betad.

Frage: Ich habe ein Premiere Abo und meiner Bekannter hat ebenfalls eins, beide
mit unterschiedlichen Paketen. Kann ich diese kombinieren?
Antwort: Nein, siehe "Gehen mit cardserver die neuen Premiere Karten?".

Frage: Wenn ich ein Phoenix an die serielle Schnittstelle anschliesse, bootet
die dbox2 nicht mehr, im Display sind die Inforamtionen vom Debug Modus und
volle Balkenzahl zu sehen.
Antwort: Das ist eine Debug Funktion des Beta Research Bootloaders. Wenn beim
Booten bestimmte Pegel an der seriellen Schnittstelle anliegen, wird der
Bootvorgang angehalten. Mir ist keine Abhilfe bekannt, ich empfehle daher den
Standby-Modus von Neutrino oder ein MultiCam, falls noch nicht vorhanden.
+-+-+-+-+-+-+-+-+-+-+ +-+-+-+-+  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|D|o|w|n|l|o|a|d|e|d| |f|r|o|m|  |w|w|w|.|R|D|I|-|d|r|e|a|m|b|o|x|.|c|o|m|
+-+-+-+-+-+-+-+-+-+-+ +-+-+-+-+  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+