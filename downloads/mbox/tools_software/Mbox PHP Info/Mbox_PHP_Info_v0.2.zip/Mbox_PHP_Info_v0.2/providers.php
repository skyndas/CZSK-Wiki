<?php 
include('protector.php');
include('header.php');
?>
<style type="text/css">
<!--
.style2 {color: #000000}
-->
</style>

  <p class="style2" style="margin-left: 20"><font face="Arial" size="4">Providers available</font></p>
  <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">
  
  <table width="80%"  border="1" cellpadding="0" cellspacing="0" align="center">
  <tr bgcolor="#CCCCCC">
    <td width="17%"><div align="center">ID</div></td>
    <td width="16%"><div align="center">CAID</div></td>
    <td width="53%"><div align="center">Name</div></td>
    <td width="14%"><div align="center">Cards</div></td>
  </tr>
<?php
if (file_exists($info_path.'share.info') && file_exists($file_path.'ident.info'))
{
   $cards = read2array($info_path.'share.info');
   unset($cards[count($cards)-1]);
   echo "<h4><div align=\"center\">".count($cards).' cards online.</div></h4>';

   foreach($cards as $card){
     $elms = explode(' ',$card);
	 $provs[$elms[5]]['id'] = $elms[5];
	 $provs[$elms[5]]['cnt']=$provs[$elms[5]]['cnt']+1;
   }
   $ident = read2array($file_path.'ident.info');
   unset($ident[count($ident)-1]);
   foreach ($ident as $id){
     $names = explode(';',$id);
     $ids[$names[0]]['id'] = $names[0];
     $ids[$names[0]]['name'] = $names[1];
   }
   if (empty($provs)){
     echo "<tr><td colspan=4><div align=\"center\">No providers found.</div></td></tr>";
   }
   foreach($provs as $prov){
   //print_r($prov);
   echo "<tr>";
    echo "<td><div align=\"center\">".substr($prov['id'],4)."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".substr($prov['id'],0,4)."&nbsp;</div></td>";
	if (isset($ids[$prov['id']]['name']))
    echo "<td><div align=\"center\">".$ids[$prov['id']]['name']."&nbsp;</div></td>";
	else
    echo "<td><div align=\"center\">&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$prov['cnt']."&nbsp;</div></td>";
   echo "</tr>";

   }
}
else
  echo "<tr><td colspan=4><div align=\"center\">The files 'share.info' and/or 'share.onl' were not found.</div></td></tr>";
  ?>
  </table>
  </font></p>

&nbsp;
&nbsp;
&nbsp;
&nbsp;
      
<?php 
include('footer.php'); 
?>
