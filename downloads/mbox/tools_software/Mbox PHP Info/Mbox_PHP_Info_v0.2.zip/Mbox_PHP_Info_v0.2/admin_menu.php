<div align="center"><STRONG>&nbsp;&nbsp;
  <a class="menu" href="index.php" target="_self">Home</a>&nbsp;&nbsp; |&nbsp;&nbsp; <a class="menu" href="peers.php" target="_self">Peers</a>&nbsp;&nbsp; |&nbsp;&nbsp;
  <a class="menu" href="cards.php" target="_self">Cards</a>&nbsp;&nbsp; |&nbsp;&nbsp; <a class="menu" href="providers.php" target="_self">Providers</a>&nbsp;&nbsp; |&nbsp;&nbsp; <a class="menu" href="editor.php" target="_self">File Editor</a>&nbsp;&nbsp;
  |&nbsp;&nbsp; <a class="menu" href="shell.php" target="_self"> </a>
  <?php if ($_SESSION['logged'] == 'true') { ?>
  &nbsp;&nbsp; <a class="menu" href="logout.php" target="_self">Logout</a>&nbsp;&nbsp;
  <?php }?>
</STRONG></div>
