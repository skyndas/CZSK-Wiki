<?php 
include('protector.php');
include('header.php');
?>
<style type="text/css">
<!--
.style4 {font-size: 14px; }
.style9 {font-size: 14px; font-weight: bold; }
-->
</style>

<blockquote>
  
</blockquote>
<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="20%" valign="top">

<h4 align="left" class="style4">Mbox Config </h4>
<h5 align="left" class="style4">
<a href="editor.php?file=cwshare.cfg" target="_self">- cwshare.cfg</a><br>
<a href="editor.php?file=mbox.cfg" target="_self">- mbox.cfg<br />
</a><a href="editor.php?file=softcam.cfg" target="_self">- softcam.cfg</a><br>
<a href="editor.php?file=ignore.list" target="_self">- ignore.list<br />
</h5>
</td>
<!--<td width="15%" valign="top"><h4 align="left" class="style4">Mbox keys </h4>
  <h5 align="left" class="style4">
<a href="editor.php?file=nagra" target="_self">- Nagravision</a><br>
<a href="editor.php?file=crypto" target="_self">- Cryptoworks</a><br>
<a href="editor.php?file=nds" target="_self">- NDS</a><br>
<a href="editor.php?file=irdeto" target="_self">- Irdeto</a><br>
<a href="editor.php?file=seca" target="_self">- Seca</a><br>
<a href="editor.php?file=tps" target="_self">- TPS</a><br>
<a href="editor.php?file=via" target="_self">- Viaccess</a><br>
<a href="editor.php?file=conax" target="_self">- Conax</a><br>
</h5></td>-->
    <td width="60%" valign="top"><p class="style9">Others </p>
      <p class="style9">
      	
  <!--<a href="editor.php?file2=atack.txt" target="_self">- atack.txt</a><br />-->
  <a href="editor.php?file2=debug.txt" target="_self">- debug.txt</a><br />
 <!-- <a href="editor.php?file2=online.log" target="_self">- online.log</a><br /> 
<!--  <a href="editor.php?file2=share.log" target="_self">- share.log</a><br />  -->
  <a href="editor.php?file2=stat.info" target="_self">- stat.info</a><br /> 
  <a href="editor.php?file2=share.info" target="_self">- share.info</a><br /> 
  <a href="editor.php?file2=share.onl" target="_self">- share.onl</a><br /> 
 <!-- <a href="editor.php?file2=sc.info" target="_self">- sc.info</a><br /> -->
  <a href="editor.php?file=ident.info" target="_self">- ident.info</a> 
</p></td>
    <td width="5%">&nbsp;</td>
  </tr>
</table>

<div align="center">
  <blockquote>
    <p>
      <?php
 if (isset($_POST['Submit2'])) {
    $data = $_POST['text1'];
	$file_np = $_POST['filename'];
	$file = $file_path.$_POST['filename'];  
   if (isset($_POST['site']) && $_POST['site']==1) {	$file = '../'.$_POST['filename'];  };
    if (!$file_handle = fopen($file,"w")) { echo "<h6>Erro opening file $file_np. Check permissions.\n</h6>"; }  
    if (!fwrite($file_handle, $data)) { echo "<h6>Error writing file $file_np. Check permissions.\n</h6>"; }  
     echo "<font color=\"#FF0000\" face=\"Arial\" size=\"4\">$file_np saved with success!</font>";   
    fclose($file_handle);  
 }
 if (isset($_GET['file'])){
 
   $file = $_GET['file'];
   
   {
   if (file_exists($file_path.$file)) {
   $cw = file_get_contents($file_path.$file);
   print "<h4 align=\"center\">".$file."</h4><font color='green'><b>writeable !!</b></font>";}
   else {   print "<h4 align=\"center\">File not found - ".$file."</h4>"; $cw='';}
   }
?>
    </p>
  </blockquote>
  <form id="form1" name="form1" method="post" action="<?=$_SERVER['PHP_SELF']?>">
  <div align="center">
    <p>
      <textarea name="text1" cols="100" rows="20"><?=$cw?></textarea>
    </p>
    <p>
      <input name="site" type="hidden" value="<?=isset($_GET['site'])?>">
      <input name="filename" type="hidden" value="<?=$file?>">
	  <input type="submit" name="Submit2" value="Save" /> 
    </p>
  </div>
</form>
<p>&nbsp;</p>
</div>
<?php
} 

?>

<?php
 if (isset($_POST['Submit3'])) {
    $data2 = $_POST['text2'];
	$file_np2 = $_POST['filename2'];
	$file2 = $info_path.$_POST['filename2']; 
	  if (isset($_POST['site']) && $_POST['site']==1) {	$file = '../'.$_POST['filename2'];  };
    if (!$file_handle2 = fopen($file2,"w")) { echo "<h6>Erro opening file $file_np. Check permissions.\n</h6>"; }  
    if (!fwrite($file_handle2, $data2)) { echo "<h6>Error writing file $file_np. Check permissions.\n</h6>"; }  
     echo "<font color=\"#FF0000\" face=\"Arial\" size=\"4\">$file_np saved with success!</font>";   
    fclose($file_handle2);  
 }

 if (isset($_GET['file2'])){

   	  $file2 = $_GET['file2'];
			{
   if (file_exists($info_path.$file2)) {
   $cw2 = file_get_contents($info_path.$file2);
   print "<h4 align=\"center\">".$file2."</h4><font color='red'><b>read only !!</b></font>";}
   else {   print "<h4 align=\"center\">File not found - ".$file2."</h4>"; $cw2='';}
   }
?>
    </p>
  </blockquote>
  <form id="form2" name="form2" method="post" action="<?=$_SERVER['PHP_SELF']?>">
  <div align="center">
    <p>
      <textarea name="text2" cols="100" rows="20"><?=$cw2?></textarea>
    </p>
    <p>
      <input name="site" type="hidden" value="<?=isset($_GET['site'])?>">
      <input name="filename" type="hidden" value="<?=$file2?>">
	  <!--<input type="submit" name="Submit3" value="Save" />-->
    </p>
  </div>
</form>
<p>&nbsp;</p>
</div>
<?php
} 
include('footer.php');
?>
