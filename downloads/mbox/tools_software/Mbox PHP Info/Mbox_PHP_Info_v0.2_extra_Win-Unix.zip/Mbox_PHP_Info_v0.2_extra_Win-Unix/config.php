<?php
include("includes/functions.php");
#
#### User & Pass config for Mbox PHP Info
#
$username  = "user"; // User for PHP info
$password = "pass"; // Password for PHP Info
#
#### Cofiguration Paths
#
$gbox_path = "/bin/";
$file_path = "/var/keys/";
$info_path = "/tmp/";
#
$sitename = "Mbox PHP Info";
?>
