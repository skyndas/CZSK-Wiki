<?php require_once('config.php');?>
<html>
<HEAD>
  <TITLE><?=$sitename?> - Powered by phpGbox</TITLE>
  <META name="description" content="KaonTeam CardSharing">
  <META name="keywords" content="gbox">
 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body,td,th {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
}

a.menu {
	font-size: 16px;
	color: #0033FF;
	background-color:transparent;
}

a.menu:link {
	text-decoration: none;
	color: #FFFFFF;
	background-color:transparent;
}

a.menu:visited {
	text-decoration: none;
	color: #FFFFFF;
	background-color:transparent;
}
a.menu:hover {
	text-decoration: none;
	color:#FF0000;
	background-color:transparent;	
}
a.menu:active {
	text-decoration: none;
	color: #FFFF00;
	background-color:transparent;
}


a:link {
	text-decoration: none;
	color: #6600CC;
}
a:visited {
	text-decoration: none;
	color: #6600CC;
}
a:hover {
	text-decoration: none;
	color: #FF0000;
}
a:active {
	text-decoration: none;
	color: #6600CC;
}
body {
	background-color: whitesmoke;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a {
	font-family: Geneva, Arial, Helvetica, sans-serif;
}
.style3 {
	font-size: 32px;
	color: #FFFFFF;
}
-->
</style></HEAD>

<body>


<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="12%" bgcolor="#000000"><img src="images/logo.gif" width="120" height="120" border="0"></td>
    <td width="88%" bgcolor="#000000">
    <p align="left" class="style3"><?=$sitename?><font size="1"> by&copy; www.CW-Share.com</font></td>
  </tr>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="images/blackline.gif">
  <tr>
    <td width="100%" bgcolor="#000000" style="color:#FFFFFF">
      <?php include('admin_menu.php');?>
    </td>
  </tr>
</table>
