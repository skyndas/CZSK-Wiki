<?php
require_once('config.php');
session_start();

if (isset($_POST['login'])) {
$p = $_POST['password'];
$u = $_POST['username'];
if (($p == $password) && ($u == $username)) {
$_SESSION['logged']='true';
header('Location: '.$_SERVER['PHP_SELF']);
}}

 if (($_SESSION['logged'] == 'false') || (!isset($_SESSION['logged']))){
header('Location: login.php');
}

?>