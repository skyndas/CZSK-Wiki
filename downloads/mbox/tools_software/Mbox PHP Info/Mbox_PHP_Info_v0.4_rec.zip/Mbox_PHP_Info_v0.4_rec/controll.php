<?php 
include('protector.php');
include('header.php');

?>


<style type="text/css">
<!--
.style1 {color: #000000}

TEXTAREA {
 background-color: #0B0080;
 color: #E6FF00;
 font-family: Arial;
 font-size: 11px;
 padding: 10px;

}

-->
</style>
<p class="style1" style="margin-left: 20"><font face="Arial" size="4">Mbox process control</font></p>
<p style="margin-left: 20">&nbsp;</p>
  <font face="Arial" size="4" color="#000000">
  <blockquote>
  <div align="center">
    
    <?php 
    	
### ACTIONS ###
		//Start

if (isset($_POST['action'])) {
	$action = $_POST['action'];
		if ($action == 'Start') {
				error_reporting(E_ALL);
				$fp=pfsockopen( "".$box_IP."",23, $errstr, $errno, 5);
				if (!$fp) {
			   echo "$errstr ($errno)<br />\n";
			   }else{
				fputs($fp,"".$box_User."\r");
				sleep(1);
				fputs($fp,"".$box_pass."\r");
				sleep(1);
				fputs($fp,"".$emuname." &\r");
				sleep(2);
				fputs($fp,"exit\r");
			
			
			}
			fclose($fp);
			echo "<img src='images/on.jpg' border='0' /><br>Mbox started successfully...<br><br>";
			echo "<a href='controll.php'><button>Back to Info</button></a><br><br>";
			include('footer.php'); 
		}
	
	//Stop

	if ($action == 'Stop') {
		error_reporting(E_ALL);
				$fp=pfsockopen( "".$box_IP."",23, $errstr, $errno, 5);
				if (!$fp) {
			   echo "$errstr ($errno)<br />\n";
			   }else{
				fputs($fp,"".$box_User."\r");
				sleep(1);
				fputs($fp,"".$box_pass."\r");
				sleep(1);
				fputs($fp,"killall -9 ".$emuname." 2>/dev/null\r");
				sleep(1);
				fputs($fp,"rm /tmp/emu.tmp\r");
				sleep(1);
				fputs($fp,"exit\r");

			}
			fclose($fp);
			echo "<img src='images/off.jpg' border='0' /><br>Mbox stopped successfully...<br><br>";
			echo "<a href='controll.php'><button>Back to Info</button></a><br><br>";
			include('footer.php');

			}

		//Restart
			if ($action == 'Restart') {
			
			error_reporting(E_ALL);
				$fp=pfsockopen( "".$box_IP."",23, $errstr, $errno, 5);
				if (!$fp) {
			   echo "$errstr ($errno)<br />\n";
			   }else{
				fputs($fp,"".$box_User."\r");
				sleep(1);
				fputs($fp,"".$box_pass."\r");
				sleep(1);
				fputs($fp,"killall -9 ".$emuname." 2>/dev/null\r");
				sleep(2);
				fputs($fp,"rm /tmp/emu.tmp\r");
				sleep(1);
				fputs($fp,"".$emuname." &\r");
				sleep(2);
				fputs($fp,"exit\r");

			}
			fclose($fp);
			echo "<img src='images/off.jpg' border='0' /><img src='images/on.jpg' border='0' /><br>Mbox restarted successfully...<br><br>";
			echo "<a href='controll.php'><button>Back to Info</button></a><br><br>";
			include('footer.php');

			
			}
			exit();
			}
			
    
    #### INFO Mbox running
    
    		error_reporting(E_ALL);
		$fp=pfsockopen( "".$box_IP."",23, $errstr, $errno, 5);
		if (!$fp) {
	   echo "$errstr ($errno)<br />\n";
	   }else{
		fputs($fp,"".$box_User."\r");
		sleep(1);
		fputs($fp,"".$box_pass."\r");
		sleep(1);
		fputs($fp,"ps | grep [m]box > /tmp/emu.tmp\r");
		sleep(2);
		fputs($fp,"exit\r");

		echo "<div align='center'>";
		echo "Running Mbox Prozess on your System<br>";
		echo "<textarea readonly='value' name='text1' cols='80' rows='10'>";
		
		$info = file_get_contents($info_path.'emu.tmp');
		if (strlen($info) > 0){
		echo $info;
	}else{ 
		echo "MBOX IS NOT RUNNING !!!";
		}
	echo "</textarea></div>";
	}
	fclose($fp);
    
    if (!strlen($info) > 0) {print "<font color=\"#FF0000\"><b>Mbox is stopped...</b><br>";} else {print "<font color=\"#228800\"><b>Mbox is running...</b><br>";}
    
?>
    
  </div>
  <form id="form1" name="form1" method="post" action="controll.php">
    <p align="center">
      <input name="action" type="submit" id="start" value="Start" />
      <input name="action" type="submit" id="stop" value="Stop" />
      <input name="action" type="submit" id="restart" value="Restart" />
    </p>
</form>


<?php
include('footer.php'); 
?>
