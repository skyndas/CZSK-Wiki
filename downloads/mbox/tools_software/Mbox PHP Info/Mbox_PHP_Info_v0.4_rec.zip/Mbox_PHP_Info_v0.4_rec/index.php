<?php 
include('protector.php');
include('header.php');


?>
<style type="text/css">
<!--
.style1 {color: #6600CC}
.style2 {color: #000000}

TEXTAREA {
 background-color: #0B0080;
 color: #E6FF00;
 font-family: Arial;
 font-size: 11px;
 padding: 10px;

}
-->
</style>

<blockquote>
  <p class="style1" style="margin-left: 20"><font face="Arial" size="4"><span class="style2">Welcome Administrator</span></font></p>
  <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">In this PHP Info you can view some information about your Mbox and make some changes to your config files.</font></p>
  <p style="margin-left: 20">&nbsp;</p>

<?php


if (file_exists($info_path.'share.info') && file_exists($info_path.'share.onl') )
{
$cards = read2array($info_path.'share.info');
unset($cards[count($cards)-1]);
foreach($cards as $card){
     $elms = explode(' ',$card);
	 $dists[$elms[8]]['dist'] = substr($elms[8],5);
	 $dists[$elms[8]]['cnt']=$dists[$elms[8]]['cnt']+1;
	 $levs[$elms[7]]['Lev'] = substr($elms[7],4);
	 $levs[$elms[7]]['cnt']=$levs[$elms[7]]['cnt']+1;
   }
   


$peer_list = read2array($info_path.'share.onl');
unset($peer_list[count($peer_list)-1]);
foreach ($peer_list as $peer){
     $p = explode(' ',$peer);
	 if ($p[0] == '1'){ 
	 $peers[$p[3]]['status'] = $p[0];
	 }	 
}

?>

<p class="style2" style="margin-left: 20"><font face="Arial" size="4">Information Center </font></p>
<table>
    <tr valign="top">
        <td width="300" valign="top"> 
<p style="margin-left: 20"><font face="Arial" size="2" color="#000000">Gbox version: <strong><font color="#00cc33"><?=file_get_contents($info_path.'mbox.ver');?></font></strong></font><br />
Cards Online : <strong><font color="#cc0000"><?=count($cards);?></font></strong> 
<br>
Peers Online : <strong><font color="#0000cc"><?=count($peers);?></font></strong>
<br>
</td><td width="200" valign="top">
<strong>Card distances : </strong><br>

<?php
sort($dists);
foreach ($dists as $dist) {
echo "Distance <strong>".$dist['dist']."</strong> : <a href=\"cards.php?dist=".$dist['dist']."&peerselect=all&filter=OK\"><strong><u>".$dist['cnt']."</strong> cards.</u></a><br>";
}
?>


</td>
<td width="200" valign="top">
<strong>Card Level : </strong><br>


<?php
sort($levs);
foreach ($levs as $lev) {
echo "Level <strong>".$lev['Lev']."</strong> : <strong><font color='#cc0000'>".$lev['cnt']."</font></strong> cards.<br>";

#echo "Level <strong>".$lev['Lev']."</strong> : <a href=\"cards.php?level=".$lev['Lev']."&peerselect=all&filter=OK\"><strong><u>".$lev['cnt']."</strong> cards.</u></a><br>";

}
} else { echo "<font color='red'><h2>ERROR !!!</h2><br><b>Check the gbox Path Variables in config.php</b></font>"; } 
?>
	</td>
 </tr>
</table>
<?php
$ecm = file_get_contents($info_path.'ecm.info');
$pid = file_get_contents($info_path.'pid.info');
?>

</br>
<table>
    <tr>
        <td>
       
  <form id="form1" name="form1">
      <textarea readonly="value" name="text1" cols="50" rows="7"><?=$ecm?></textarea>
</form>
</td>
<td>
  <form id="form1" name="form1">
      <textarea readonly="value" name="text1" cols="70" rows="7"><?=$pid?></textarea>
</form>
 </td>
    </tr>
</table>


</blockquote>

<?php
include('footer.php'); 
?>
