#########################################################################
#																		#
#				MBOX PHP Info by Capa @ www.CW-Share.com				#
#					bugs to capa@cw-share.com							#
#																		#
#########################################################################

Mbox PhP info requires Apache web server and PHP.
you can use XAMP for Unix or Windows for example 
link -->>  http://www.apachefriends.org/de/xampp.html

In this Tool you can view some Info about your running Mbox
You can also mak some changes to your config Files...
And you be able to Start | Stop | Restart your Mbox

They are two different versions, one for connect to your
Receiver like Dreambox, Kathrein etc. or the secons version
for your Linux or Windows server where Mbox is running.
The different is, if you're using Unix or Win server you dont
need FTP connection like in "Receiver" version

#########################################################################

!!! IMPORTANT !!!
	-	since version 0.2 there are two different versions
		one for "Windows/Linux" mbox servers
		and one for mbox running on DVB Receivers

#########################################################################		

Changelog:


- v0.4
	- added "Mbox Controll", Start|Stop|Restart your softcam !!
----------------
- v0.3
	- rebuild the "File Editor" should now works fine
----------------
- v0.2
	- added some more info about cards and peers
----------------
- v0.1
	- started to convert Gbox Info to Mbox PHP Info
	
#########################################################################


INSTALL:

first step is to configure the config.php to set the correct
user und password for the PHPInfo but also for 
the FTP login into your receiver (Server version dont have this option)
Please check all variables in your config.php !!!

install apache und PHP on your PC/Webserver. best solution is on local
PC machine is XAMPP -  http://www.apachefriends.org/de/xampp.html
After installation copy MboxPHPInfo folder into webroot
In XAMMP:
WIN:  C:\Programme\Xampp\htdocs\
Unix: /opt/lampp/htdocs
start the webserver. now you can type in your browser
localhost/MboxPHPInfo/index.php	

