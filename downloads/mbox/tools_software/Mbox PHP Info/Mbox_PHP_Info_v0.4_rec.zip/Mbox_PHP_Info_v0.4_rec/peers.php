<?php 
include('protector.php');
include('header.php');
?>
<style type="text/css">
<!--
.style1 {color: #000000}

TEXTAREA {
 background-color: #0B0080;
 color: #E6FF00;
 font-family: monospace;
 font-size: 11px;
 padding: 10px;

}

-->
</style>

	

<blockquote>
  <!--<p class="style1" style="margin-left: 20"><font face="Arial" size="4">Peers List</font></p>-->
  <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">
  
  
    <table width="80%"  border="1" cellpadding="0" cellspacing="0" align="center">

  	<tr>
      <td colspan="4" align="center" bgcolor="#EDEDED" style="font-weight:bold"> ..:: LEGEND ::.. </td>
      </tr>
    <tr>
    <td width="25%" align="center"  bgcolor="red" style="font-weight:bold">OFFLINE</td>
    <td width="25%" align="center" bgcolor="#FFFF00" style="font-weight:bold">Online | No Cards</td>
    <td width="25%" align="center" bgcolor="#0000FF" style="color:#ffffff; font-weight:bold">Online | No Local</td>
    <td width="25%" align="center" bgcolor="#00FF00" style="font-weight:bold">Online | Local&amp;Virtual</td>
    </tr>
    </table>

  <table width="80%"  border="1" cellpadding="0" cellspacing="0" align="center">
  <tr bgcolor="#CCCCCC">
    <td width="9%"><div align="center"><font color="#000000" size="2" face="Arial">Mbox ID </font></div></td>
    <td width="9%"><div align="center"><font color="#000000" size="2" face="Arial">Version</font></div></td>
    <td width="31%"><div align="center"><font color="#000000" size="2" face="Arial">Domain</font></div></td>
    <td width="23%"><div align="center"><font color="#000000" size="2" face="Arial">IP</font></div></td>
    <td width="19%"><div align="center"><font color="#000000" size="2" face="Arial">Status</font></div></td>
    <td width="9%"><div align="center"><font color="#000000" size="2" face="Arial">Cards</font></div></td>
    </tr>
<?php

if (file_exists($info_path.'share.info') && file_exists($info_path.'share.onl'))
{


	
   $cards = read2array($info_path.'share.info');
   unset($cards[count($cards)-1]);

   foreach($cards as $card){
     $elms = explode(' ',$card);
	 $cid=$elms[3];
	 $provs[$cid] = $provs[$cid]+1;
	 $dists[$cid][$elms[8]] = $dists[$cid][$elms[8]]+1;
   }
   $peer_list = read2array($info_path.'share.onl');
   unset($peer_list[count($peer_list)-1]);

   echo "<h4><div align=\"center\">".count($peer_list).' peers listed.<br>';
   echo count($cards).' cards online.</div></h4>';
   
	

   foreach($peer_list as $peer){
     $p = explode(' ',$peer);
	 $peers[$p[3]]['id'] = $p[3];
	 $peers[$p[3]]['version'] = $p[4];
	 $peers[$p[3]]['domain'] = $p[1];
	 $peers[$p[3]]['status'] = $p[0];
	 $peers[$p[3]]['ip'] = $p[2];
	 $peers[$p[3]]['cards'] = $provs[$p[1]];
   }
   if (empty($peers)){
     echo "<tr><td colspan=6><div align=\"center\">No peers found.</div></td></tr>";
   }

   foreach ($peers as $peer){
   if (($peer['status'] == '0') && (!isset($peer['cards'])))
   {$status = 'OFF'; $color='#FF0000';} else {$status = 'Online'; $color='#0066FF';}

	if (isset($dists[$peer['domain']]['dist:1'])){
    $color = '#66FF00';
	} else 
	{
	if (isset($dists[$peer['domain']]['dist:2'])){
    $color = '#0066FF';}
	}
	if (!isset($peer['cards']) && $peer['status'] == '1') {$color='#FFFF00';}
    echo "<tr>";
    echo "<td><div align=\"center\">".$peer['id']."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$peer['version']."&nbsp;</div></td>";
    echo "<td><div align=\"center\"><a href=\"cards.php?dist=0&peerselect=".$peer['domain']."&filter=OK\">".$peer['domain']."</a>&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$peer['ip']."&nbsp;</div></td>";
    echo "<td bgcolor=\"".$color."\"><div align=\"center\">".$status."&nbsp;</div></td>";
	if (isset($peer['cards'])) 
    echo "<td><div align=\"center\"><a href=\"cards.php?dist=0&peerselect=".$peer['domain']."&filter=OK\">".$peer['cards']."&nbsp;</div></td>";
	else 
    echo "<td><div align=\"center\"><font size='1'>No Card</font></td>";
   echo "</tr>";

   }
}
else   
echo "<tr><td colspan=6><div align=\"center\">The files 'share.info' and/or 'share.onl' were not found.</div></td></tr>";
  ?>
  </table>
  </font></p>
</blockquote>
<?php
#####################################################################
$cw = file_get_contents($info_path.'stat.info');

?>
  <form id="form1" name="form1">
  <div align="center">
    <p>
      <textarea readonly="value" name="text1" cols="100" rows="20"><?=$cw?></textarea>
          </p>
  </div>
</form>
      
<?php 
include('footer.php'); 
?>
