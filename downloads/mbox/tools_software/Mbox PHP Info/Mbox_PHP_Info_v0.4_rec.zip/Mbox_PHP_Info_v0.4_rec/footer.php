<table border="0" width="100%" cellspacing="0" cellpadding="0" background="images/botline.gif">
  <tr>
    <td width="80%"><img border="0" src="images/botline.gif" width="41" height="12"><div align="center"><font color="#FFFFFF">Modified by <font color="red">Capa</font> - <a href="http://cw-share.com">www.CW-Share.com</a>  |  Orginal bySaTaNuKe </div><br></font></td>
  <td align="left"><font color="#FFFFFF"><b>v.0.4<b></font></td>
  
  </tr>
</table>

</body>

</html>
