<?php
include("includes/functions.php");
#
#### User & Pass config for Mbox PHP Info
#
$username  = "user"; // User for PHP info
$password = "pass"; // Password for PHP Info
#
#### Conection to Receiver
$box_IP = "192.168.178.24"; // Ip from your Receiver/dreambox
$box_User = "root"; // Receiver FTP User name / mostly "root"
$box_pass = "dreambox"; // FTP User password / dreambox/dbox/kathrein 
#
#### Cofiguration Paths
#
$gbox_path = "ftp://".$box_User.":".$box_pass."@".$box_IP."/usr/bin/";
$file_path = "ftp://".$box_User.":".$box_pass."@".$box_IP."/var/keys/";
$info_path = "ftp://".$box_User.":".$box_pass."@".$box_IP."/tmp/";
#
$sitename = "Mbox PHP Info";
#
#### Mbox Controll config 
#
$emuname = "mbox_0.4.0023" //set your softcam name like in /usr/bin/ "mbox" or "mbox_0.4.0023" or whatever version you are using
?>
