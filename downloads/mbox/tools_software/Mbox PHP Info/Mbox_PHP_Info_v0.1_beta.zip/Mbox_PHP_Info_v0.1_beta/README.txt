###################################################################
#																																	#
#									Gbox Web Controll MOD Version 0.9								#
#																																	#
###################################################################

Viele kennen sicherlich das GboxControl_win32
Da dort ach ein webinterface eingebaut ist welches sehr 
�bersichtilich und gut aufgebaut ist, habe ich es mir erlaubt :-)
es mal abzu�ndern und f�r standalon server umzubauen

Dieses PHP script ist eigentlich f�r linux server gedacht
da mir alle anderen scripte nicht gefallen und ich dieses
f�r mein linux server haben wollte
es l�uft aber genauso auf einem Win PC

###################################################################

FUNKTIONEN :

- �bersicht �ber alle user, carten, provider

- Fileeditor zu bearbeitung aller wichtigen files
	wie cwshare.cfg, gbox_cfg, ignore.list und alle anderen dateien
	Unter windows sind alle Dateien beschreibbar ( grins )
	Unter Unix gelten unsere bekkanten Dateirechte, wobei tempor�re 
	dateien meistens "readonly" sind

- hizugef�gt wurde eine m�chtige shell zu verschiedenen 
	bearbeitungen ( dateirechte beachten )

- Leider musste ich das stop/start/restart/ script rausnehmen
	da es f�r das GboxControl_win32 gecodet wurde
	Habe es zwar an Unix angepasst aber da das PHP script unter
	anderem user l�uft ist ein restarten der gbox nicht wirklich
	m�glich ohne einige sicherheitsregeln zu brechen

###################################################################

MINDESTVORAUSSETZUNGEN :

- Apache web server
- PHP 4 oder 5
- (als tipp zur erleicherung xampp/lampp )

- f�r dreambox werden apache + php f�r ppc's ben�tigt

###################################################################

KONFIGURATION :

es ist lediglich n�tig die config.php zu bearbeiten

- es sollten die pfade zu den gbox ordnern angepasst werden

unter linux z.B  /var/keys/  oder /usr/bin 
unter windows nat�rlich z.B C:\gbox_win\
oder wo ihr auch immer eure verzeichnisse angelegt habt

es solten auch user und pass f�r die weboberfl�che angelegt werden

Bsp.: 

$gbox_path = "/bin/";
$file_path = "/var/keys/";
$info_path = "/tmp/";
$sitename = "Gbox Web Controll for Unix Servers";
$username  = "user";
$password = "pass";


##################################################################

Falls einer was entdeckt oder was �ndern will, oder was auch immer
kann er mich unter capa77@gmail.com erreichen

Viel spass am script :-)

Capa

