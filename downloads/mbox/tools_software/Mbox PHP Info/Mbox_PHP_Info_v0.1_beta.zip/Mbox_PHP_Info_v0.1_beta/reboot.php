<?php
include('protector.php');
/*
This file is very hardcoded for gboxcontrol,it will not work if gboxcontrol is not running.
*/

function start(){
$trigger = "gboxstart.trigger";
$h = fopen($trigger, 'w') or die("Can't start gbox");
fclose($h);
}

function stop(){
$trigger = "gboxstop.trigger";
$h = fopen($trigger, 'w') or die("Can't stop gbox");
fclose($h);
}


if (isset($_POST['action'])) {
$action = $_POST['action'];
if ($action == 'Start') {
start();
}

if ($action == 'Stop') {
stop();
}

if ($action == 'Restart') {
stop();
start();
}
header('Location: reboot.php');
exit();
}
include('header.php');

?>
<style type="text/css">
<!--
.style1 {color: #000000}
-->
</style>
<p class="style1" style="margin-left: 20"><font face="Arial" size="4">Gbox process control</font></p>
<p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
  <font face="Arial" size="4" color="#000000">
  <blockquote>
  <div align="center">
    <?php 
if (!file_exists('gboxrun.trigger')) {print "<font color=\"#FF0000\">Gbox is stopped...<br>";} else {print "<font color=\"#669900\">Gbox is running...<br>";}
?>
    
  </div>
  <form id="form1" name="form1" method="post" action="reboot.php">
    <p align="center">
      <input name="action" type="submit" id="start" value="Start" />
      <input name="action" type="submit" id="stop" value="Stop" />
      <input name="action" type="submit" id="restart" value="Restart" />
    </p>
</form>
  <div align="center">
</blockquote>
<p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
<?php 
include('footer.php');
?>
  </div>
