<?php 
include('protector.php');
include('header.php');
if (file_exists($info_path.'share.info'))
{
   $cards = read2array($info_path.'share.info');
   unset($cards[count($cards)-1]);
   foreach($cards as $card){
     $elms = explode(' ',$card);
	  $peers[$elms[3]]['domain'] = $elms[3];
   }
}
?>
<style type="text/css">
<!--
.style2 {color: #000000}
-->
</style>
 <blockquote>
  <p class="style2" style="margin-left: 20"><font face="Arial" size="4">Cards available </font></p>
  <form id="form1" name="form1" method="GET" action="cards.php">
         <p> Distance
           <input name="dist" type="text" 
	<?php if (isset($_GET['filter']))
	{print 'value="'.$_GET['dist'].'"';} 
	else 
	{print 'value="0"';}
	?> size="5" />
        
        Peer : 
        <select name="peerselect" id="peerselect">
          <option value="all">All</option>
          <?php
	 foreach($peers as $peer){
	 if (isset($_GET['filter'])) {
	   if ($peer['domain'] == $_GET['peerselect']) 
	   {print('<option value="'.$peer['domain'].'" selected="selected">'.$peer['domain'].'</option>');}
	   else
   	   print('<option value="'.$peer['domain'].'">'.$peer['domain'].'</option>');
	 }
	 else
	 print('<option value="'.$peer['domain'].'">'.$peer['domain'].'</option>');
	 }
	 ?>
        </select>
        <input name="filter" type="submit" id="filter" value="OK" />
        <br />
        Distance 0 - Show all distances of the peer. </p>
         </blockquote>
  </form>
  <p style="margin-left: 20">
  <font face="Arial" size="2" color="#000000">
  
  <table width="95%"  border="1" cellpadding="0" cellspacing="0" align="center">
  <tr bgcolor="#CCCCCC">
    <td width="8%"><div align="center">N</div></td>
    <td width="8%"><div align="center">Card ID</div></td>
    <td width="8%"><div align="center">Prov<font color="#000000" size="2" face="Arial">. </font>ID</div></td>
    <td width="10%"><div align="center">CAID</div></td>
    <td width="33%"><div align="center">Provider name </div></td>
    <td width="18%"><div align="center">Peer</div></td>
    <td width="12%"><div align="center">Level</div></td>
    <td width="11%"><div align="center"><font color="#000000" size="2" face="Arial">Distance</font></div></td>
  </tr>
<?php
if (file_exists($info_path.'share.info') && file_exists($file_path.'ident.info'))
{
   $cards = read2array($info_path.'share.info');
   unset($cards[count($cards)-1]);
   foreach($cards as $card){
     $elms = explode(' ',$card);
	 if (isset($_GET['filter'])) {
	 
	 if (($_GET['dist'] != '0') && ($_GET['peerselect'] == 'all') && ($elms[8] == 'dist:'.$_GET['dist']))
	    {
	  $provs[$elms[1]]['num'] = $elms[1];
	  $provs[$elms[1]]['id'] = $elms[5];
	  $provs[$elms[1]]['peer'] = $elms[3];
	  $provs[$elms[1]]['distance'] = $elms[8];
	  $provs[$elms[1]]['level'] = $elms[7];
	  $provs[$elms[1]]['cardid'] = $elms[9];
	  
	   }
	 else
  	 if (($_GET['dist'] != '0') && ($_GET['peerselect'] != 'all') && ($elms[8] == 'dist:'.$_GET['dist']) && ($elms[3] == $_GET['peerselect']))
	    {
	  $provs[$elms[1]]['num'] = $elms[1];
	  $provs[$elms[1]]['id'] = $elms[5];
	  $provs[$elms[1]]['peer'] = $elms[3];
	  $provs[$elms[1]]['distance'] = $elms[8];
	  $provs[$elms[1]]['level'] = $elms[7];
	  $provs[$elms[1]]['cardid'] = $elms[9];
	   }
	 else
  	 if (($_GET['dist'] == '0') && ($_GET['peerselect'] != 'all') && ($elms[3] == $_GET['peerselect']))
	    {
	  $provs[$elms[1]]['num'] = $elms[1];
	  $provs[$elms[1]]['id'] = $elms[5];
	  $provs[$elms[1]]['peer'] = $elms[3];
	  $provs[$elms[1]]['distance'] = $elms[8];
	  $provs[$elms[1]]['level'] = $elms[7];
	  $provs[$elms[1]]['cardid'] = $elms[9];
	   }
	 else
  	 if (($_GET['dist'] == '0') && ($_GET['peerselect'] == 'all'))
	    {
	  $provs[$elms[1]]['num'] = $elms[1];
	  $provs[$elms[1]]['id'] = $elms[5];
	  $provs[$elms[1]]['peer'] = $elms[3];
	  $provs[$elms[1]]['distance'] = $elms[8];
	  $provs[$elms[1]]['level'] = $elms[7];
	  $provs[$elms[1]]['cardid'] = $elms[9];
	   }
	 
	 }//end submit
	 else
     {
	 $provs[$elms[1]]['num'] = $elms[1];
	 $provs[$elms[1]]['id'] = $elms[5];
	 $provs[$elms[1]]['peer'] = $elms[3];
	 $provs[$elms[1]]['distance'] = $elms[8];
	 $provs[$elms[1]]['level'] = $elms[7];
	  $provs[$elms[1]]['cardid'] = $elms[9];
     }
   }
   $ident = read2array($file_path.'ident.info');
   unset($ident[count($ident)-1]);

   foreach ($ident as $id){
     $names = explode(';',$id);
     $ids[$names[0]]['id'] = $names[0];
     $ids[$names[0]]['name'] = $names[1];
   }

   echo "<h4><div align=\"center\">".count($provs).' cards listed.</div></h4>';

   if (empty($provs)){
     echo "<tr><td colspan=7><div align=\"center\">No cards found</div></td></tr>";
   }
   else
   foreach($provs as $prov){
   //print_r($prov);
   echo "<tr>";
    echo "<td><div align=\"center\">".$prov['num']."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".substr($prov['cardid'],3,4)."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".substr($prov['id'],4)."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".substr($prov['id'],0,4)."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$ids[$prov['id']]['name']."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$prov['peer']."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$prov['level']."&nbsp;</div></td>";
    echo "<td><div align=\"center\">".$prov['distance']."&nbsp;</div></td>";
   echo "</tr>";

   }
} 
else   
echo "<tr><td colspan=7><div align=\"center\">The files 'share.info' and/or 'share.onl' were not found.</div></td></tr>";

  ?>
  </table>
  </font></p>

<p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
      <p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
      
<?php 
include('footer.php'); 
?>
