<?php 
include('protector.php');
include('header.php');


?>
<style type="text/css">
<!--
.style1 {color: #6600CC}
.style2 {color: #000000}
-->
</style>

<blockquote>
  <p class="style1" style="margin-left: 20"><font face="Arial" size="4"><span class="style2">Welcome Administrator</span></font></p>
  <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">In this section you can view some information about your mbox and make some changes to your config files.</font></p>
  <p style="margin-left: 20">&nbsp;</p>

<?php
if (file_exists($info_path.'share.info') && file_exists($info_path.'share.onl') )
{
$cards = read2array($info_path.'share.info');
unset($cards[count($cards)-1]);
foreach($cards as $card){
     $elms = explode(' ',$card);
	 $dists[$elms[8]]['dist'] = substr($elms[8],5);
	 $dists[$elms[8]]['cnt']=$dists[$elms[8]]['cnt']+1;
   }

$peer_list = read2array($info_path.'share.onl');
unset($peer_list[count($peer_list)-1]);
foreach ($peer_list as $peer){
     $p = explode(' ',$peer);
	 if ($p[0] == '1'){ 
	 $peers[$p[3]]['status'] = $p[0];
	 }	 
}

?>
<p class="style2" style="margin-left: 20"><font face="Arial" size="4">Information Center </font></p>
<p style="margin-left: 20"><font face="Arial" size="2" color="#000000">Gbox version: <strong><?=file_get_contents($info_path.'mbox.ver');?></strong></font><br />
Cards Online : <strong><?=count($cards);?></strong> 
<br />
Peers Online : <strong><?=count($peers);?></strong>
<br />
<br />
<strong>Card distances : </strong><br>
<br />
<?php
sort($dists);
foreach ($dists as $dist) {
echo "Distance <strong>".$dist['dist']."</strong> : <a href=\"cards.php?dist=".$dist['dist']."&peerselect=all&filter=OK\"><strong><u>".$dist['cnt']."</strong> cards.</u></a><br>";
}
} else { echo "<font color='red'><h2>ERROR !!!</h2><br><b>Check the gbox Path Variables in config.php</b></font>"; } 
?>
</p>
<p style="margin-left: 20">&nbsp;</p>
<p style="margin-left: 20"><font color="#000000" size="2" face="Arial"></font></p>
</blockquote>
<p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
      <p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
<?php
include('footer.php'); 
?>
