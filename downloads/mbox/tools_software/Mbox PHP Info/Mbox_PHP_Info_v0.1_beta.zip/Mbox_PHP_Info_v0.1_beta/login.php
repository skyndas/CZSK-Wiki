<?php 
include('header.php');
?>
<style type="text/css">
<!--
.style1 {color: #000000}
-->
</style>

<blockquote>
  <p class="style1" style="margin-left: 20"><font face="Arial" size="4">Login</font></p>
  <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">Please type your login details to access this page.</font></p>
  <form id="form1" name="form1" method="post" action="index.php">
    <table width="30%" border="0" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="47%"><div align="right"><font face="Arial" size="2" color="#000000">Username : </font></div></td>
        <td width="53%"><input type="text" name="username" /></td>
      </tr>
      <tr>
        <td><div align="right"><font face="Arial" size="2" color="#000000">Password : </font></div></td>
        <td><input type="password" name="password" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><div align="right"></div></td>
        <td>
          
          <div align="left">
            <input type="submit" name="login" value="Login" />
          </div></td>
      </tr>
    </table>
  </form>
  <p style="margin-left: 20">&nbsp;</p>
</blockquote>
<p style="margin-left: 20">&nbsp;</p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;&nbsp;</font></p>
      <p style="margin-left: 20"><font face="Arial" size="2" color="#000000">&nbsp;</font></p>
<?php 
include('footer.php'); 
?>