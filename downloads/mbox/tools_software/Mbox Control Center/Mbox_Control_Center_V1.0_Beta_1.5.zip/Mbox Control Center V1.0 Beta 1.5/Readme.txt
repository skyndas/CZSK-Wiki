removed empty password check
- add sort on each grid
- add check for non hex value's in M-line
- add Telnet termulator ( Thanks to VisMan. )



please backup your files BEFORE you use MCC !!!
