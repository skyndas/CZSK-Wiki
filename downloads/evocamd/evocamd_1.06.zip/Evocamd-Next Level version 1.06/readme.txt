-----------------------------------------------------------------------------------------------------------------------------
Important:
Please use your local cards in newcamd-client.txt on buttom..also as last in file.
This will guarantee that all the time first your cards are used and as second choice
spider or another routes,think on traffic please 
N2 idea key must be as N prov 00 idea key in Keylist.txt
Tps key must be as T:xxxxxxxxxxxxxxxxxxxxxxxxxxxx in Autoupdate.Key
Biss keys must be as B:sid xxxxxxxxxxxxxxxxxxxxxxxxx in Keylist.txt(same for fix cw providers)
NDS emm is 100% tested and should work for all available providers.
-----------------------------------------------------------------------------------------------------------------------------

Evocamd-Next Level version 1.06
-------------------------------
Nagravision2 autoroll for some providers ( Dish, Bev)
thx an bball for support.
Added new binary for relook pvr
Vdr binary updatet

Evocamd-Next Level version 1.05
-------------------------------
BEV Canada fix

Evocamd-Next Level version 1.04
-------------------------------

Nagravison2 emm handling added.

Evocamd-Next Level version 1.03
-------------------------------

Videoguard Multiple EMM handling added.
Changed to libcrypto.so.0.9.7 instead of libcrypto.so.0


Evocamd-Next Level version 1.02
-------------------------------

Some small needed fixes.
Italia emm is tested and should work okay now.

Evocamd-Next Level version 1.01
-------------------------------

Nagra AU fix
Italia emm fix(videoguard)

Evocamd-Next Level version 1.00
-------------------------------

evocamd_ppc.bin			->	Evocamd binary for dreambox
evocamd-oldGCC.bin		->	Evocamd with support for Triple Dragon and Dbox2(old gcc)
directory /vdr			->	Evocamd binary for VDR + evo-vdr-1.3.21.diff

Konfiguration(Configuration) Files
-------------------

camd_cfg
Autoupdate.Key
Keylist.txt
newcamd-client.txt
ignore.list
priority.list
replace.list
eeproms und rams(siehe scce Ordner)

------------------------------------------------------------------------------------------------------------------------------


Ja genau, wir haben endlich geschaft evocamd neu zu designen.
Warum?Nun dort waren viele sachen womit wir mehr oder weniger nicht Zufrieden waren.
Was hat sich ge�ndert?
NewCS client wurde �berarbeitet um best m�gliche speed zu erzielen,das gleiche gilt 
f�r emu modus ..jedoch immer daran denken "priority.list ignore.list replace.list " zu konfigurieren(Beispiel Datei liegt bei).
Warum werden diese dateien benutzt?Es ist in eure Interesse Leute !!!Damit habt ihr unbegrenzte m�glichkeiten
in was ecm pids oder provider Auswahl betrifft.Denke nicht das besser w�re wenn wir das f�r euch bestimmen, ein 
bisschen flexibilit�t w�re dann nicht mehr vorhanden.
Ausser NewCS wird noch radegast share �nterst�tzt, jedoch die camd3 Unterst�tzung wurde eingestellt, da wie wir verstanden haben
�nderungen in protokoll gegeben haben soll.
-------------------------------------------------------------------------------------------------------------------------------


Welche Syteme werden Unterst�tzt:
Emulation:
---------
Seca - ecm
Viacess - ecm & emm
Irdeto - ecm & emm
Biss - ecm
Nagravision - ecm & emm(nur n1)
-------------------------------------


Card Support trough NewCS cardserver:
-------------------------------------
 *- Conax       *- Seca        
 *- Irdeto      *- Cryptoworks 
 *- Betacrypt   *- Viaccess    
 *- Dreamcrypt  *- Videoguard  
-----------------------------------------------------------------------------------------------
NOTE!
EMM IST SUPPORTED F�R ALLE CA-SYS(siehe oben) ausser dreamcrypt!!!!!!
FALLS IHR SOGENANNTE MOSC CARDS BENUTZT, BITTE VORHER BLOCKER IN NEWCS CONFIG AKTIVIEREN.
WIR SIND NICHT VERANTWORTLICH F�R M�GLICHE SCHADEN,SPRICH KARTE DEAKTIVIERT DURCH PROVIDER !!!
-----------------------------------------------------------------------------------------------
 







WICHTIG
--------

In Radegast share wird clear modus sharing unterst�tzt sowie crypted !!!
F�r ben�tigte Einstellungen, bitte rdgd readme beachten	
Um OSD benutzen zu k�nnen wurde die camd_cfg erweitert mit USER = und PWD = einstellungen. 

Faq

1. Its support evocamd tps2 channel?
Indeed,just put your aes key in Autoupdate.key
T: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

2.Its sharing possible with evocamd?
Yes,you can use the spider net and NewCS/cardserver
3.Can i use my cards in dream or Triple dragon slots?
Offcorse,just setup a newcamd cardserver,and put your login Data in newcamd-client.txt
4.Is emm supported with newcamd-cardserver?
Yes,irdeto-conax-seca,cryptoworks,viacess is supportet,just setup one AU user in cardserv.cfg and you are done
5. Is a premiere card supported with evocamd?
Offcorse, NewCS rulez :)))))))

7.I get AU on  Cabo but i dont have picture,and in log i see mecm failed
Check in Autoupdate.key if e1n and n1n are corect
8.Can i use my premiere card in dbox2 normal slot?
Yes,you can
9.How can i log on my windows pc?
In camd_cfg you must setup one UDP port for logging, you find a client in our distribution
10.I cant use camd3 client with a dreamcrypt card
Its must work,but please check allways your ignore.list,maybe you ignore some caids or provider what you need