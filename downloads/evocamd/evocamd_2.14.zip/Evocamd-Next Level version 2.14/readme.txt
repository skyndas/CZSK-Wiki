-----------------------------------------------------------------------------------------------------------------------------
Important:
Please use your local cards in newcamd-client.txt on buttom..also as last in file.
This will guarantee that all the time first your cards are used and as second choice
spider or another routes,think on traffic please 
N2 idea key must be as N prov 00 idea key in Keylist.txt
Tps key must be as T:xxxxxxxxxxxxxxxxxxxxxxxxxxxx in /var/keys/tps
Biss keys must be as B sid 00 xxxxxxxxxxxxxxxxxxxxxxxxx in Keylist.txt(same for static cw providers)
NDS emm is 100% tested and should work for all available providers.
Nagra2 key format is changed since Version 1.06( where AU code for nagra2 was added) :
Format:

; N2 Keys:
; M1 - ECM RSA Modulus (e = 3)
; N1 - EMM RSA Modulus (Round 1, e = 3)
; PK - EMM Parity Key (Expanded to N2 and E2) or I - idea key
; V - EMM Verify Key
; I - idea
-----------------------------------------------------------------------------------------------------------------------------
Evocamd-Next Level version 2.14
--------------------------------------
Fix TPS again..!
Added config and key file reload, P: { 01 } (still in testing, please report if some 
errors ..)



Evocamd-Next Level version 2.13
--------------------------------------

Small update: TPS decoding
put tps.bin in /var/keys or /tmp

small faq: Why its still try some server bevore emu decoding, for example tps?
Well..as you know latest evo versions put a file in /var/keys wich tell how's the way to decoding( services.txt), you
better maybe delete this file and restart again.

Evocamd-Next Level version 2.12
--------------------------------------

Some fixes..like nds emm on italy for example..
Cache services function added ( keep in mind how was decoded last service, if network or emu, this increase wait time), no need to config something,will be managed by evocamd (look in /var/keys/services.txt to see what it do).


Evocamd-Next Level version 2.11
--------------------------------------
You are able now to use TPS_AES.txt keys list and http update.(except evocamd from dbox+dragon directory, there still the old one)
This mean when no "good" key in list, will be downloaded from http your choice
the good one.Please check camd_cfg for configuration.
wwwtps = http://xxxxxxxxxxxxx/xxx/xxxxxxx.php
wwwtps_offset = 0
wwwtps_filter = 0500:007C00:0000000000:00:%02x%02x%02x%02x%02x%02x%02x%02x:%02x%02x%02x%02x%02x%02x%02x%02x
wwwtps_offset and wwwtps_filter is a flexibler way to fetch keys from http your choice, as every http use another format.
In this example if you have wwwtps_offset = 5, filter will be wwwtps_filter = 007C00:0000000000:00:%02x%02x%02x%02x%02x%02x%02x%02x:%02x%02x%02x%02x%02x%02x%02x%02x, if wwwtps_offset = 25 , your filter will be wwwtps_filter = %02x%02x%02x%02x%02x%02x%02x%02x:%02x%02x%02x%02x%02x%02x%02x%02x and so on.On default filter is 0.
Keys will be saved on evocamd termination, so PLEASE NEVER KILL EVOCAMD WITH "-9"
- New Vdr version added.

Evocamd-Next Level version 2.10_update
--------------------------------------
Fix  memory leak in nagra emm
SHA added in binary to avoid libcrypto dependencies

Evocamd-Next Level version 2.10
--------------------------------------
FIX CW HASH on DISH and BEV
No any timebomb inside like some coreeans viewsat stbs , tja money is king seems allover.
THX to our NA friends for help.
NOTE: YOU MUST ADD ROM102.bin in /var/scce directory ( not available in this package )
Evocamd-Next Level version 2.09_update
--------------------------------------
multi aes bug fixed *G*

Evocamd-Next Level version 2.09
--------------------------------------
"Keylist.txt brocken when emm keys available"
FIXED!
"after recording i have sometimes english audio track empty"
FIXED!
"I want use many tps aes keys because they cycle many time at day"
FIXED!

-pmt update fix
-multi aes wird jetzt supportet, denk bitte daran das alle keys in /var/keys/TPS_AES.txt sich befinden sollen ( nicht mehr /var/keys/tps).
---------------------------
TPS_AES.txt format:
111111111111111111111111111
222222222222222222222222222
333333333333333333333333333
444444444444444444444444444
555555555555555555555555555
---------------------------
also einfach key darin pflanzen ohne irgendein T: oder was auch immer
-nagra emm fix

Evocamd-Next Level version 2.08_update
--------------------------------------
Fix BEV and DISH USA emm

Evocamd-Next Level version 2.08
--------------------------------------

Fixed huge bug in card handling on cryptoworks.
Please change to this version to avoid it.
Fix fta bug on dream ppc boxes


Evocamd-Next Level version 2.07
--------------------------------------

Add some new crypto providers

Evocamd-Next Level version 2.06_update
--------------------------------------

some more fixes...

Evocamd-Next Level version 2.06
-------------------------------
some more cw providers
Turner,BT, Checzlink, Slovaklink
Evocamd-Next Level version 2.05
-------------------------------
- some fixes
- add cryptoworks emu

Evocamd-Next Level version 2.04_update
--------------------------------------

Fix freezes issue with emm enabled
new vdr version added ( think about that configs must be in same dir as evo binary)


Evocamd-Next Level version 2.04
-------------------------------
Some polsat fix
You need DES in libcrypto !!!!!

Evocamd-Next Level version 2.03
-------------------------------

Fix Globecast provider
Fix POLLERR emm issue
Other small fixes ( minor and major one )

Evocamd-Next Level version 2.02
-------------------------------

Fix nagra parser on triple dragon
Fix caid list, dont stick in one caid forever...if server not available.
PLEASE CHANGE TO THIS VERSION TO AVOID BUG !!!!!!!!!!

Evocamd-Next Level version 2.01
-------------------------------

fix AU problem on nagra2 channels USA  (fake keys)

Evocamd-Next Level version 2.00
-------------------------------
 As evocamd now uses enigma specific socket messages, it was not possible to keep all machines in one binary.
 From now on you will find some extra directories for binaries.
 - dreambox_7025
 - dreambox_ppc
 - dragon
 - relook
 - dbox
 New is the mipsel(7025) and ppc Dream binaries. You will now be able to watch one channel and record more 
 channels at the same time, and this without any changes in enigma source. No patch is needed for this.
 On 7025 you will be able, with two tuners to record two channels and watch a third at the same time(dunno any CI that can do this :P)
 On 7020 or 7000 you must enable in CI menu "can handle two services", you are then able to record one
 channel and watch another at the same time, but note this is only possible on the same Transponder.
Camd3 client old proto is enabled again, so you can use it to talk with dukat or freezers servers around :)
Radegast client is enabled too, and tested.
-------------------------------------------------------
Important!

Few words about multichannel, please keep in mind that not all cards suport too many requests same time, and please
if you use some Spider Network dont use it just for fun..use it just if needed as you will make higher traffic in net.


In diese Distribution befinden sich mehrere binaries f�r verschiedene boxen wie folgt:
- dreambox_7025
- dreambox_ppc
- dragon
- relook
- dbox

Neu ist die dreambox 7025 binarie mit multichannel support ( es ist m�glich zum Beispiel zwei channels aufzunehmen und ein drittes
zu gucken)
Das gilt auch f�r die ppc Version mit die aber nur ein channel aufnehmen und eins gucken auf den Selben Transponder m�glich ist.
Daf�r aber die entsprechen option in CI menu aktivieren.
Camd3 client wurde wieder aktiviert ( das alte protokoll), damit k�nnte man auf Dukat oder freezer Servers verbinden.
Radegast client ist auch so weit aktiviert aber leider noch nicht getestet. 
--------------------------------------------------------
Wichtig!
Bitte denkt daran das drei requests gleichzeitig nicht von alle karten Unterst�tzt wird, und das macht
unn�tige Traffic in Zb Spider Net, also bitte nur benutzen wenn unbedingt notwendig.
camd3 config syntax :
camd35:bla.linux.net:20248:1/1702:test1:test1
in "/var/keys/camd35.conf"

Evocamd-Next Level version 1.10
-------------------------------
fix AU problem on nagra2 channels (USA)
fixes freezing/pixelation problems people have been seeing on nagra2

Evocamd-Next Level version 1.09
-------------------------------

fix cabo n2 ident


Evocamd-Next Level version 1.08
-------------------------------

fix swap of dcw on nagra2 providers

Evocamd-Next Level version 1.07
-------------------------------
"autofetch AES Key feature"

Location of aes key was changed to /var/keys/tps.
If file not present will be created.
To update your aes key you must put in camd_cfg URL from 
where to fetch the new one.
Example:
wwwtps = http://xxxxxxxxxxxxxxx/SoftCam.Key
Important:
Just SoftCam.Key format will be used.

Kleine �nderung:
tps key wird jetzt in /var/keys/tps erwartet.
Falls file nicht existiert, es wird angelegt und mit g�ltige key ausgef�llt
soweit in camd_cfg dieser Eintrag existiert:
wwwtps = http://xxxxxxxxxxxxxxx/SoftCam.Key
Nur SoftCam.Key format wird unterst�tzt f�r autofetch!!!

Fehlerhafte libcrypto wurde in Package ersetzt.

Evocamd-Next Level version 1.06
-------------------------------
Nagravision2 autoroll for some providers ( Dish, Bev)
thx an bball for support.
Added new binary for relook pvr
Vdr binary updatet

Evocamd-Next Level version 1.05
-------------------------------
BEV Canada fix

Evocamd-Next Level version 1.04
-------------------------------

Nagravison2 emm handling added.

Evocamd-Next Level version 1.03
-------------------------------

Videoguard Multiple EMM handling added.
Changed to libcrypto.so.0.9.7 instead of libcrypto.so.0


Evocamd-Next Level version 1.02
-------------------------------

Some small needed fixes.
Italia emm is tested and should work okay now.

Evocamd-Next Level version 1.01
-------------------------------

Nagra AU fix
Italia emm fix(videoguard)

Evocamd-Next Level version 1.00
-------------------------------

evocamd_ppc.bin			->	Evocamd binary for dreambox
evocamd-oldGCC.bin		->	Evocamd with support for Triple Dragon and Dbox2(old gcc)
directory /vdr			->	Evocamd binary for VDR + evo-vdr-1.3.21.diff

Konfiguration(Configuration) Files
-------------------

camd_cfg
Autoupdate.Key
Keylist.txt
newcamd-client.txt
ignore.list
priority.list
replace.list
eeproms und rams(siehe scce Ordner)

------------------------------------------------------------------------------------------------------------------------------


Ja genau, wir haben endlich geschaft evocamd neu zu designen.
Warum?Nun dort waren viele sachen womit wir mehr oder weniger nicht Zufrieden waren.
Was hat sich ge�ndert?
NewCS client wurde �berarbeitet um best m�gliche speed zu erzielen,das gleiche gilt 
f�r emu modus ..jedoch immer daran denken "priority.list ignore.list replace.list " zu konfigurieren(Beispiel Datei liegt bei).
Warum werden diese dateien benutzt?Es ist in eure Interesse Leute !!!Damit habt ihr unbegrenzte m�glichkeiten
in was ecm pids oder provider Auswahl betrifft.Denke nicht das besser w�re wenn wir das f�r euch bestimmen, ein 
bisschen flexibilit�t w�re dann nicht mehr vorhanden.
Ausser NewCS wird noch radegast share �nterst�tzt, jedoch die camd3 Unterst�tzung wurde eingestellt, da wie wir verstanden haben
�nderungen in protokoll gegeben haben soll.
-------------------------------------------------------------------------------------------------------------------------------


Welche Syteme werden Unterst�tzt:
Emulation:
---------
Seca - ecm
Viacess - ecm & emm
Irdeto - ecm & emm
Biss - ecm
Nagravision - ecm & emm(nur n1)
-------------------------------------


Card Support trough NewCS cardserver:
-------------------------------------
 *- Conax       *- Seca        
 *- Irdeto      *- Cryptoworks 
 *- Betacrypt   *- Viaccess    
 *- Dreamcrypt  *- Videoguard  
-----------------------------------------------------------------------------------------------
NOTE!
EMM IST SUPPORTED F�R ALLE CA-SYS(siehe oben) ausser dreamcrypt!!!!!!
FALLS IHR SOGENANNTE MOSC CARDS BENUTZT, BITTE VORHER BLOCKER IN NEWCS CONFIG AKTIVIEREN.
WIR SIND NICHT VERANTWORTLICH F�R M�GLICHE SCHADEN,SPRICH KARTE DEAKTIVIERT DURCH PROVIDER !!!
-----------------------------------------------------------------------------------------------
 







WICHTIG
--------

In Radegast share wird clear modus sharing unterst�tzt sowie crypted !!!
F�r ben�tigte Einstellungen, bitte rdgd readme beachten	
Um OSD benutzen zu k�nnen wurde die camd_cfg erweitert mit USER = und PWD = einstellungen. 

Faq

1. Its support evocamd tps2 channel?
Indeed,just put your aes key in Autoupdate.key
T: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

2.Its sharing possible with evocamd?
Yes,you can use the spider net and NewCS/cardserver
3.Can i use my cards in dream or Triple dragon slots?
Offcorse,just setup a newcamd cardserver,and put your login Data in newcamd-client.txt
4.Is emm supported with newcamd-cardserver?
Yes,irdeto-conax-seca,cryptoworks,viacess is supportet,just setup one AU user in cardserv.cfg and you are done
5. Is a premiere card supported with evocamd?
Offcorse, NewCS rulez :)))))))

7.I get AU on  Cabo but i dont have picture,and in log i see mecm failed
Check in Autoupdate.key if e1n and n1n are corect
8.Can i use my premiere card in dbox2 normal slot?
Yes,you can
9.How can i log on my windows pc?
In camd_cfg you must setup one UDP port for logging, you find a client in our distribution
10.I cant use camd3 client with a dreamcrypt card
Its must work,but please check allways your ignore.list,maybe you ignore some caids or provider what you need