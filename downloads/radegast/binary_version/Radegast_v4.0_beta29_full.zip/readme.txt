Beerman 9.1 fix:

* rdgd 4.b29 - D+ included ;)

NOTE: Copy rdgd to /var/bin and restart box
NOTE2: Please check if in /var is enough place for that
otherwise your box will stop decoding at all
(Too small flash in TD, unfortunatelly)
Note3: "DON'T FORGET TO CHANGE PERMISSIONS of rdgd to 700!!! (chmod 700 /var/bin/rdgd)"

--
BM