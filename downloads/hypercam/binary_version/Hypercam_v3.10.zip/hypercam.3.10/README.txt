Yeah ! This is Hypercam README file...

Hypercam is a softcam system designed for efficient peer to peer sharing
situation. This file is a little piece of information about it.

This software is provided without any kind of waranty. Does not work on your
system ? Sorry...let's try with another softcam !



==============
=   HOW-TO   =
==============

How to setup this softcam ?

--------------------------------------------------
For all generic platforms : PowerPC, Mipsel or sh4
--------------------------------------------------

First, choose the most appropriate version depeding on your needs :

=> TINY version only support smartcard readers. No other stuff.
=> LITE version adds sharing support


---------------------------------------------
PowerPC platforms running Enigma1
---------------------------------------------

Depending on the version you want to install, choose the appropriate tar file
and :

ON ITGATE PLATFORMs (auto-install) :
=> rename it to install.tar
=> upload it on the receiver into /var/etc
=> reboot the receiver and enjoy !

---------------------------------------------------
All other platforms or any platform running Enigma2
---------------------------------------------------

=> Upload the BINARY file such as hypercam.mipsel.tiny on your receiver.
=> Change its running attribute to 755 with chmod command
=> Upload a fully featured libcrypto.so, if not already present in /lib.
=> Upload sample file hypercam.cfg to required location
=> Update LD_LIBRARY_PATH so that it points out to the location of the lib.
=> Start the softcam with -c option to tell hypercam where you placed the
configuration file. Default is /var/bin/hypercam.cfg

Example :
If both binary file and configuration file are loaded into /usr/hypercam
directory :

/usr/hypercam/hypercam.mipsel.tiny -c /usr/hypercam/hypercam.cfg

-----------------------
Note for QBOX /  ABCOM
-----------------------

These devices require complementary support files or operations :

=> QBOXHD require specific operations to setup symlink because of its
non-standard DVB architecture. You will find support on that on most forums.

=>  ABCOM require an E2 platform with appropriate smartcard
drivers. Here again, find support on most forums.

Have fun !


==============
=  HISTORY   =
==============

--------------
 Release 1.01
--------------
=> Major release. Now we are no more in 0.xx !

../..


--------------
 Release 3.08
--------------
==> Fix a bug about resources management, on intensive zapping

--------------
 Release 3.09
--------------
==> Improve support of TNTsat french cards (SD & HD )

--------------
 Release 3.10
--------------
==> For Mipsel & SH4 versions, link libcrypto in static mode, to suppress dependancy with openssl versions,
 	to be compatible with OpenPLi version 4 images



