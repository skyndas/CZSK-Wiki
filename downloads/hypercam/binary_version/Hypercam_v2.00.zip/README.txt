Yeah ! This is Hypercam README file...

Hypercam is a softcam system designed for efficient peer to peer sharing
situation. This file is a little piece of information about it.

This software is provided without any kind of waranty. Does not work on your
system ? Sorry...let's try with another softcam !



==============
=   HOW-TO   =
==============

How to setup this softcam ?

--------------------------------------------------
For all generic platforms : PowerPC, Mipsel or sh4
--------------------------------------------------

First, choose the most appropriate version depeding on your needs :

=> TINY version only support smartcard readers. No other stuff.
=> LITE version adds sharing support
=> FULL version also adds emulation support

---------------------------------------------
PowerPC platforms running Enigma1
---------------------------------------------

Depending on the version you want to install, choose the appropriate tar file
and :

ON ITGATE PLATFORMs (auto-install) :
=> rename it to install.tar
=> upload it on the receiver into /var/etc
=> reboot the receiver and enjoy !

---------------------------------------------------
All other platforms or any platform running Enigma2
---------------------------------------------------

=> Upload the BINARY file such as hypercam.mipsel.full on your receiver.
=> Change its running attribute to 755 with chmod command
=> Upload a fully featured libcrypto.so, if not already present in /lib.
=> Upload sample file hypercam.cfg to required location
=> Update LD_LIBRARY_PATH so that it points out to the location of the lib.
=> Start the softcam with -c option to tell hypercam where you placed the
configuration file. Default is /var/bin/hypercam.cfg

Example :
If both binary file and configuration file are loaded into /usr/hypercam
directory :

/usr/hypercam/hypercam.mipsel.full -c /usr/hypercam/hypercam.cfg

---------------------------------
Note for QBOX / DGSTATION / ABCOM
---------------------------------

These devices require complementary support files or operations :

=> QBOXHD require specific operations to setup symlink because of its
non-standard DVB architecture. You will find support on that on most forums.

=> DGSTATION / ABCOM require an E2 platform with appropriate smartcard
drivers. Here again, find support on most forums.

Have fun !


==============
=  HISTORY   =
==============

--------------
 Release 1.01
--------------
=> Major release. Now we are no more in 0.xx !
=> Fixed one deadlock case
=> Fixed one null pointer causing hypercam to crash on startup with log disabled
=> Experimental : now supporting other PPC based STB receivers running Enigma 1
=> Experimental : now supporting QBOX HD. Please read the README.QBOXHD for setup instructions
=> Experimental : now supporting IPBOX 9000. Please read the README.IPBOX for setup instructions

--------------
 Release 1.02
--------------
=> Fixed NDS smartcard handling causing a crash
=> Fixed smartcard removall causing a crash
=> Fixed Nagra card timing settings
=> Fixed Nagra 3 system identification for smartcard

--------------
 Release 1.03
--------------
=> Fixed IPBOX pmt file operations
=> Fixed Nagra 3 system identification for PMT

--------------
 Release 1.04
--------------
=> Added one type of NDS card support
=> Added hypercam.status file, see configuration file for settings
=> Fixed clear => crypted switch for some channel not providing new PMT

--------------
 Release 1.05
--------------
=> Fixed clear => crypted switch / Dreambox PPC specific operations
=> Workaround for Dreambox PPC poor smartcard drivers timing...

--------------
 Release 1.06
--------------
=> Fixed card support on Dreambox PPC for N2/N3/IRDETO/NDS
=> Fixed streaming decryption on Dreambox PPC

--------------
 Release 1.07
--------------
=> Fixed VIA operations 
=> Fixed NDS support for SKY

--------------
 Release 1.08
--------------
=> Fixed SECA handling 
=> Fixed N3 support
=> NEW : now supporting multi-tuner systems !
=> NEW : now supporting mipsel platforms !
=> NEW : now supporting all E2 features !
=> NEW : now supporting -c command line option to specify configuration file

--------------
 Release 1.09
--------------
=> Fixed SECA support
=> Fixed card file generation for host with no decoding (not generating files)
=> Updated status and scheme file generation : now generating one file per active demux
=> Updated card and localcard files content to include multi demux selection indication
=> Enhanced card propagation logic in case of same card received from different peers with different share level
=> Removed unneeded IPBOX9000 versions. Please use standard sh4 version on recent E2 firmwares with paco SCI drivers
=> Removed qboxhd version, because of the lack of support for this machine. qboxhd sucks !

--------------
 Release 1.10
--------------
=> Performance enhancement, now able to support more than 1000 connection on
single server on strong machines.
=> Fixed operations on qboxhd, thanks to one member of the team (but this
receiver still sucks !)
=> Fixed operations on Marusys VU+ Duo. Should now support smartcard readers.
=> Fixed ATR handling, causing in some case memory leak
=> Added DRE support...but not tested !
=> Fixed NDS operations for Sky
=> Fixed peer file support, was updating too often...
=> Fixed card reset logic. Should work find everywhere now.

--------------
 Release 1.11
--------------
=> Remove some optimization options that produce unstable versions
=> Fixed NDS operations for Sky again

--------------
 Release 1.12
--------------
=> Fixed status file generation so that unused demux are no more reported
=> Fixed card timing logic, now supporting recent drivers on most receivers.
=> Fixed NDS operations for Sky

--------------
 Release 1.13
--------------
=> Fixed NDS operations for Sky again due to attacks

--------------
 Release 2.00
--------------
=> Fixed decryption operations for DM7025 support
=> Fixed multi-decryption operation support for E2
=> Fixed host identification code for latest kernel support

