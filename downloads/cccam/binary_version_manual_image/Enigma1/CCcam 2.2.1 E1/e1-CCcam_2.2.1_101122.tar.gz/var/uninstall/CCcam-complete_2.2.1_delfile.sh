#!/bin/sh
# Name: CCcam-complete_2.2.1_101122.tar.gz
# Version: 2.2.1
# Type: Cam

kill `pidof newcs_1.67 oscam_1.00 `
killall -9 newcs_1.67 oscam_1.00 CCcam_2.2.1 2>/dev/null
sleep 2
remove_tmp

rm -rf /var/bin/CCcam_2.2.1
rm -rf /var/script/CCcam_2.2.1_cam.sh
rm -rf /var/script/CCcam_2.2.1_newcs_1.67_cam.sh
rm -rf /var/script/CCcam_2.2.1_oscam_1.00_cam.sh
rm -rf /var/uninstall/CCcam_2.2.1-newcs_1.67-script_delfile.sh
rm -rf /var/uninstall/CCcam_2.2.1-oscam_1.00-script_delfile.sh
rm -rf /var/uninstall/CCcam-complete_2.2.1_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
