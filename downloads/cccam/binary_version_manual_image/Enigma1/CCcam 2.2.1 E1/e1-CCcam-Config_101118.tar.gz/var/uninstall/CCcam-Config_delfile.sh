#!/bin/sh
# Name: CCcam-Config_101118.tar.gz
# Version: 
# Type: cam-config

rm -rf /var/uninstall/CCcam-Config_delfile.sh
rm -rf /var/etc/CCcam.cfg
rm -rf /var/etc/CCcam.channelinfo
rm -rf /var/etc/CCcam.prio
rm -rf /var/etc/CCcam.providers

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
