#!/bin/sh
# Name: CCcam-complete_2.1.4_110129.tar.gz
# Version: 2.1.4
# Type: Cam

kill `pidof newcs_1.67 oscam_1.00 `
killall -9 newcs_1.67 oscam_1.00 CCcam_2.1.4 2>/dev/null
sleep 2
remove_tmp

rm -rf /var/bin/CCcam_2.1.4
rm -rf /var/script/CCcam_2.1.4_cam.sh
rm -rf /var/script/CCcam_2.1.4_newcs_1.67_cam.sh
rm -rf /var/script/CCcam_2.1.4_oscam_1.00_cam.sh
rm -rf /var/uninstall/CCcam_2.1.4-newcs_1.67-script_delfile.sh
rm -rf /var/uninstall/CCcam_2.1.4-oscam_1.00-script_delfile.sh
rm -rf /var/uninstall/CCcam-complete_2.1.4_delfile.sh

exit 0

