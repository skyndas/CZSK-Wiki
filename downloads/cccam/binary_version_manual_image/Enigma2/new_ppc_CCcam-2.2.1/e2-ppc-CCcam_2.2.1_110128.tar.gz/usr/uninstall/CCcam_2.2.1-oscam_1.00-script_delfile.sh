#!/bin/sh
# CAMD_NAME: CCcam_2.2.1-oscam_1.00-script_110128.tar.gz
# CAMD_VERSION: 2.2.1
# Type: Cam

killall -9 oscam_1.00 CCcam_2.2.1 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/script/CCcam_2.2.1_oscam_1.00_cam.sh
rm -rf /usr/uninstall/CCcam_2.2.1-oscam_1.00-script_delfile.sh

exit 0

