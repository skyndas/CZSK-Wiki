#!/bin/sh
# Name: CCcam-complete_2.2.1_110128.tar.gz
# Version: 2.2.1
# Type: Cam

kill `pidof oscam_1.00 newcs_1.67 CCcam_2.2.1`
killall -9 oscam_1.00 newcs_1.67 CCcam_2.2.1 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/CCcam_2.2.1
rm -rf /usr/script/CCcam_2.2.1_cam.sh
rm -rf /usr/script/CCcam_2.2.1_newcs_1.67_cam.sh
rm -rf /usr/script/CCcam_2.2.1_oscam_1.00_cam.sh
rm -rf /usr/uninstall/CCcam_2.2.1-newcs_1.67-script_delfile.sh
rm -rf /usr/uninstall/CCcam_2.2.1-oscam_1.00-script_delfile.sh
rm -rf /usr/uninstall/CCcam-complete_2.2.1_delfile.sh

exit 0

