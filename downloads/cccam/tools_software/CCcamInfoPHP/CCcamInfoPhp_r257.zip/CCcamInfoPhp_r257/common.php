<?php
//___________________________________________________________________________________________________  
function detect_ie()
{
	global $browser;

	if( $browser->getBrowser() == Browser::BROWSER_IE )
		return true;
	else
		return false;
}
//___________________________________________________________________________________________________
function hasHTTPSwrapper()
{
	$w = stream_get_wrappers();
	return in_array('https', $w) ? true : false;
}
//___________________________________________________________________________________________________  
function seek_client($array_clientmessageport, $clientname)
{
	$index=-1;
	$i=-1;
	foreach ($array_clientmessageport as $value[])
	{
		$i++;
		if ($clientname == $value[$i][0])
			$index=$i;
	}				
	return $index;
}
//___________________________________________________________________________________________________   
function change_language($newlang)
{
	
	$myfile = "config.php";
	$config_data = file ($myfile);
	
	$fh = fopen($myfile, 'w') or die("can't open file");
	
	$seek_line1 = "\$language = \"";
	$seek_line2 = "\$language=\"";
	$config_line = "\$language = \"".$newlang."\";";
	$config_line = $config_line."\n";
	
	foreach ($config_data as $currentline) 
	{

		if (strstr($currentline,$seek_line1) || strstr($currentline,$seek_line2))
		{
			fwrite($fh, $config_line);
		}
		else
		{
			fwrite($fh, $currentline);
		}

	}
	fclose($fh);
	return 0;
}
//___________________________________________________________________________________________________   
function timpexec()
{
   $time = microtime();
   return $time;
}

$timpSTART = timpexec();

//___________________________________________________________________________________________________
function ENDPage()
{
   global $common_lv_pageloading;
   global $timpSTART;
   global $generic_lv_notice;
   global $generic_lv_collexp1;
   global $generic_lv_collexp2;
   global $generic_lv_memory;
   global $icon_height;
   global $icon_width;
   global $use_memory_statistics;
   global $use_debug_browser;
   global $browser;

   $timpEND = timpexec();
   $diferentaTIMP = number_format(((substr($timpEND,0,9)) + (substr($timpEND,-10)) - (substr($timpSTART,0,9)) - (substr($timpSTART,-10))),4);
   $TIMP_Page = "<BR>".$common_lv_pageloading." : <B>".$diferentaTIMP."</B>s";
   echo "<br><FONT COLOR=white>".$generic_lv_notice."</FONT><br>".$generic_lv_collexp1."<img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."'>".$generic_lv_collexp2."<br>";

   if($use_debug_browser)
   {
      echo "<br>";

      echo "<font color='#494949'>Browser : <b>".$browser->getBrowser()." ".$browser->getVersion()." </b>/<b> ".$browser->getPlatform()."</b></FONT>"; 
   }

   echo '<font color="#494949">'.$TIMP_Page.'</font>';

   if($use_memory_statistics &&  function_exists('memory_get_usage') ) 
   {
      $memorie_limita = ini_get('memory_limit');
      $memorie = ceil( memory_get_usage()/1024);
      $memorie_Page = "<BR>".$generic_lv_memory." : <B>".$memorie."</B> KB";
      echo '<font color="#494949">'.$memorie_Page.' / '.$memorie_limita.'</font>';
   }

   echo "<BR></BODY></HTML>";
}

error_reporting(E_ERROR | E_PARSE);
//error_reporting(E_ALL);

//-------------------------------------
// UPDATE - REDIRECT
//-------------------------------------
$forceupdate = "";   if(isset($_GET['forceupdate']))  $forceupdate = $_GET['forceupdate'];
$page = "";          if(isset($_GET['page']))         $page = $_GET['page'];
$newlang = "";       if(isset($_GET['language']))     $newlang = $_GET['language'];

if($forceupdate != "" && $page != "")
{
	if ($newlang!="")
		change_language($newlang);
	$pageRedirect = $page;
	$pageRedirect = $pageRedirect."?forceupdate=1";
	if ($sort != "") $pageRedirect = $pageRedirect."&sort=".$sort;
	header('Location: '.$pageRedirect);
	exit;
}
//-------------------------------------
// DEFAULTS - CONFIGURED in config.php
//-------------------------------------
$work_path = "";
$update_from_button = true;
$fullReshare = true;
$country_whois = true;
if (file_exists("config.php")) include "config.php";

//-------------------------------------
// ACTIVE PROFLE
//-------------------------------------

$active_profie = 0;
$filename_profile = "profile.ini";
$setProfil = "";  if(isset($_GET['setProfil'])) $setProfil = $_GET['setProfil'];

if ($setProfil != "")
{
   $active_profie = $setProfil;
   $fp = @fopen($filename_profile,"w");
   fwrite($fp, $setProfil."\n");
   fclose($fp);
}
else
if (isset($cron_profil) && isset($CCCamWebInfo[$cron_profil]))
{
   $active_profie = $cron_profil;
}
else
if (file_exists($filename_profile))
{
   $filename_profile_data = file ($filename_profile);
   $active_profie = (int)(trim($filename_profile_data[0]));

   if (!isset($CCCamWebInfo[$active_profie]))
   {
      $active_profie = 0;
      $fp = @fopen($filename_profile,"w");
      fwrite($fp, $active_profie."\n");
      fclose($fp);
   }
}

//-------------------------------------
// CRON PROFILE
//-------------------------------------

$filename_cronprofile = "cronprofile.ini";
if (!file_exists($filename_cronprofile))
{
   $fp = @fopen($filename_cronprofile,"w");
   fwrite($fp, INITIAL_CRONPROFILE."\n");
   fclose($fp);
}

//-------------------------------------
// CCCAM SERVER
//-------------------------------------

$cccam_host   = "";
$webinfo_port = "";
$webinfo_user = "";
$webinfo_pass = "";

if (isset($CCCamWebInfo[$active_profie]))
{
   $cccam_host = $CCCamWebInfo[$active_profie][0];

   $webinfo_port = "16001";
   $webinfo_user = "";
   $webinfo_pass = "";

   if (isset($CCCamWebInfo[$active_profie][1])) $webinfo_port      = $CCCamWebInfo[$active_profie][1];
   if (isset($CCCamWebInfo[$active_profie][1])) $webinfo_port      = $CCCamWebInfo[$active_profie][1];
   if (isset($CCCamWebInfo[$active_profie][2])) $webinfo_user      = $CCCamWebInfo[$active_profie][2];
   if (isset($CCCamWebInfo[$active_profie][3])) $webinfo_pass      = $CCCamWebInfo[$active_profie][3];
}

//-------------------------------------
// 
//-------------------------------------

//$update_info = false;
//$update_shares = false;
//$update_servers = false;
//$update_clients = false;
//$update_activeclients = false;
//$update_entitlements = false;

$skipUpdate = false;
$server_offline = false;

$str_empty = "0";

if(file_exists("version.php"))	include "version.php";

//-------------------------------------
// BROWSER
//-------------------------------------

if ($use_debug_browser)
{
   include "browser.php";
   $browser = new Browser();
}

//-------------------------------------
// PARAMS
//-------------------------------------

//$programversion = "CCcamInfoPHP";
if (detect_ie())
	$programversion = "CCcamInfoPHP ".$svn_revision." <img border=\"0\" src=\"images/public.png\" title='".$meniu_lv_disclosure_public."' align='middle'>";
else
	$programversion = "CCcamInfoPHP ".$svn_revision." <img border=\"0\" src=\"images/public.png\" title='".$meniu_lv_disclosure_public."' style='vertical-align:bottom'>";
// $programversion = "CCcamInfoPHP <img border=\"0\" src=\"images/public.png\" width='60' height='13' align='middle'>";

$pagina = $_SERVER['PHP_SELF'];
$uri = $_SERVER['REQUEST_URI'];
$pagina_secure = $_SERVER['HTTPS'];
$query_string = $_SERVER['QUERY_STRING'];

$sort = "";             if(isset($_GET['sort']))         $sort = $_GET['sort'];
$provider = "";         if(isset($_GET['provider']))     $provider = $_GET['provider'];
$node = "";             if(isset($_GET['node']))         $node = $_GET['node'];
$server_nodeDns = "";   if(isset($_GET['nodeDns']))      $server_nodeDns = $_GET['nodeDns'];
$username = "";   		  if(isset($_GET['username']))     $username = $_GET['username'];
$server_checkPing = ""; if(isset($_GET['checkPing']))    $server_checkPing = $_GET['checkPing'];
$server_checkPort = ""; if(isset($_GET['checkPort']))    $server_checkPort = $_GET['checkPort'];
$server_checkPort_recent = ""; if(isset($_GET['checkPortrecent']))    $server_checkPort_recent = $_GET['checkPortrecent'];
$server_search_dyndns_on_google = ""; if(isset($_GET['searchDynDnsonGoogle']))    $server_search_dyndns_on_google = $_GET['searchDynDnsonGoogle'];
$editor_checkFilter = ""; if(isset($_GET['checkFilter']))    $editor_checkFilter = $_GET['checkFilter'];
$serverstats_checkPayserver = ""; if(isset($_GET['checkPayserver']))	$serverstats_checkPayserver = $_GET['checkPayserver'];
$serverstats_manualCheckPayserver = ""; if(isset($_GET['manualCheckPayserver']))    $serverstats_manualCheckPayserver = $_GET['manualCheckPayserver'];
$serverstats_manualCheckKnownByGoogle = ""; if(isset($_GET['manualCheckKnownByGoogle']))    $serverstats_manualCheckKnownByGoogle = $_GET['manualCheckKnownByGoogle'];
$serverstats_updatePayserver = ""; if(isset($_GET['updatePayserver']))    $serverstats_updatePayserver = $_GET['updatePayserver'];
$pingAll = "";          if(isset($_GET['pingAll']))      $pingAll = $_GET['pingAll'];
$index_resetNodeStats = ""; if(isset($_GET['resetNodeStats']))    $index_resetNodeStats = $_GET['resetNodeStats'];
$index_resetStats = ""; if(isset($_GET['resetStats']))   $index_resetStats = $_GET['resetStats'];
$autorefresh = ""; if(isset($_GET['autorefresh']))       $autorefresh = $_GET['autorefresh'];
$reload_on_button = ""; if(isset($_GET['reloadonbutton']))       $reload_on_button = $_GET['reloadonbutton'];
$delete_unknown_sid = ""; if(isset($_GET['deleteUnknownSid']))    $delete_unknown_sid = $_GET['deleteUnknownSid'];

if(isset($_POST['nodeDns'])) $server_nodeDns = $_POST['nodeDns'];
if(isset($_POST['username'])) $username = $_POST['username'];
$NotesToSave = "__NOTDEFINDED__"; if(isset($_POST['saveNotes']))    $NotesToSave = $_POST['saveNotes'];
$WebIfLinkToSave = "__NOTDEFINDED__"; if(isset($_POST['saveWebIfLink']))    $WebIfLinkToSave = $_POST['saveWebIfLink'];
$CCcamWebIfLinkToSave = "__NOTDEFINDED__"; if(isset($_POST['saveCCcamWebIfLink']))    $CCcamWebIfLinkToSave = $_POST['saveCCcamWebIfLink'];
$ContactsToSave = "__NOTDEFINDED__"; if(isset($_POST['saveContacts']))    $ContactsToSave = $_POST['saveContacts'];
$RefreshIntervalToSave = "__NOTDEFINDED__"; if(isset($_GET['saveRefreshInterval']))    $RefreshIntervalToSave = $_GET['saveRefreshInterval'];
$cronupdate = ""; if(isset($_GET['cronupdate'])) $cronupdate = $_GET['cronupdate'];
$refreshupdate = ""; if(isset($_GET['refreshupdate'])) $refreshupdate = $_GET['refreshupdate'];
$exclude_portcheck = ""; if(isset($_GET['exclude_portcheck'])) $exclude_portcheck = $_GET['exclude_portcheck'];

//-------------------------------------
// PATHS & FILES
//-------------------------------------

$save_path        = $work_path.$cccam_host."/";
$global_save_path = $work_path.".global/";
$download_path    = $work_path.$cccam_host."/download/";
$notes_path       = $work_path.$cccam_host."/notes/";
$webiflink_path   = $work_path.$cccam_host."/webiflinks/";
$contacts_path    = $work_path.$cccam_host."/contacts/";
$backup_path      = $work_path.$cccam_host."/backup/";
$syslog_path      = $work_path.$cccam_host."/syslog/";
$refresh_path     = $work_path;
$cronupdate_path  = $work_path;
$cronupdate_file  = "cronupdate.ini";
$cronupdate_save_path = $cronupdate_path.$cronupdate_file;
$portcheck_path   = $work_path.$cccam_host."/portchecks/";
$reload_path      = $work_path;
//$online_path      = $work_path.$cccam_host."/online/";

if (!is_dir($global_save_path)) mkdir($global_save_path, 0777);
if ($cccam_host!="")
{
   if (!is_dir($save_path))        mkdir($save_path, 0777);
   if (!is_dir($download_path))    mkdir($download_path, 0777);
   if (!is_dir($notes_path))       mkdir($notes_path, 0777);
   if (!is_dir($webiflink_path))   mkdir($webiflink_path, 0777);
   if (!is_dir($contacts_path))    mkdir($contacts_path, 0777);
   if (!is_dir($backup_path))      mkdir($backup_path, 0777);
   if (!is_dir($syslog_path))      mkdir($syslog_path, 0777);
   if (!is_dir($portcheck_path))   mkdir($portcheck_path, 0777);
//   if (!is_dir($online_path))      mkdir($online_path, 0777);
}

$globalServersfile      = $global_save_path."servers.data";
$globalNodeIDfile       = $global_save_path."nodeid.data";
$ping_file              = $global_save_path."ping.data";

$update_log             = $save_path."update.log";
$country_file           = $save_path."country.data";
$pair_file              = $save_path."pair.data";
$ECM_file               = $save_path."ECM.data";
$online_file            = $save_path."online.data";
$usage_file             = $save_path."usage.data";
$usedProvidersFile      = "CCcam_used.providers";
$fakeProvidersFile      = "CCcam_fake.providers";
$unknownProvidersFile   = "CCcam_unknown.providers";
$portcheck_file		= $save_path."portcheck.data";

$countrycode_file       = "country.code";

$caminfo_update         = $download_path."caminfo.data";
$servers_update         = $download_path."servers.data";
$shares_update          = $download_path."shares.data";
$clients_update         = $download_path."clients.data";
$activeclients_update   = $download_path."activeclients.data";
$entitlements_update    = $download_path."entitlements.data";

$caminfo_file           = $save_path."caminfo.data";
$servers_file           = $save_path."servers.data";
$shares_file            = $save_path."shares.data";
$clients_file           = $save_path."clients.data";
$activeclients_file     = $save_path."activeclients.data";
$most_activeclients_file = $save_path."mostactiveclients.data";
$entitlements_file      = $save_path."entitlements.data";
$unknownsids_file	= $save_path."unknownsids.data";
$refresh_file		= "refresh.ini";
$refresh_save_path	= $refresh_path.$refresh_file;
$reload_file		= "reload.ini";
$reload_save_path	= $reload_path.$reload_file;

// notes
if ($NotesToSave != "__NOTDEFINDED__")
{
   list($notessave_DNS, $notessave_PORT) = explode(":", $server_nodeDns);
   $notes_save_path   = $notes_path.$notessave_DNS.".".$notessave_PORT.".note";  
   $fp = @fopen($notes_save_path,"w");
   fwrite($fp, $NotesToSave);
   fclose($fp);
}

// Newcamd, OSCam, Sbox web interface links
if ($WebIfLinkToSave != "__NOTDEFINDED__")
{
   list($webiflinksave_DNS, $webiflinksave_PORT) = explode(":", $server_nodeDns);
   $webif_link_save_path = $webiflink_path.$webiflinksave_DNS.".".$webiflinksave_PORT.".newcamd.link";
   $fp = @fopen($webif_link_save_path,"w");
   fwrite($fp, $WebIfLinkToSave);
   fclose($fp);
}

// CCcam web interface links
if ($CCcamWebIfLinkToSave != "__NOTDEFINDED__")
{
   $webif_link_save_name = "";
   if ($username != "")
	$webif_link_save_name = $username.".CCcam-s2s.client";
   else
   if ($server_nodeDns != "")
   {
      list($webiflinksave_DNS, $webiflinksave_PORT) = explode(":", $server_nodeDns);
      $webif_link_save_name = $webiflinksave_DNS.".".$webiflinksave_PORT.".CCcam-s2s.server";
   }
   if ($webif_link_save_name != "")
   {
      $webif_link_save_path = $webiflink_path.$webif_link_save_name.".link";
      $fp = @fopen($webif_link_save_path,"w");
      fwrite($fp, $CCcamWebIfLinkToSave);
      fclose($fp);
   }
}

// contacts
if ($ContactsToSave != "__NOTDEFINDED__")
{
   if ($server_nodeDns != "")
   {
      list($contactssave_DNS, $contactssave_PORT) = explode(":", $server_nodeDns);
      $contacts_save_path   = $contacts_path.$contactssave_DNS.".".$contactssave_PORT.".server.contact";
      $fp = @fopen($contacts_save_path,"w");
      fwrite($fp, $ContactsToSave);
      fclose($fp);
   }
}

// autorefresh
if (!file_exists($refresh_save_path))
{
   $fp = @fopen($refresh_save_path,"w");
   if ($initial_refresh_active)
      fwrite($fp, "yes"."\n");
   else
      fwrite($fp, "no"."\n");
   fwrite($fp, $initial_refresh_interval);
   fclose($fp);	
}

if ($RefreshIntervalToSave != "__NOTDEFINDED__")
{
   $refresh = file($refresh_save_path);
   if ((int)(trim($RefreshIntervalToSave)) < 1)
	$RefreshIntervalToSave = $initial_refresh_interval;
   $refresh[1] = $RefreshIntervalToSave;
   $fp = @fopen($refresh_save_path,"w");
   fwrite($fp, $refresh[0]);
   fwrite($fp, $refresh[1]);
   fclose($fp);
}

if (strstr($autorefresh, "yes"))
{
   $refresh = file($refresh_save_path);
   $fp = @fopen($refresh_save_path,"w");
   fwrite($fp, "yes"."\n");
   fwrite($fp, $refresh[1]);
   fclose($fp);
}
else if (strstr($autorefresh, "no"))
{
   $refresh = file($refresh_save_path);
   $fp = @fopen($refresh_save_path,"w");
   fwrite($fp, "no"."\n");
   fwrite($fp, $refresh[1]);
   fclose($fp);
}

// crond update
if (!file_exists($cronupdate_save_path) || $use_embedded_webserver) // set initial state, if embedded webserver is used
{
   $fp = @fopen($cronupdate_save_path,"w");
   if ($initial_cronupdate_active)
      fwrite($fp, "yes"."\n");
   else
      fwrite($fp, "no"."\n");
   fclose($fp);
}

if (strstr($cronupdate, "yes"))
{
   $fp = @fopen($cronupdate_save_path,"w");
   fwrite($fp, "yes"."\n");
   fclose($fp);
}
else if (strstr($cronupdate, "no"))
{
   $fp = @fopen($cronupdate_save_path,"w");
   fwrite($fp, "no"."\n");
   fclose($fp);
}

// reload on button
if (!file_exists($reload_save_path))
{
   $fp = @fopen($reload_save_path,"w");
   if ($initial_reload_active)
      fwrite($fp, "yes"."\n");
   else
      fwrite($fp, "no"."\n");
   fclose($fp);
}

if (strstr($reload_on_button, "yes"))
{
   $fp = @fopen($reload_save_path,"w");
   fwrite($fp, "yes"."\n");
   fclose($fp);
}
else if (strstr($reload_on_button, "no"))
{
   $fp = @fopen($reload_save_path,"w");
   fwrite($fp, "no"."\n");
   fclose($fp);
}

if (file_exists($countrycode_file)) $countrycode_data = file ($countrycode_file);
if (file_exists($country_file))     $country_data     = file ($country_file);

define('INT_SECOND', 1);
define('INT_MINUTE', 60);
define('INT_HOUR', 3600);
define('INT_DAY', 86400);
define('INT_WEEK', 604800);

//-------------------------------------
// FUNCTIONS
//-------------------------------------

//___________________________________________________________________________________________________
function flush_buffers()
{
    ob_end_flush(); 
    ob_flush(); 
    flush();
    ob_start(); 
} 
//___________________________________________________________________________________________________
function formula_usage($timp, $ecm)
{
	list($zile,$rest) =  explode("d ",$timp);
	list($ore,$minute,$secunde) =  explode(":",$rest);
	$timpconectat = $zile*86400 + $ore*3600 + $minute*60 + $secunde;
	
	$indexECM = ((int)((3600*$ecm)/($timpconectat)));
	 
	//if ($timpconectat<60) $indexECM = (int)($indexECM/2); 
	
	if ($ecm>0) $indexECM = $indexECM + 1;
	
	return $indexECM;
}
//___________________________________________________________________________________________________
function formatted_timediff($timediff)
{
	
	global $common_lv_weeks,$common_lv_week;
	global $common_lv_days,$common_lv_day;
	global $common_lv_hours,$common_lv_hour;
	global $common_lv_mins,$common_lv_min;
	global $common_lv_secs,$common_lv_sec;
	
	$weeks    = (int) intval($timediff / INT_WEEK);
	$timediff = (int) intval($timediff - (INT_WEEK * $weeks));
	$days     = (int) intval($timediff / INT_DAY);
	$timediff = (int) intval($timediff - (INT_DAY * $days));
	$hours    = (int) intval($timediff / INT_HOUR);
	$timediff = (int) intval($timediff - (INT_HOUR * $hours));
	$mins     = (int) intval($timediff / INT_MINUTE);
	$timediff = (int) intval($timediff - (INT_MINUTE * $mins));
	$sec      = (int) intval($timediff / INT_SECOND);
	$timediff = (int) intval($timediff - ($sec * INT_SECOND));
	
	$str = '';
	if ( $weeks )
	{
	  $str .= intval($weeks);
	  $str .= ($weeks > 1) ? ' '.$common_lv_weeks : ' '.$common_lv_week;
	}
	
	if ( $days )
	{
	  $str .= ($str) ? ', ' : '';
	  $str .= intval($days);
	  $str .= ($days > 1) ? ' '.$common_lv_days : ' '.$common_lv_day;
	}
	
	if ( $hours )
	{
	  $str .= ($str) ? ', ' : '';
	  $str .= intval($hours);
	  $str .= ($hours > 1) ? ' '.$common_lv_hours : ' '.$common_lv_hour;
	}
	
	if ( $str == "" && $mins )
	{
	  $str .= ($str) ? ', ' : '';
	  $str .= intval($mins);
	  $str .= ($mins > 1) ? ' '.$common_lv_mins : ' '.$common_lv_min;
	}
	
	if ( $str == "" && $sec )
	{
	  $str .= ($str) ? ', ' : '';
	  $str .= intval($sec);
	  $str .= ($sec > 1) ? ' '.$common_lv_secs : ' '.$common_lv_sec;
	}
	
	return $str;
}
//___________________________________________________________________________________________________
function get_formatted_timediff($then, $now = false)
{
    $now      = (!$now) ? time() : $now;
    $timediff = ($now - $then);
    $str = formatted_timediff($timediff);
    
    return $str;
}
//___________________________________________________________________________________________________
function filesuck ($dnsadd, $dnsport, $dnsuser, $dnspass, $dnspath, $filename="", $timeout=10 )
{
   $out  = "GET $dnspath HTTP/1.1\r\n";
   $out .= "Host: ".$dnsadd."t\r\n";
   $out .= "Connection: Close\r\n";
   $out .= "Authorization: Basic ".base64_encode($dnsuser.":".$dnspass)."\r\n";
   $out .= "\r\n";

   if (!$conex = @fsockopen($dnsadd, $dnsport, $errno, $errstr, $timeout))
       return 0;
   fwrite($conex, $out);
   $data = '';
   while (!feof($conex)) {
       $data .= fgets($conex, 512);
   }
   fclose($conex);
   $somecontent = $data;


   if ($filename=="")
   {
      return $somecontent;
   }
   else
   {
      if (file_exists($filename)) unlink($filename);
      touch ($filename);
      if (is_writable($filename))
      {
         if (!$handle = fopen($filename, 'a'))
         {
            echo "Cannot open file ($filename)";
            exit;
         }
         fwrite($handle, $somecontent);
         fclose($handle);
      }
      else {echo "The file $filename is not writable";}
   }
}
//___________________________________________________________________________________________________
function fstripos($string,$word)
{
   $retval = -1;
   for($i=0;$i<=strlen($string);$i++)
   {
       if (strtolower(substr($string,$i,strlen($word))) == strtolower($word))
       {
           $retval = $i;
       }
   }
   return $retval;
}
//___________________________________________________________________________________________________
function stripcontents($contents)
{
   $strip_contents = strip_tags($contents,'<BR><H2>');

   $pos=fstripos($strip_contents, "<H2>");
   if ($pos!=-1)
   {
      $strip_contents = substr($strip_contents, $pos);
      $strip_contents = str_replace("</H2>","</H2>\n",$strip_contents);
   }

   return $strip_contents;
}
//___________________________________________________________________________________________________
function stripdata($filename)
{
   $contents=file_get_contents($filename);
   $strip_contents = stripcontents($contents);

   $f=@fopen($filename,"w");
   if ($f)
   {
      fwrite($f,$strip_contents);
     fclose($f);
   }
}
//___________________________________________________________________________________________________
function CCcamUptime()
{
	global $caminfo_file;
	
	$caminfo_data = file ($caminfo_file);
	foreach ($caminfo_data as $currentline) 
	{
		$liniesplit = explode("<BR>", $currentline);
		foreach ($liniesplit as $linie) 
		{
			if (strstr($linie,"Uptime"))
			{
				$temp = explode(" ",$linie,2);
				$CCcamUptime = $temp[1];
			}
		}
	}
	return trim($CCcamUptime);
}
//___________________________________________________________________________________________________
function loadUsageData()
{
   global $usage_file;
   global $UsageUsers;
   
   $usage_data = file ($usage_file);
   foreach ($usage_data as $currentline)
   {
      list($DNS, $TIME, $USAGE) = explode("|", $currentline);
      $USER_IP = "";
      if (fstripos($DNS, "/")!=-1)
      {
         list($DNS, $USER_IP) = explode("/", $DNS);
      }

      $DNS = trim($DNS);
      $USAGE = trim($USAGE);
      $USER_IP = trim($USER_IP);

      if (isset($TIME))
      {
         $TIME = trim($TIME);
         $UsageUsers[$DNS]["time"] = $TIME;
         $UsageUsers[$DNS]["usage"] = $USAGE;
         $UsageUsers[$DNS]["ip"] = $USER_IP;
      }
   }
}
//___________________________________________________________________________________________________
function saveUsageData($clients_data)
{
	$saveTime = time();
	   
   global $usage_file;
   global $UsageUsers;
   global $ClientECMCounter210;
   
   loadUsageData();

   $modificat = false;
  
   foreach ($clients_data as $currentline) 
	{
		$inceput1 = substr($currentline,0,1);
		$inceput2 = substr($currentline,1,2);
		if (strstr($currentline,"| Shareinfo")) break; 	

		if ($inceput1 == "|" && $inceput2 != " U")
		{
			$active_client 		= explode("|", $currentline);
			$ac_Username 			= trim($active_client[1]);
			$ac_IP 					= trim($active_client[2]);
			if ($ClientECMCounter210)
				$ac_Connected 		= CCcamUptime();
			else
				$ac_Connected 			= trim($active_client[3]);
			$ac_Idle 				= trim($active_client[4]);
			$ac_ECM 					= trim($active_client[5]);
			$ac_EMM 					= trim($active_client[6]);
			$ac_Version				= trim($active_client[7]);
			$ac_LastShare			= trim($active_client[8]);
			
			$ac_EcmTime	= "";  
			if (isset($active_client[9]))	
				$ac_EcmTime	= trim($active_client[9]);
			
			list($acEcm,$acEcmOk) = explode("(", $ac_ECM);
			list($acEcmOk,$temp) = explode(")", $acEcmOk);
			
			list($acEmm,$acEmmOk) = explode("(", $ac_EMM);
			list($acEmmOk,$temp) = explode(")", $acEmmOk);
			
			$indexECM = formula_usage($ac_Connected, $ac_ECM);
			
			
			list($zile,$rest) =  explode("d ",$ac_Connected);
			list($ore,$minute,$secunde) =  explode(":",$rest);
			$minuteConectat = 1 + $zile*24*60 + $ore*60 + $minute;
			
			$timediff = 0;
			if ($UsageUsers[$ac_Username]["time"] != "")
				$timediff = ($saveTime - $UsageUsers[$ac_Username]["time"]);
				
			$minuteDiff  = (int) intval($timediff / INT_MINUTE);
			
			
			$SaveIndexECM = $UsageUsers[$ac_Username]["usage"];
			list($lastIndexEcm,$averageIndexEcm) = explode(".", $SaveIndexECM,2);
			
			if ($minuteConectat < $minuteDiff) // fac media
			{
				if (isset($averageIndexEcm) && $averageIndexEcm!="")
					$averageIndexEcm = (int)(( $lastIndexEcm + $averageIndexEcm*3)/4);
				else
				if (isset($lastIndexEcm) && $lastIndexEcm!="")
					$averageIndexEcm = $indexECM;
				
			}
//			if ($averageIndexEcm > 4000) $averageIndexEcm = $lastIndexECM;
			if ($averageIndexEcm > 4000) $averageIndexEcm = $indexECM;

			$lastIndexEcm = $indexECM;
			
			
			$UsageUsers[$ac_Username]["usage"]  = $lastIndexEcm.".".$averageIndexEcm;
			$UsageUsers[$ac_Username]["time"] = $saveTime;
         $modificat = true;
		}
		else
		if (strstr($currentline,"Welcome to CCcam"))
		{
			$temp = explode("H2>", $currentline,3);
			$Headline = $temp[1];
			$temp = explode(" ", $Headline);
			$CCcamVer = $temp[3];
			$temp = explode(".", $CCcamVer);
			if (trim($temp[0]) >= "2")
				if (trim($temp[1]) >= "1") 
					$ClientECMCounter210 = true;
				else
					$ClientECMCounter210 = false;
			else
				$ClientECMCounter210 = true;
		}
	}

   if ($modificat == true)
   {
   	
      $fp = @fopen($usage_file,"w");
      
      fwrite($fp, "savetime|".$saveTime."|"."\n");
      foreach ($UsageUsers as $User => $Usage)
      {
      	if ($User != "savetime")
         	fwrite($fp, $User."|".$Usage["time"]."|".$Usage["usage"]."\n");
      }
      fclose($fp);
   }
}
//___________________________________________________________________________________________________
function VerificLog($DNS)
{
	global $OnlineServers;
	$online_history = $OnlineServers[$DNS]["log"];
	
	$logtime = explode(".", $online_history);
	
	$maxim = 40320; // 28 zile
	$tot = 0;
	$str = "";
	
	foreach ($logtime as $log)
   {
   	$v = $log;
   	$semn = "";
   	if (strstr($log,"-"))
   	{
   		$semn = "-";
   		$v = substr($log,1);
   	}
   		
   	if ($str!="") $str = $str.".";
   	$tot = $tot + $v;
  	
   	
   	if ($tot > $maxim) // am depasit
   	{
   		$ramaslog = $v - ($tot - $maxim);
   		$str = $str.$semn.$ramaslog;
   		break;
   	}
   	else
   	{
   		$str = $str.$log;
   	}
 	
	}
	
	if ($str != $online_history)
	{
		$OnlineServers[$DNS]["log"] = $str;
	}
}
//___________________________________________________________________________________________________
function saveOnlineData($servers_data)
{
   $saveTime = time();
	   
   global $online_file;
   global $OnlineServers;
   
   loadOnlineData();

   $modificat = false;
   
   $minuteConectatMaxim = 0;
	foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host      = trim($server[1]);
         $server_Time      = trim($server[2]);
         if ($server_Host != "" && $server_Time != "")
         {
            list($zile,$rest) =  explode("d ",$server_Time);
            list($ore,$minute,$secunde) =  explode(":",$rest);
            $minuteConectat = 1 + $zile*24*60 + $ore*60 + $minute;
				
            if ($minuteConectatMaxim < $minuteConectat && $minuteConectat < 1000000)
               $minuteConectatMaxim = $minuteConectat;
         }	
      }
   }
	
   if ($minuteConectatMaxim < 2)
      return;
		
   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host      = trim($server[1]);
         $server_Time      = trim($server[2]);
         
         $logtime = $OnlineServers[$server_Host]["log"];
         
         if ($server_Host != "" && $server_Time == "") // offline
         {
            $timediff = 0;
            if ($OnlineServers[$server_Host]["time"] != "")
               $timediff = ($saveTime - $OnlineServers[$server_Host]["time"]);

            $minuteOffline  = (int) intval($timediff / INT_MINUTE);

            if ($logtime!="")
            {
               list($lastlogtime,$logtimenew) = explode(".", $logtime,2);
               if (isset($lastlogtime) && $lastlogtime!="")
               {
                  if ($lastlogtime > 0)
                     $logtime = "-".$minuteOffline.".".$logtime;
                  else
                  if ($logtimenew=="")
                     $logtime = "-".$minuteOffline;
                  else
                     $logtime = "-".$minuteOffline.".".$logtimenew;
               }
            }

            $OnlineServers[$server_Host]["log"]  = $logtime;
            $modificat = true;
      	}
      	else
         if ($server_Host != "" && $server_Time != "") // online
         {
         	list($zile,$rest) =  explode("d ",$server_Time);
				list($ore,$minute,$secunde) =  explode(":",$rest);
				$minuteConectat = 1 + $zile*24*60 + $ore*60 + $minute;
				
				if ($minuteConectat > 1000000)
					$minuteConectat = $minuteConectatMaxim;
				
				$timediff = 0;
				if ($OnlineServers[$server_Host]["time"] != "")
					$timediff = ($saveTime - $OnlineServers[$server_Host]["time"]);
				
			   $minuteLastSave  = (int) intval($timediff / INT_MINUTE);
		   
			    
			   if ($logtime=="")
			  		$logtime = $minuteConectat;
			  	else
			   {
			   	if ($minuteConectat > $minuteLastSave)
			      	$minuteConectatADD = $minuteLastSave;
			      else
			      	$minuteConectatADD = $minuteConectat;
			      
			      list($lastlogtime,$logtimenew) = explode(".", $logtime,2);
			      
			      if (isset($lastlogtime) && $lastlogtime!="")
			      {
			      	if ($lastlogtime > 0)
			      		$minuteConectat = $minuteConectatADD+$lastlogtime;
			      	else
			      	{
			      		$logtimenew = $logtime;
			      	}
			      }
			      
			      if ($logtimenew == "")
		      		$logtime = $minuteConectat;
		      	else
		      		$logtime = $minuteConectat.".".$logtimenew;
			   }

				$OnlineServers[$server_Host]["time"] = $saveTime;
            $OnlineServers[$server_Host]["log"]  = $logtime;
            $modificat = true;
         }
         
         
         VerificLog($server_Host);
      }
   }

   if ($modificat == true)
   {
   	
      $fp = @fopen($online_file,"w");
      
      fwrite($fp, "savetime|".$saveTime."|"."\n");
      foreach ($OnlineServers as $OnlineHost => $OnlineTime)
      {
      	if ($OnlineHost != "savetime")
         	fwrite($fp, $OnlineHost."|".$OnlineTime["time"]."|".$OnlineTime["log"]."\n");
      }
      fclose($fp);
   }
}
//___________________________________________________________________________________________________
function procentOnline($DNS)
{
	global $OnlineServers;
	
	if (!isset($OnlineServers))
		loadOnlineData();
		
	// online history
   //$online_saveTime = $OnlineServers["savetime"]["time"];
   //$online_lastseen = $OnlineServers[$DNS]["time"];
   $online_history  = $OnlineServers[$DNS]["log"];
   
   $minute_off = 0;
   $minute_on = 0;
   /*
   if ($online_saveTime != $online_lastseen)
   {
   	$timediff = ($online_saveTime - $online_lastseen);
	   $minute_off  = (int) intval($timediff / INT_MINUTE);
   }
   */
   
   $logtime = explode(".", $online_history);
   foreach ($logtime as $log)
   {
   	if (strstr($log,"-"))
   	{
   		$minute_off = $minute_off + substr($log,1);
   	}
   	else 	
   	{
   		$minute_on = $minute_on + $log;
   	}
	}
	
   
   $procent = round(($minute_on/($minute_off +$minute_on) *100),1);
	return $procent;
}
//___________________________________________________________________________________________________
function loadOnlineData()
{
   global $online_file;
   global $OnlineServers;
   
   $online_data = file ($online_file);
   foreach ($online_data as $currentline)
   {
      list($DNS, $TIME, $LOG) = explode("|", $currentline);
      $DNS = trim($DNS);
      $LOG = trim($LOG);

      if (isset($TIME))
      {
     		$TIME = trim($TIME);
         $OnlineServers[$DNS]["time"] = $TIME;
         $OnlineServers[$DNS]["log"] = $LOG;
      }
   }
}
//___________________________________________________________________________________________________
function checkFile($File)
{
	global $generic_lv_serverdown;
	
	if (file_exists($File))
	{
	  $servers_data = file ($File);
	
	  if (count($servers_data) <1)
	  {
	     echo "<FONT COLOR=red>".$generic_lv_serverdown." !</FONT>";
	     exit;
	  }
	
	  if (count($servers_data) <6)
	  {
	     echo "<FONT COLOR=red>".$servers_data[0]."</FONT>";
	     exit;
	  }
	
	}
	else
	{
	  exit;
	}
}
//___________________________________________________________________________________________________
function pingResultColor($ping,$showping = 0)
{
	global $common_lv_pingverybad,$common_lv_pingveryslow,$common_lv_pingslow,$common_lv_pinggood,$common_lv_pingverygood,$common_lv_pingexcellent,$common_lv_notsaved;

	$textPing = "";
	if ($showping ==1 && $ping != "" && $ping>0)
		$textPing = "<FONT COLOR=white>".$ping."</FONT><FONT COLOR=gray>ms </FONT>";
	
   if     ($ping>300)   $textPing = $textPing."<FONT color=red>[".$common_lv_pingverybad."]</FONT>";
   elseif ($ping>200)   $textPing = $textPing."<FONT color=\"#C11B17\">[".$common_lv_pingveryslow."]</FONT>";
   elseif ($ping>130)   $textPing = $textPing."<FONT color=orange>[".$common_lv_pingslow."]</FONT>";
   elseif ($ping>80)    $textPing = $textPing."<FONT color=yellow>[".$common_lv_pinggood."]</FONT>";
   elseif ($ping>40)    $textPing = $textPing."<FONT color=green>[".$common_lv_pingverygood."]</FONT>";
   else                 $textPing = $textPing."<FONT color=\"#5EFB6E\">[".$common_lv_pingexcellent."]</FONT>";
   if     ($ping == 0)  $textPing = $common_lv_notsaved;
 
 	return $textPing;  
}
//___________________________________________________________________________________________________
function procentColor($procent)
{
   $ret = "";
   
   if      ($procent <20) $ret = "<FONT COLOR=red>".$procent."%</FONT>";
   else if ($procent <50) $ret = "<FONT COLOR=orange>".$procent."%</FONT>";
   else if ($procent <80) $ret = "<FONT COLOR=yellow>".$procent."%</FONT>";
   else if ($procent <90) $ret = "<FONT COLOR=green>".$procent."%</FONT>";
   else                   $ret = "<FONT COLOR=#10f180>".$procent."%</FONT>";
   
   return $ret;
}
//___________________________________________________________________________________________________
function pingColor($pingSalvat)
{
   $ret = "";
   if       ($pingSalvat[0] == "") $ret = "&nbsp;?&nbsp;";
   else if  ($pingSalvat[0]<40)    $ret = "<FONT COLOR=\"#5EFB6E\">".$pingSalvat[0]."</FONT>";
   else if  ($pingSalvat[0]<80)    $ret = "<FONT COLOR=green>".$pingSalvat[0]."</FONT>";
   else if  ($pingSalvat[0]<130)   $ret = "<FONT COLOR=yellow>".$pingSalvat[0]."</FONT>";
   else if  ($pingSalvat[0]<200)   $ret = "<FONT COLOR=orange>".$pingSalvat[0]."</FONT>";
   else if  ($pingSalvat[0]<300)   $ret = "<FONT COLOR=\"#C11B17\">".$pingSalvat[0]."</FONT>";
   else                            $ret = "<FONT COLOR=red>".$pingSalvat[0]."</FONT>";
   
   if (isset($pingSalvat[2]))
   {
   	$diffPing = $pingSalvat[0] - $pingSalvat[2];
   	$diffMargin = (int)($pingSalvat[2] * 50/100);
   	if ($diffMargin < 50) $diffMargin  = 50;
   	if ($diffPing > $diffMargin ) $ret = "<FONT COLOR=red><B>! </B></FONT>".$ret."&nbsp;&nbsp;";
   }
		
   return $ret;
}    
//___________________________________________________________________________________________________
function pingColorBest($pingSalvat)
{
   $ret = "";
   if       ($pingSalvat[0] == "") $ret = "&nbsp;?&nbsp;";
   else if  ($pingSalvat[2]<40)  $ret = "<FONT COLOR=\"#5EFB6E\">".$pingSalvat[2]."</FONT>";
   else if  ($pingSalvat[2]<80) 	$ret = "<FONT COLOR=green>".$pingSalvat[2]."</FONT>";
   else if  ($pingSalvat[2]<130) $ret = "<FONT COLOR=yellow>".$pingSalvat[2]."</FONT>";
   else if  ($pingSalvat[2]<200) $ret = "<FONT COLOR=orange>".$pingSalvat[2]."</FONT>";
   else if  ($pingSalvat[2]<300) $ret = "<FONT COLOR=\"#C11B17\">".$pingSalvat[2]."</FONT>";
   else                          $ret = "<FONT COLOR=red>".$pingSalvat[2]."</FONT>";
   
   return $ret;
}                      
//___________________________________________________________________________________________________
function format1($titlu,$v1="",$v2=-1,$v3=true)
{
       $ret = "";
       
       $ret = "".$titlu." : ";
       $ret.="<B><FONT COLOR=white>".$v1."</FONT></B>";
       if ($v2>0)
       {
               $procent = (int)($v1/$v2 *100);
               $procentAfisat = procentColor($procent);
               $ret.=" / ".$v2." (<B>".$procentAfisat."</B>)";
       }
       if ($v3)
	       $ret.="<BR>";
       
       echo $ret;
}
//___________________________________________________________________________________________________
function format2($titlu,$v1="",$v2="")
{
       global $country_flags_path;

       $ret = "";

       $ret = "".$titlu." : ";
       $ret.="<img border='0' src='".$country_flags_path.$v1.".gif' alt='".$v1."'>";
       $ret.="<B><FONT COLOR=white> , ".$v2."</FONT></B>";
       $ret.="<BR>";

       echo $ret;
}
//___________________________________________________________________________________________________
function format3($last_share)
{
	global $use_formatted_lastshare;

	$ret = "";

	if($use_formatted_lastshare && strstr($last_share,"["))
	{
		list($last_share_head, $last_share_remainer) = explode("[",$last_share);
		list($last_share_provider, $last_share_tail) = explode("]",$last_share_remainer);
		$ret = $last_share_head."<FONT COLOR=\"#555555\">[".$last_share_provider."]</FONT>".$last_share_tail;
	}
	else
		$ret = $last_share;

	return $ret;
}
//___________________________________________________________________________________________________
function get_files_in_dir($dir)
{
        unset($files);
        if (is_dir($dir))
        {
                if ($handle = opendir($dir))
                {
                        $files = array();
                        while (false !== ($file = readdir($handle)))
                        {
                                if (is_file($dir."/".$file))
                                {
                                        $files[] = $file;
                                }
                        }
                }
                closedir($handle);
                if (is_array($files))
                        sort($files);
        }
	return $files;
}
//___________________________________________________________________________________________________
function showNotice($text)
{
	global $generic_lv_notice;

	echo "<FONT COLOR=white>".$generic_lv_notice."</FONT><br>";
	echo $text;
        echo "<br>";
}
//___________________________________________________________________________________________________
function showFile($file,$lines="24",$columns="80",$headline="")
{
        if (file_exists($file))
        {
	        if ($headline!="")
	                echo "<br><FONT COLOR=white><b>".$headline."</b></FONT><br>";

		echo "<textarea readonly class='TEXTAREANORMAL' cols=$columns name='showFile' rows=$lines>";
        
		$array = file($file);
		for ( $i = 0; $i < count ( $array ); $i++ ){
			echo $array[$i];
		}

		echo "</textarea>";

		return true;
        }
	return false;
}
//___________________________________________________________________________________________________
function showChangelog()
{
	global $changeloggeometry;
	global $language;
	global $generic_lv_no_language_specific_changelog;
	global $generic_lv_no_changelog;

	$changelog_public = "changelog/Changelog_".$language;
	$changelog_nonpublic = "nonpublic/changelog/Changelog_".$language;
	$changelog_private = "private/changelog/Changelog_".$language;

	if (!file_exists($changelog_public))
	{
		$changelog_public = "changelog/Changelog_EN";
		$changelog_nonpublic = "nonpublic/changelog/Changelog_EN";
		$changelog_private = "private/changelog/Changelog_EN";

		if (file_exists($changelog_public))
			echo "<br><FONT COLOR=red>".$generic_lv_no_language_specific_changelog."</FONT><br>";
	}

	if (file_exists($changelog_public))
	{
		echo "<br><FONT COLOR=white><b>Changelog</b></FONT><br>";
		echo "<textarea readonly class='TEXTAREANORMAL' rows=$changeloggeometry[0] name='showFile' cols=$changeloggeometry[1]>";

		$array_public = file($changelog_public);

		$array = $array_public;

		if (file_exists($changelog_nonpublic))
		{
			$array[] = "\n";
			$array_nonpublic = file($changelog_nonpublic);
			$array = array_merge($array, $array_nonpublic);

			if (file_exists($changelog_private))
			{
				$array[] = "\n";
				$array_private = file($changelog_private);
				$array = array_merge($array, $array_private);
			}
		}

		for ( $i = 0; $i < count ( $array ); $i++ ){
			echo $array[$i];
		}

		echo "</textarea>";
	}
	else
		echo "<br><FONT COLOR=red>".$generic_lv_no_changelog."</FONT>";
}
//___________________________________________________________________________________________________
function resetNodeStats($server)
{
	global $resetstatistics;
	global $common_lv_ok;
	global $common_lv_not_ok;
	global $common_lv_no_files_in_dir;
	global $common_lv_file_does_not_exist;
	global $common_lv_resetnodestats_title;
	global $common_lv_resetnodestats_title_statistic;
	global $common_lv_resetnodestats_title_reset;
	global $common_lv_resetnodestats_title_files;
	global $common_lv_resetnodestats_reset_yes;
	global $common_lv_resetnodestats_reset_no;
	global $use_resetstatistics_status_icons;
	global $icon_width;
	global $icon_height;

	if ($server!="")
	{
		echo "<br>".$common_lv_resetnodestats_title." : <FONT COLOR=white><b>".$server."</b></FONT><br>";
		echo "<table border=0 cellpadding=2 cellspacing=1>";
		echo "<tr>";
		echo "<th class=\"tabel_headerc\">#</th>";
		echo "<th class=\"tabel_header\">".$common_lv_resetnodestats_title_statistic."</th>";
		echo "<th class=\"tabel_headerc\">".$common_lv_resetnodestats_title_reset."</th>";
		echo "<th class=\"tabel_headerc\">".$common_lv_resetnodestats_title_files."</th>";
		echo "<th class=\"tabel_headerc\">Status</th>";
		echo "</tr>";

		for ( $i = 0; $i < count ( $resetstatistics ); $i++ ){
			echo "<td class=\"Node_count\">".$i."</td>";
			echo "<td class=\"Node_ID\">".$resetstatistics[$i][0]."</td>";
			if ($resetstatistics[$i][2] == true)
				echo "<td class=\"tabel_hop_total2\">".$common_lv_resetnodestats_reset_yes."</td>";
			else
				echo "<td class=\"tabel_hop_total2\">".$common_lv_resetnodestats_reset_no."</td>";
			if ($resetstatistics[$i][1] == "")
			{
				$dir = $server."/";
				$file = $dir.$resetstatistics[$i][0];
				if (file_exists($file))
					echo "<td class=\"tabel_hop_total2\">".$file."</td>";
				else
					echo "<td class=\"tabel_hop_total2\">".$file." <FONT COLOR=red>".$common_lv_file_does_not_exist."</FONT></td>";
			}
			else
			{
				$dir = $server."/".$resetstatistics[$i][1];
				$files = get_files_in_dir($dir);
				echo "<td class=\"tabel_hop_total2\">";
				if (count($files))
				{
					echo "<table border=0 cellpadding=2 cellspacing=1>";
					echo "<tr>";
					foreach ($files as $file)
					{
						echo "<td class=\"tabel_hop_total2\">";
						echo $dir.$file."</td></tr>";
					}
					echo "</table>";
				}
				else
					echo "<FONT COLOR=red>".$common_lv_no_files_in_dir."</FONT>";
				echo "</td>";
			}
			
			if ($resetstatistics[$i][2] == "true")
			{
				if ($resetstatistics[$i][1] == "")
				{
					$dir = $server."/";
					$file = $dir.$resetstatistics[$i][0];
					if (file_delete($file))
					{
						if ($use_resetstatistics_status_icons)
							echo "<td class=\"tabel_hop_total2\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_ok.png\" width='".$icon_width."' height='".$icon_height."'></td></tr>";
						else
							echo "<td class=\"tabel_hop_total2\"><FONT COLOR=green>".$common_lv_ok."</FONT></td>";
					}
					else
					{
						if ($use_resetstatistics_status_icons)
							echo "<td class=\"tabel_hop_total2\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_not_ok.png\" width='".$icon_width."' height='".$icon_height."'></td></tr>";
						else
							echo "<td class=\"tabel_hop_total2\"><FONT COLOR=red>".$common_lv_not_ok."</FONT></td>";
					}
				}
				else
				{
					$dir = $server."/".$resetstatistics[$i][1];
					$files = get_files_in_dir($dir);
					echo "<td class=\"tabel_hop_total2\">";
					if (count($files))
					{
						echo "<table border=0 cellpadding=2 cellspacing=1>";
						echo "<tr>";
						foreach ($files as $file)
						{
                                                	if (file_delete($dir.$file))
							{
								if ($use_resetstatistics_status_icons)
									echo "<td class=\"tabel_hop_total2\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_ok.png\" width='".$icon_width."' height='".$icon_height."'></td></tr>";
								else
									echo "<td class=\"tabel_hop_total2\"><FONT COLOR=green>".$common_lv_ok."</FONT></td></tr>";
							}
							else
							{
								if ($use_resetstatistics_status_icons)
									echo "<td class=\"tabel_hop_total2\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_not_ok.png\" width='".$icon_width."' height='".$icon_height."'></td></tr>";
								else
									echo "<td class=\"tabel_hop_total2\"><FONT COLOR=red>".$common_lv_not_ok."</FONT></td></tr>";
							}
						}
						echo "</table>";
					}
					else
						echo "<FONT COLOR=red>".$common_lv_no_files_deleted."</FONT>";
					echo "</td>";
				}
			}
			else
				echo "<td class=\"tabel_hop_total2\">n/a</td>";

			echo "</tr>";
		}
		echo "</table>";
	}
	else
		return false;
	return true;
}
//___________________________________________________________________________________________________
function resetStats()
{
	global $CCCamWebInfo;

	foreach ($CCCamWebInfo as $server)
	{
		resetNodeStats($server[0]);
	}
        return true;
}
//___________________________________________________________________________________________________
function isRefreshActive()
{
	global $refresh_path;
	global $refresh_file;

	$refresh = false;

	$file = $refresh_path.$refresh_file;

	if (file_exists($file))
	{
		$array = file($file);
		if (strstr($array[0], "yes"))
			$refresh = true;
	}
	return $refresh;
}
//___________________________________________________________________________________________________
function getRefreshInterval()
{
	global $refresh_path;
	global $refresh_file;
	$refreshinterval = "";

	$file = $refresh_path.$refresh_file;

	if (file_exists($file))
	{
		$array = file($file);
		$refreshinterval = trim($array[1]);
	}
	return $refreshinterval;
}
//___________________________________________________________________________________________________
function isRefreshablePage()
{
	global $pagina;
	global $refresh_on_page;
	global $setProfil;
	global $forceupdate;
	global $cronupdate;
	global $cronportcheck;
	global $autorefresh;
	global $saveAutoRefreshInterval;
	global $refresh_on_subpages;

	$refreshable = false;

	foreach($refresh_on_page as $page)
	{
		if ($page == $pagina)
		{
			$this_page = basename($_SERVER['REQUEST_URI']);
        		if (strpos($this_page, "?") !== false)
			{
				// do not refresh for these parameters
				if ($setProfil != "" || $forceupdate != "" || $autorefresh != "" || $saveAutoRefreshInterval != "" || $refresh_on_subpages != "" || $cronupdate != "" || $cronportcheck != "")
                			$refreshable = true;
			}
        		else
                		$refreshable = true;
		}
	}
	if (isset($_POST['nodeDns']) || isset($_POST['username']) || isset($_POST['manualCheckPayserver']))
		$refreshable = false;
	return $refreshable;
}
//___________________________________________________________________________________________________
function isCronupdateActive()
{
        global $cronupdate_path;
        global $cronupdate_file;

        $cronupdateactive = false;

        $file = $cronupdate_path.$cronupdate_file;

        if (file_exists($file))
        {
                $array = file($file);
                if (strstr($array[0], "yes"))
                        $cronupdateactive = true;
        }
        return $cronupdateactive;
}
//___________________________________________________________________________________________________
function suspendCronUpdate()
{
	global $cronupdate_save_path;

	$fp = @fopen($cronupdate_save_path,"w");
	fwrite($fp, "no"."\n");
	fclose($fp);
}
//___________________________________________________________________________________________________
function resumeCronUpdate()
{
	global $cronupdate_save_path;

	$fp = @fopen($cronupdate_save_path,"w");
	fwrite($fp, "yes"."\n");
	fclose($fp);
}
//___________________________________________________________________________________________________
function isReloadActive()
{
        global $reload_path;
        global $reload_file;

        $reloadactive = false;

        $file = $reload_path.$reload_file;

        if (file_exists($file))
        {
                $array = file($file);
                if (strstr($array[0], "yes"))
                        $reloadactive = true;
        }
        return $reloadactive;
}
//___________________________________________________________________________________________________
function sterg0($text)
{
       $inceput = substr($text,0,1);
       while($inceput == "0" && strlen($text)>1)
       {
               $text = substr($text,1,strlen($text)-1);
               $inceput = substr($text,0,1);   
       }
       return $text;
}
//___________________________________________________________________________________________________
function adaug0($text,$count)
{
       if (strlen($text) == 0)
               return $text;
       /*
       $dif = $count - strlen($text);
       
       echo $dif." ";
 for ($k = 1; $k <= $dif; $k++) 
               $ret = "0".$ret;
       */
       
       while( strlen($text) < $count)
       {
               $text = "0".$text;
       }
       return $text;
}
//------------------------------------------------------------------------------
function interpretPortcheckResult($portcheckResult,$countrycode)
{
   $security = SECURITY_UNKNOWN;

   $secure = array("CCcam Port","NewCS/OSCam Newcamd");
   $moderate_secure = array("SSH","HTTPS");
   $unsecure = array("CCcam Web","CCcam Telnet","NewCS/OSCam Web","NewCS Telnet","FTP","Telnet","SMTP","HTTP");

   if ($countrycode == "<>")
      $security = SECURITY_SECURE;
   else
   {
      $security = SECURITY_UNKNOWN;

      foreach ($portcheckResult as $result)
      {
         $protocol = trim($result[0]);
         $port = trim($result[1]);
         $status = trim($result[2]);

         if($status == PORTSCAN_PORT_OPENED)
         {
            switch($security)
            {
               case SECURITY_UNKNOWN:
                  if(in_array(trim($protocol),$secure,true))          $security = SECURITY_SECURE;
               case SECURITY_SECURE:
                  if(in_array(trim($protocol),$moderate_secure,true)) $security = SECURITY_MODERATE_SECURE;
               case SECURITY_MODERATE_SECURE:
                  if(in_array(trim($protocol),$unsecure,true))        $security = SECURITY_UNSECURE;
                  break;
            }
         }
      }
   }

   return $security;
}
//------------------------------------------------------------------------------
function readPortcheckResult($node,$nodetype)
{
   global $portcheck_path;

   list($node_DNS, $node_PORT) = explode(":",$node);
   $portcheckResult_file = $portcheck_path.$node_DNS.".".$node_PORT.".".$nodetype.".data";

   if ($portcheckResultdata = file($portcheckResult_file))
   {
      foreach ($portcheckResultdata as $result)
      {
         list($protocol,$port,$status) = explode ("|", $result);
         // line: protocol name, port, status
         $portcheckResult[] = array(trim($protocol), trim($port), trim($status));
      }
   }
/*
   else
   {
      if($nodetype == "CCcam-s2s")
         $sc_port = array ( $node_PORT=>"CCcam Port", 16001=>"CCcam Web", 16000=>"CCcam Telnet", 10001=>"NewCS/OSCam Newcamd", 8080=>"NewCS/OSCam Web", 1001=>"NewCS Telnet", 21=>"FTP", 22=>"SSH", 23=>"Telnet", 25=>"SMTP", 80=>"HTTP", 443=>"HTTPS");
      else if($nodetype == "newcamd")
         $sc_port = array ( 12000=>"CCcam Port", 16001=>"CCcam Web", 16000=>"CCcam Telnet", $node_PORT=>"NewCS/OSCam Newcamd", 8080=>"NewCS/OSCam Web", 1001=>"NewCS Telnet", 21=>"FTP", 22=>"SSH", 23=>"Telnet", 25=>"SMTP", 80=>"HTTP", 443=>"HTTPS");
      else
         $sc_port = array ( 12000=>"CCcam Port", 16001=>"CCcam Web", 16000=>"CCcam Telnet", 10001=>"NewCS", 8080=>"NewCS/OSCam Web", 1001=>"NewCS Telnet", 21=>"FTP", 22=>"SSH", 23=>"Telnet", 25=>"SMTP", 80=>"HTTP", 443=>"HTTPS");

      // check each port
      foreach($sc_port as $node_PORT=>$value)
         $portcheckResult[] = array($value,$node_PORT,PORTSCAN_PORT_NO_RESULT);
   }
*/

   return $portcheckResult;
}
//------------------------------------------------------------------------------
function savePortCheckResult($node,$nodetype,$portcheckResult)
{
   global $portcheck_path;
   global $common_lv_fileopenwriteerror;

   // save portcheck result under portcheck/$nodename.$nodeport.$nodetype.data
   list($node_DNS, $node_PORT) = explode(":",$node);
   $portcheckResult_file = $portcheck_path.$node_DNS.".".$node_PORT.".".$nodetype.".data";

   if (is_array($portcheckResult) && count($portcheckResult) > 0)
   {
      if ($fp = fopen($portcheckResult_file,"w"))
      {
         foreach ($portcheckResult as $result)
         {
            // line: protocol name, port, status
            fputs($fp,$result[0]."|".$result[1]."|".$result[2]."\n");
         }

         fclose($fp);
      }
      else
         echo "<br><FONT COLOR=red>".$common_lv_fileopenwriteerror."</FONT><br>";
   }
}
//------------------------------------------------------------------------------
function checkPort($node_DNS,$node_PORT)
{
   $ret = PORTSCAN_PORT_CLOSED;

   $node_IP = trim(getHostIP($node_DNS));
   $fp = @fsockopen($node_IP,$node_PORT,$errno,$errstr,5);

   if($fp)
   {
      $ret = PORTSCAN_PORT_OPENED;
      @fclose($fp);
   }

   return $ret;
}
//------------------------------------------------------------------------------
function checkPorts($node,$nodetype,$countrycode="")
{
   $is_node_reachable = false;

   // check single server port according to node type to determine, if node is generally reachable
   list($node_DNS,$node_PORT) = explode(":",$node);

   if (checkPort($node_DNS,$node_PORT) == PORTSCAN_PORT_OPENED)
      $is_node_reachable = true;

   if ($is_node_reachable)
   {
      // setup port matrix according to node type
      if($nodetype == "CCcam-s2s")
         $sc_port = array ( $node_PORT=>"CCcam Port", 16001=>"CCcam Web", 16000=>"CCcam Telnet", 10001=>"NewCS/OSCam Newcamd", 8080=>"NewCS/OSCam Web", 1001=>"NewCS Telnet", 21=>"FTP", 22=>"SSH", 23=>"Telnet", 25=>"SMTP", 80=>"HTTP", 443=>"HTTPS");
      else if($nodetype == "newcamd")
         $sc_port = array ( 12000=>"CCcam Port", 16001=>"CCcam Web", 16000=>"CCcam Telnet", $node_PORT=>"NewCS/OSCam Newcamd", 8080=>"NewCS/OSCam Web", 1001=>"NewCS Telnet", 21=>"FTP", 22=>"SSH", 23=>"Telnet", 25=>"SMTP", 80=>"HTTP", 443=>"HTTPS");
      else
         $sc_port = array ( 12000=>"CCcam Port", 16001=>"CCcam Web", 16000=>"CCcam Telnet", 10001=>"NewCS", 8080=>"NewCS/OSCam Web", 1001=>"NewCS Telnet", 21=>"FTP", 22=>"SSH", 23=>"Telnet", 25=>"SMTP", 80=>"HTTP", 443=>"HTTPS");

      // check each port
      foreach($sc_port as $node_PORT=>$value)
         $portcheckResult[] = array($value,$node_PORT,checkPort($node_DNS,$node_PORT));

      savePortCheckResult($node,$nodetype,$portcheckResult);

      if($countrycode != "<>")
         setSecurityfromPortcheck($node,interpretPortcheckResult($portcheckResult,$countrycode),true);
   }

   return $portcheckResult;
}
//___________________________________________________________________________________________________
function showPortCheckResult($node,$nodetype)
{
   global $idtable;
   global $icon_width;
   global $icon_height;
   global $server_lv_legendscan;
   global $server_lv_legendscan_port;
   global $server_lv_legendscan_status;
   global $server_lv_legendscan_openport;
   global $server_lv_legendscan_closedport;
   global $server_lv_scan_service;
   global $server_lv_scan_port;
   global $server_lv_scan_status;
   global $server_lv_legendscan_unknownport;
   global $common_lv_recent_portcheck_unavailable;
   global $generic_lv_collexp;

   // read portcheckResult from portcheck/$nodename.$nodeport.$nodetype.data
   $portcheckResult = readPortCheckResult($node,$nodetype);

   // show portcheckResult only if is_array and count > 0
   if (is_array($portcheckResult) && count($portcheckResult) > 0)
   {
      echo "<br>";

      echo "<SPAN onclick='toggleDisplay(\"".$idtable['PORTSCAN']."\");' style='cursor:hand;'>Ports : <FONT COLOR=white><b>".count($portcheckResult)."</b></FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
      echo "<table id=\"".$idtable['PORTSCAN']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
      echo "<tr>";
      echo "<td>".$server_lv_legendscan."</td>";
      echo "</tr>";
      echo "<th class=\"tabel_header\">".$server_lv_legendscan_port."</th>";
      echo "<th class=\"tabel_header\">".$server_lv_legendscan_status."</th>";
      echo "</tr>";
      echo "<th class=\"tabel_normal\">".$server_lv_legendscan_openport."</th>";
      echo "<th class=\"tabel_normal\"><div align=\"center\"><img border=\"0\" src=\"images/port_open.gif\" width=\"12\" height=\"12\"></th><tr>";
      echo "<th class=\"tabel_normal\">".$server_lv_legendscan_closedport."</th>";
      echo "<th class=\"tabel_normal\"><div align=\"center\"><img border=\"0\" src=\"images/port_closed.gif\" width=\"12\" height=\"12\"></th><tr>";
//    echo "<th class=\"tabel_normal\">".$server_lv_legendscan_unknownport."</th>";
//    echo "<th class=\"tabel_normal\"><div align=\"center\"><img border=\"0\" src=\"images/unknown.png\" width=\"12\" height=\"12\"></th><tr>";
      echo "</table>";
      echo "<br>";

      echo "<table border=0 cellpadding=2 cellspacing=1>";
      echo "<th class=\"tabel_header\">".$server_lv_scan_service."</th>";
      echo "<th class=\"tabel_header\">".$server_lv_scan_port."</th>";
      echo "<th class=\"tabel_header\">".$server_lv_scan_status."</th></tr>";

      list($host_DNS,$host_Port) = explode(":", $node);
      $webifs = array("CCcam Web","NewCS/OSCam Web","HTTP","HTTPS");

      foreach($portcheckResult as $result)
      {
         echo "<th class=\"tabel_normal\">".$result[0]."</th>"; // protocol
         echo "<th class=\"tabel_normal\">".$result[1]."</th>"; // port

         switch($result[2])
         {
            case PORTSCAN_PORT_OPENED :
               if (in_array($result[0],$webifs,true))
               {
                  if ($result[0] == "HTTPS")
                     $href_head = "<A HREF='https://".$host_DNS."'>";
                  else
                     $href_head = "<A HREF='http://".$host_DNS.":".$result[1]."'>";
                  $href_tail = "</A>";
               }
               else
               {
                  $href_head = "";
                  $href_tail = "";
               }

               echo "<th class=\"tabel_normal\"><div align=\"center\">".$href_head."<img border=\"0\" src=\"images/port_open.gif\" title='".$server_lv_legendscan_openport."' width=\"12\" height=\"12\"></th>".$href_tail."</tr>";
               break;
//          case PORTSCAN_PORT_CLOSED :
            default :
               echo "<th class=\"tabel_normal\"><div align=\"center\"><img border=\"0\" src=\"images/port_closed.gif\" title='".$server_lv_legendscan_closedport."' width=\"12\" height=\"12\"></th></tr>";
               break;
//          default :
//             echo "<th class=\"tabel_normal\"><div align=\"center\"><img border=\"0\" src=\"images/unknown.png\" title='".$server_lv_legendscan_unknownport."' width=\"12\" height=\"12\"></th></tr>";
         }
      }
      echo "</table>";
   }
   else
      // show error message
      echo "<br><FONT COLOR=red>".$common_lv_recent_portcheck_unavailable."</FONT><br>";
}
//___________________________________________________________________________________________________
function loadSecuritycheckData()
{
   global $portcheck_file;
   global $PortCheckResults;
   global $servers_file;

//   unset $PortCheckResults;

   if (file_exists($portcheck_file))
   {
      $portcheck_data = file ($portcheck_file);
      foreach ($portcheck_data as $currentline)
      {
         $portcheck_result = explode("|", $currentline);
         $host_DNS = trim($portcheck_result[0]); // host DNS
         $host_PORTCHECK = array(trim($portcheck_result[1]), trim($portcheck_result[2]), trim($portcheck_result[3]), trim($portcheck_result[4]), trim($portcheck_result[5]), trim($portcheck_result[6])); // array(portcheck exclude, recent portcheck result, previous result, dyndns check on Google, node type, port)

         // add detailed port check results

         $PortCheckResults[$host_DNS] = $host_PORTCHECK;
      }
   }

   // add all new server nodes with exclude status PORTCHECK_CROND_NOT_EXCLUDED, portcheck status SECURITY_UNKNOWN
   checkFile($servers_file);
   $servers_data = file ($servers_file);

   $new_node_added = false;

   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host   = trim($server[1]);
//       $server_Time   = trim($server[2]); // currently not neccessary
         $server_Type   = trim($server[3]);
//       $server_Ver    = trim($server[4]); // currently not neccessary
//       $server_Nodeid = trim($server[5]); // currently not neccessary
//       $server_Cards  = trim($server[6]); // currently not neccessary
//       $server_Idents = trim($server[7]); // currently not neccessary

         $tara_DNS = taraNameSaved($server_Host);
         $country = $tara_DNS[0]["tara"];

         if ($server_Host != "" && $country != "<>" && !isset($PortCheckResults[$server_Host]))
         {
            list($host_DNS,$host_Port) = explode (":",$server_Host);
            $host_Port = trim($host_Port);
            $PortCheckResults[$server_Host] = array(PORTCHECK_CROND_NOT_EXCLUDED,SECURITY_UNKNOWN,SECURITY_UNKNOWN,NOT_KNOWN_BY_GOOGLE,$server_Type,$host_Port);
            $new_node_added = true;
         }
      }
   }

   if ($new_node_added)
      saveSecuritycheckData();
}
//___________________________________________________________________________________________________
function saveSecuritycheckData()
{
   global $portcheck_file;
   global $PortCheckResults;
   global $common_lv_fileopenwriteerror;

   $count = count($PortCheckResults);
   if ($count > 0)
   {
      if ((file_exists($portcheck_file) && is_writable($portcheck_file)) || !file_exists($portcheck_file))
      {
         if ($fp = @fopen($portcheck_file,"w"))
         {
            foreach ($PortCheckResults as $node => $PortCheckResult)
            {
               $line = $node;			// node name
               $line .= "|";
               $line .= $PortCheckResult[0];	// portcheck exclude from cronjob
               $line .= "|";
               $line .= $PortCheckResult[1];	// recent security check result
               $line .= "|";
               $line .= $PortCheckResult[2];    // previous security check result
               $line .= "|";
               $line .= $PortCheckResult[3];    // dyndns address known by Google
               $line .= "|";
               $line .= $PortCheckResult[4];    // node type
               $line .= "|";
               $line .= $PortCheckResult[5];    // port

               fputs($fp, $line."\n");
            }
            fclose($fp);
         }
      }
      else
         echo "<br><FONT COLOR=red>".$common_lv_fileopenwriteerror."</FONT><br>";
   }
}
//___________________________________________________________________________________________________
function isExludedfromPortcheck($node, $country="")
{
   global $PortCheckResults;

   $excluded = false;

   if ($PortCheckResults[$node][0] == PORTCHECK_CROND_EXCLUDED || $country == "<>")
   // local ip addresses are excluded from crond portcheck by definition
      $excluded = true;

   return $excluded; 
}
//___________________________________________________________________________________________________
function excludefromPortcheck($node,$exclude=false,$save=false)
{
   global $PortCheckResults;

   $PortCheckResults[$node][0] = ($exclude) ? PORTCHECK_CROND_EXCLUDED : PORTCHECK_CROND_NOT_EXCLUDED;

   if ($save)
      saveSecuritycheckData(); 
}
//___________________________________________________________________________________________________
function excludefromPortcheckAll($exclude=false)
{
   global $portcheck_file;
   global $PortCheckResults;
   global $common_lv_fileopenwriteerror;

   // loadSecuritycheckData if $PortCheckResults is not array and thus not defined
   if(!is_array($PortCheckResults)) loadSecuritycheckData();

   // do only if $PortCheckResults is_array and count > 0
   if (is_array($PortCheckResults) && count($PortCheckResults) > 0)
   {
      if ((file_exists($portcheck_file) && is_writable($portcheck_file)) || !file_exists($portcheck_file))
      {
         if ($fp = @fopen($portcheck_file,"w"))
         {
            foreach ($PortCheckResults as $node => $PortCheckResult)
            {
               $line = $node;                   // node name
               $line .= "|";
               $line .= ($exclude) ? PORTCHECK_CROND_EXCLUDED : PORTCHECK_CROND_NOT_EXCLUDED;// portcheck exclude from cronjob
               $line .= "|";
               $line .= $PortCheckResult[1];    // recent security check result
               $line .= "|";
               $line .= $PortCheckResult[2];    // previous security check result
               $line .= "|";
               $line .= $PortCheckResult[3];    // dyndns address known by Google
               $line .= "|";
               $line .= $PortCheckResult[4];    // node type
               $line .= "|";
               $line .= $PortCheckResult[5];    // port

               fputs($fp, $line."\n");
            }
            fclose($fp);
         }
      }
      else
         echo "<br><FONT COLOR=red>".$common_lv_fileopenwriteerror."</FONT><br>";
   }

   loadSecuritycheckData();
}
//___________________________________________________________________________________________________
function isKnownByGoogle($node)
{
   global $PortCheckResults;

   $knownbygoogle = false;

   if ($PortCheckResults[$node][3] == KNOWN_BY_GOOGLE)
   // DynDns address is known by Google
      $knownbygoogle = true;

   return $knownbygoogle;
}
//___________________________________________________________________________________________________
function setSecurityfromPortcheck($node,$security=SECURITY_UNKNOWN,$save=false)
{
   global $PortCheckResults;

   $ret = false;

   if ($node != "")
   {
      $PortCheckResults[$node][2] = $PortCheckResults[$node][1]; // set previous result
      $PortCheckResults[$node][1] = $security;                   // set actual result
      $ret = true;
   }

   if ($save)
      saveSecuritycheckData();

   return $ret;
}
//___________________________________________________________________________________________________
function setKnownByGoogle($node,$knownbygoogle=NOT_KNOWN_BY_GOOGLE,$save=false)
{
   global $PortCheckResults;

   $ret = false;

   if ($node != "")
   {
      $PortCheckResults[$node][3] = $knownbygoogle;              // set known by Google result
      $ret = true;
   }

   if ($save)
      saveSecuritycheckData();

   return $ret;
}
//___________________________________________________________________________________________________
function linkNod($node,$text,$clasa="",$cuQuerry = true)
{
       global $pagina;
       
       if ($clasa!="")
               $ret = "<A CLASS=\"".$clasa."\" HREF=".$pagina."?";
       else
               $ret = "<A HREF=".$pagina."?";
               
       $node = sterg0($node);
       if ($cuQuerry)
               $ret = $ret.$_SERVER['QUERY_STRING'];
       
       $ret = $ret."&node=".$node.">".$text."</A>";
       return $ret;
}
//___________________________________________________________________________________________________
function linkSid($action,$sid,$text="",$clasa="",$cuQuerry = false)
{
       global $pagina;

       if ($clasa!="")
               $ret = "<A CLASS=\"".$clasa."\" HREF=".$pagina."?";
       else
               $ret = "<A HREF=".$pagina."?";

       if ($_SERVER['QUERY_STRING'] == "" || !$cuQuerry)
       {
               $ret = $ret.$action."=".$sid.">".$text."</A>";
       }
       else
               $ret = $ret.$_SERVER['QUERY_STRING']."&".$action."=".$sid.">".$text."</A>";

       return $ret;
}
//___________________________________________________________________________________________________
function linkTag($server="",$node="",$nodetype="",$server=true,$country="",$tags=0)
{
	global $use_security_tag;
	global $use_localip_tag;
	global $use_webif_tag;
	global $use_payserver_tag;
	global $use_excluded_tag;
	global $generic_lv_portsecurity_unknown;
	global $generic_lv_portsecurity_secure;
	global $generic_lv_portsecurity_moderate_secure;
	global $generic_lv_portsecurity_unsecure;
	global $generic_lv_portsecurity_localip;
	global $generic_lv_portsecurity_excluded;
	global $generic_lv_portscan_excluded;
	global $generic_lv_cccam_webif_available;
	global $generic_lv_cccam_webif_not_available;
	global $generic_lv_warning_payserver;
	global $generic_lv_localip_secure;
	global $generic_lv_known_by_google;
	global $webiflink_path;
	global $yaps;
	global $lops;
	global $PortCheckResults;
	global $serverstats_lv_payserveryaps;
	global $serverstats_lv_payserverprivate;

	$href_recent_portcheck_head = "";
	$href_recent_portcheck_tail = "";

	if($node != "")
	{
		$href_recent_portcheck_head = "<A HREF='serverstats.php?nodeDns=".$node."&checkPortrecent=1'>";
		$href_recent_portcheck_tail = "</A>";
		list($node_DNS,$node_Port) = explode(":", $node);
		$href_knownbygoogle_head = "<A HREF='http://www.google.de/search?hl=en&q=".$node_DNS."'>";
		$href_knownbygoogle_tail = "</A>";
	}

	$ps_yaps_exists = file_exists($yaps["humanreadabledb"]);
	$ps_lops_exists = file_exists($lops["db"]);

	$tag = "";
	$tag .= "&nbsp;";

	list($host_DNS,$host_PORT) = explode(":", $node);

	if ($tags & TAG_SECURITY_PORTSCAN)
	{
		if ($country == "<>")
		{
			if ($use_security_tag)
				$tag .= $href_recent_portcheck_head."<img border=\"0\" src=\"images/secure.png\" title='".$generic_lv_portsecurity_secure."' align='top' width='12' height='12'>".$href_recent_portcheck_tail;
			if ($tags & TAG_SECURITY_PORTSCAN_EXTENDED)
				$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portsecurity_secure." </B></FONT>&nbsp;";
			if ($use_excluded_tag && $tags & TAG_PORTSCAN_EXCLUDED)
			{
				$tag .= "<img border=\"0\" src=\"images/excluded.png\" title='".$generic_lv_portsecurity_excluded."' align='top'>";
				if ($tags & TAG_PORTSCAN_EXCLUDED_EXTENDED)
					$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portscan_excluded."</B></FONT>&nbsp;";
			}
		}
		else
		{
			if (!isset($PortCheckResults[trim($node)]))
			{
				if ($use_security_tag)
					$tag .= $href_recent_portcheck_head."<img border=\"0\" src=\"images/unknown.png\" title='".$generic_lv_portsecurity_unknown."' align='top' width='12' height='12'>".$href_recent_portcheck_tail;
				if ($tags & TAG_SECURITY_PORTSCAN_EXTENDED)
					$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portsecurity_unknown."</B></FONT>&nbsp;";
				if ($use_excluded_tag && $PortCheckResults[trim($node)][0] == PORTCHECK_CROND_EXCLUDED && $tags & TAG_PORTSCAN_EXCLUDED)
				{
					$tag .= "<img border=\"0\" src=\"images/excluded.png\" title='".$generic_lv_portsecurity_excluded."' align='top'>";
					if ($tags & TAG_PORTSCAN_EXCLUDED_EXTENDED)
						$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portscan_excluded."</B></FONT>&nbsp;";
				}
			}
			else if ($PortCheckResults[trim($node)][1] == SECURITY_UNKNOWN)
			{
				if ($use_security_tag)
					$tag .= $href_recent_portcheck_head."<img border=\"0\" src=\"images/unknown.png\" title='".$generic_lv_portsecurity_unknown."' align='top' width='12' height='12'>".$href_recent_portcheck_tail;
				if ($tags & TAG_SECURITY_PORTSCAN_EXTENDED)
					$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portsecurity_unknown."</B></FONT>&nbsp;";
				if ($use_excluded_tag && $PortCheckResults[trim($node)][0] == PORTCHECK_CROND_EXCLUDED && $tags & TAG_PORTSCAN_EXCLUDED)
				{
					$tag .= "<img border=\"0\" src=\"images/excluded.png\" title='".$generic_lv_portsecurity_excluded."' align='top'>";
					if ($tags & TAG_PORTSCAN_EXCLUDED_EXTENDED)
						$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portscan_excluded."</B></FONT>&nbsp;";
				}
			}
			else if ($PortCheckResults[trim($node)][1] == SECURITY_SECURE)
			{
				if ($use_security_tag)
					$tag .= $href_recent_portcheck_head."<img border=\"0\" src=\"images/secure.png\" title='".$generic_lv_portsecurity_secure."' align='top' width='12' height='12'>".$href_recent_portcheck_tail;
				if ($tags & TAG_SECURITY_PORTSCAN_EXTENDED)
					$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portsecurity_secure."</B></FONT>&nbsp;";
				if ($use_excluded_tag && $PortCheckResults[trim($node)][0] == PORTCHECK_CROND_EXCLUDED && $tags & TAG_PORTSCAN_EXCLUDED)
				{
					$tag .= "<img border=\"0\" src=\"images/excluded.png\" title='".$generic_lv_portsecurity_excluded."' align='top'>";
					if ($tags & TAG_PORTSCAN_EXCLUDED_EXTENDED)
						$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portscan_excluded."</B></FONT>&nbsp;";
				}

			}
			else if ($PortCheckResults[trim($node)][1] == SECURITY_MODERATE_SECURE)
			{
				if ($use_security_tag)
					$tag .= $href_recent_portcheck_head."<img border=\"0\" src=\"images/moderate_secure.png\" title='".$generic_lv_portsecurity_moderate_secure."' align='top' width='12' height='12'>".$href_recent_portcheck_tail;
				if ($tags & TAG_SECURITY_PORTSCAN_EXTENDED)
					$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portsecurity_moderate_secure."</B></FONT>&nbsp;";
				if ($use_excluded_tag && $PortCheckResults[trim($node)][0] == PORTCHECK_CROND_EXCLUDED && $tags & TAG_PORTSCAN_EXCLUDED)
				{
					$tag .= "<img border=\"0\" src=\"images/excluded.png\" title='".$generic_lv_portsecurity_excluded."' align='top'>";
					if ($tags & TAG_PORTSCAN_EXCLUDED_EXTENDED)
						$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portscan_excluded."</B></FONT>&nbsp;";
				}
			}
			else if ($PortCheckResults[trim($node)][1] == SECURITY_UNSECURE)
			{
				if ($use_security_tag)
					$tag .= $href_recent_portcheck_head."<img border=\"0\" src=\"images/unsecure.png\" title='".$generic_lv_portsecurity_unsecure."' align='top' width='12' height='12'>".$href_recent_portcheck_tail;
				if ($tags & TAG_SECURITY_PORTSCAN_EXTENDED)
					$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portsecurity_unsecure."</B></FONT>&nbsp;";
				if ($use_excluded_tag && $PortCheckResults[trim($node)][0] == PORTCHECK_CROND_EXCLUDED && $tags & TAG_PORTSCAN_EXCLUDED)
				{
					$tag .= "<img border=\"0\" src=\"images/excluded.png\" title='".$generic_lv_portsecurity_excluded."' align='top'>";
					if ($tags & TAG_PORTSCAN_EXCLUDED_EXTENDED)
						$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_portscan_excluded."</B></FONT>&nbsp;";
				}
			}
		}
	}

	if ($country != "<>" && ($tags & TAG_KNOWN_BY_GOOGLE))
	{
		if ($PortCheckResults[trim($node)][3] == KNOWN_BY_GOOGLE)
		{
			$tag .= "&nbsp;".$href_knownbygoogle_head."<img border=\"0\" src=\"images/google.png\" title='".$generic_lv_known_by_google."' align='top' width='12' height='12'>".$href_knownbygoogle_tail;
			if ($tags & TAG_KNOWN_BY_GOOGLE_EXTENDED)
				$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_known_by_google."</B></FONT>&nbsp;";
		}
	}

	if ($country == "<>" && ($tags & TAG_LOCAL_IP))
	{
		list($host_DNS,$host_PORT) = explode(":", $node);
		$localip = trim(getHostIP($host_DNS));
		if ($use_localip_tag)
			$tag .= "<img border=\"0\" src=\"images/localip.png\" title='".$generic_lv_portsecurity_localip." ".$localip."' align='top'>";
		if ($tags & TAG_LOCAL_IP_EXTENDED)
			$tag .= "&nbsp;<FONT COLOR=white><B>".$generic_lv_localip_secure."</B></FONT>&nbsp;";
	}

	if ($use_webif_tag && ($tags & TAG_WEBINTERFACE_LINK))
	{
		list($host_DNS,$host_PORT) = explode(":", $node);
		$path = $webiflink_path.$host_DNS.".".$host_PORT.".";
		$path .= ($nodetype == "camd3") ? $host_TYPE = "newcamd" : $host_TYPE = $nodetype;
		if ($nodetype == "CCcam-s2s" && $server == true)
			$path .= ".server";
		else if ($nodetype == "CCcam-s2s" && $server == false)
			$path .= ".client";
		$path .= ".link";
	
		if (file_exists($path))
		{
			$webif_link_saved = file_get_contents($path);
			$weblink = explode(":",$webif_link_saved);
			$host_IP = ltrim($weblink[1], "/");
			$host_PORT = $weblink[2];
			$webinterface = pingDomain($host_IP,$host_PORT,1);
			if ($webinterface!=-1)
				$tag .= "<A HREF='".$webif_link_saved."'><img border=\"0\" src=\"images/webif_available.png\" title='".$generic_lv_cccam_webif_available."' align='top'></A>";
			else
				$tag .= "<img border=\"0\" src=\"images/webif_unavailable.png\" title='".$generic_lv_cccam_webif_not_available."' align='top'>";
		}
	}

        if ($use_payserver_tag && ($tags & TAG_PAYSERVER))
	{
		$foundDatabase = "";
                if ($ps_yaps_exists && yapsCheck($yaps["humanreadabledb"], $host_DNS))
                       $foundDatabase = "(".$serverstats_lv_payserveryaps;
		if ($ps_lops_exists && yapsCheck($lops["db"], $host_DNS))
		{
			if ($foundDatabase != "")
				$foundDatabase .= ", ".$serverstats_lv_payserverprivate;
			else
				$foundDatabase .= "(".$serverstats_lv_payserverprivate;
		}
		if ($foundDatabase != "")
		{
			$foundDatabase .= ")";
			$tag .= "&nbsp;<img border=\"0\" src=\"images/warning.png\" title='".$generic_lv_warning_payserver." ".$foundDatabase."' align='top' width='12' height='12'>";
			if ($tags & TAG_PAYSERVER_EXTENDED)
				$tag .= "&nbsp;<FONT COLOR=red><b>".$generic_lv_warning_payserver."</b></FONT>";
		}
	}

	return $tag;
}
//___________________________________________________________________________________________________
function sid_delete($sid)
{
	global $unknownsids_file;

	$ret = true;

	if(file_exists($unknownsids_file))
	{
		if ($sid == "all")
			file_delete($unknownsids_file);
		else
		{
			$unknownsids = file($unknownsids_file);

			if (is_writable($unknownsids_file))
			{
				$fp = fopen($unknownsids_file,"w");
				if ($fp)
				{
					foreach($unknownsids as $unknownsid)
						if (strpos($unknownsid, $sid) === false)
							fwrite($fp,$unknownsid);
					fclose($fp);
				}
			}
			else
				$ret = false;
		}
	}
	else
		$ret = false;

	return $ret;
}
//___________________________________________________________________________________________________
function linkProvider($provider,$text,$clasa="",$cuQuerry = false)
{
       global $pagina;

       if ($clasa!="")
               $ret = "<A CLASS=\"".$clasa."\" HREF=".$pagina."?";
       else
               $ret = "<A HREF=".$pagina."?";
                               
       if ($_SERVER['QUERY_STRING'] == "" || !$cuQuerry)
       {
               $ret = $ret."provider=".$provider.">".$text."</A>";
       }
       else
               $ret = $ret.$_SERVER['QUERY_STRING']."&provider=".$provider.">".$text."</A>";
       
       return $ret;
}
//___________________________________________________________________________________________________
function providerID($caid,$prov,$link=true,$clasa="Node_Provider",$cuQuerry = false)
{
       global $use_unknown_providers;
       global $common_lv_unknown_providerid;

       $caid = sterg0($caid);
       $prov_seek = $caid.":".$prov;   
       $provUsed_seek = strtolower(adaug0($caid,4).":".adaug0($prov,6));
       
       global $usedProviders;
       if (!isset($usedProviders)) LoadUsedProviders();
       global $fakeProviders;
       if (!isset($fakeProviders)) LoadFakeProviders();
       global $unknownProviders;
       if (!isset($unknownProviders)) LoadUnknownProviders();

       $text_provider = "";
       if (IsUsedProvider($provUsed_seek)) 
               $text_provider = "<font color=#1F0FA00>".$prov." </font>";
       else
       if (IsFakeProvider($provUsed_seek))
               $text_provider = "<font color=red>".$prov." </font>";
       else
       if ($use_unknown_providers && IsUnknownProvider($provUsed_seek))
               $text_provider = "<font color=fuchsia>".$prov." </font>";
       else
               $text_provider = "<font color=#F0FA00>".$prov." </font>";

       global $CCcam_providersShort;
       
       $caidcolor = "white";
       
       if (strstr($provUsed_seek,"0501:")) $caidcolor = "red";
       if (strstr($provUsed_seek,"0502:")) $caidcolor = "red";
       
       if ($link == true)
               $caidLink = linkProvider($caid,"<font color=$caidcolor>".$caid." : </font>",$clasa,$cuQuerry);
       else
               $caidLink = "<font color=$caidcolor>".$caid." : </font>";
       
       $idRecunoscut = "";
       if (isset($CCcam_providersShort[$prov_seek]))
       {
               if ($link == true)
                       $idRecunoscut = linkProvider($caid.":".$prov, $text_provider.$CCcam_providersShort[$prov_seek] , $clasa, $cuQuerry);
               else
                       $idRecunoscut = $text_provider.$CCcam_providersShort[$prov_seek];
       }
               
       $id = "<font color=orange>".$idRecunoscut."</font>";
       
       if ($idRecunoscut == "")
       {
               $providers = explode(",", $prov);
               
               foreach ($providers as $provider)
               {
                       $provider = sterg0($provider);
                       
                       $text_provider = "";
                       $provUsed_seek = strtolower(adaug0($caid,4).":".adaug0($provider,6));
                       
                       if (IsUsedProvider($provUsed_seek)) 
                               $text_provider = linkProvider($caid.":".$provider, "<font color=#1F0FA00>".$provider." </font>", $clasa, $cuQuerry);
                       else
                       if (IsFakeProvider($provUsed_seek)) 
                               $text_provider = linkProvider($caid.":".$provider, "<font color=red>".$provider." </font>", $clasa, $cuQuerry);
                       else
                       if ($use_unknown_providers && IsUnknownProvider($provUsed_seek))
                               $text_provider = linkProvider($caid.":".$provider, "<font color=fuchsia>".$provider." </font>", $clasa, $cuQuerry);
                       else
                       if ($use_unknown_providers && !isset($CCcam_providersShort[$caid.":".$provider]))
                               $text_provider = linkProvider($caid.":".$provider, "<font color=fuchsia>".$provider." </font>".$common_lv_unknown_providerid, $clasa, $cuQuerry);
                       else
                               $text_provider = linkProvider($caid.":".$provider, "<font color=#F0FA00>".$provider." </font>", $clasa, $cuQuerry);

                       $idTemp = "";
                       if (isset($CCcam_providersShort[$caid.":".$provider]))
                       {
                               if ($link == true)
                                       $idTemp = $text_provider.linkProvider($caid.":".$provider, $CCcam_providersShort[$caid.":".$provider], $clasa, $cuQuerry);
                               else
                                       $idTemp = $text_provider.$CCcam_providersShort[$caid.":".$provider];
                       }
                               
                       if ($idTemp == "")  
                       {
                               if ($link == true)
                                       $idTemp = linkProvider($caid.":".$provider, $text_provider, $clasa, $cuQuerry);
                               else
                                       $idTemp = $text_provider;
                       }

                       $idents[$idTemp] = $provider ;
               }

               $k=0;
               foreach ($idents as $pName => $pID)
               {
                       if ($k!=0) $id = $id."<font color=white><B> | </B></font>";
                       $id = $id."<font color=orange>".$pName."</font>";
                       $k++;
                       
                       
               }
       }
       
       $id = $caidLink.$id;

       return $id;
}
//___________________________________________________________________________________________________
function IsUsedProvider($provider)
{
	global $usedProviders;
	if (!isset($usedProviders)) LoadUsedProviders();

	if (isset($usedProviders[$provider])) 
  		return true;

	return false;
}
//___________________________________________________________________________________________________
function IsFakeProvider($provider)
{
	global $fakeProviders;
	if (!isset($fakeProviders)) LoadFakeProviders();
  
	if (isset($fakeProviders[$provider]))
		return true;

	if (strstr($provider,"0501:")) return true;
	if (strstr($provider,"0502:")) return true;
       
	return false;
}
//___________________________________________________________________________________________________
function IsUnknownProvider($provider)
{
	global $unknownProviders;
	if (!isset($unknownProviders)) LoadUnknownProviders();

	if (isset($unknownProviders[$provider]))
		return true;

	return false;
}
//___________________________________________________________________________________________________
function IsUnknownSid($sid)
{
	$ret = false;

	$pos =  strpos($sid, ":");
	if ($pos !== false && $pos == 4)
	{
		$pos = strpos($sid, ":", $pos + 1);
		if ($pos !== false && $pos == 11)
			$ret = true;
	}
	return $ret;
}
//___________________________________________________________________________________________________
function LoadFakeProviders()
{
	global $fakeProviders;
	global $fakeProvidersFile;
	global $use_fake_providers;
	global $fake_providers_needle;

	if ($use_fake_providers)
	{
		$globalProviders_data = file ($fakeProvidersFile);
		foreach ($globalProviders_data as $uProvider) 
		{
			if (substr($uProvider, 0, 1) != "#")
			{
				$uProvider = strtolower(trim(substr($uProvider, 0, 11)));
				$fakeProviders[$uProvider] = 1;
			}
		}
	}
	else
	{
		$globalProviders_data = file ("CCcam.providers");
                foreach ($globalProviders_data as $uProvider) 
                {
                        if (substr($uProvider, 0, 1) != "#" && strpos($uProvider, $fake_providers_needle)) 
                        {
                                $uProvider = strtolower(trim(substr($uProvider, 0, 8)));
				$caid_short = substr($uProvider, 0, 2);
				if ($caid_short == "01" || $caid_short == "05")
				{
					$caid = $caid_short."00";
					$providerid = substr($uProvider, 2, 6);
				}
				else
				{
					$caid = substr($uProvider, 0, 4);
					$providerid_short = substr($uProvider, 4, 4);
					$providerid = "00".$providerid_short;
				}
				$uProvider = $caid.":".$providerid;
                                $fakeProviders[$uProvider] = 1;
                        }
                }

	}
}
//___________________________________________________________________________________________________
function LoadUnknownProviders()
{
        global $unknownProviders;
	global $unknownProvidersFile;
        global $use_unknown_providers;
	global $unknown_providers_needle;

        if (!$use_unknown_providers)
	{
                $globalProviders_data = file ($unknownProvidersFile);
                foreach ($globalProviders_data as $uProvider)
                {
                        if (substr($uProvider, 0, 1) != "#")
                        {
                                $uProvider = strtolower(trim(substr($uProvider, 0, 11)));
                                $unknownProviders[$uProvider] = 1;
                        }
                }
	}
	else
        {
                $globalProviders_data = file ("CCcam.providers");
                foreach ($globalProviders_data as $uProvider)
                {
                        if (substr($uProvider, 0, 1) != "#" && strpos($uProvider, $unknown_providers_needle))
                        {
                                $uProvider = strtolower(trim(substr($uProvider, 0, 8)));
                                $caid = substr($uProvider, 0, 2);
                                if ($caid == "01" || $caid == "05") // for seca and viaccess providers
                                {
                                        $caid = substr($uProvider, 0, 2);
                                        $caid = $caid."00";
                                        $providerid = substr($uProvider, 2, 6);
                                }
                                else
                                {
                                        $caid = substr($uProvider, 0, 4);
                                        $providerid = substr($uProvider, 4, 4);
                                        $providerid = "00".$providerid;
                                }
                                $uProvider = $caid.":".$providerid;
                                $unknownProviders[$uProvider] = 1;
                        }
                }
        }
}
//___________________________________________________________________________________________________
function LoadUsedProviders()
{
	global $usedProviders;
	global $usedProvidersFile;
	$globalProviders_data = file ($usedProvidersFile);
	foreach ($globalProviders_data as $uProvider) 
	{
		$uProvider = explode(" ", strtolower(trim($uProvider)));
		$usedProviders[$uProvider[0]] = 1;
	}
}
//___________________________________________________________________________________________________
function UpdateHitProviders()
{
       
	global $usedProviders;
	global $usedProvidersFile;
	LoadUsedProviders();
	
	global $servers_file;
	$servers_data = file ($servers_file);
	foreach ($servers_data as $currentline)
	{
		$inceput1 = substr($currentline,0,1);
		$inceput2 = substr($currentline,1,2);
		
		if ($inceput1 == "|" && $inceput2 != " H")
		{
			$server = explode("|", $currentline);
			$server_Idents = trim($server[7]);
			
			$hit_array = explode(" ",$server_Idents);
			if ($hit_array[0] != "")
			{
				$hit_caid = $hit_array[1];
				$hit_provider = explode(":",$hit_caid);
				$hit_exact = explode("(",$hit_array[2]);
				$hit_exact2 = explode(")",$hit_exact[1]);
				
				$hit_ecm = $hit_exact[0];
				$hit_ecmOK = $hit_exact2[0];
				
				if (!isset($ecm_hit[$hit_caid]))        
				$ecm_hit[$hit_caid] = 0;
				
				$ecm_hit[$hit_caid] += $hit_ecmOK;
			
			}
		}
	}
	
	foreach ($ecm_hit as $hit_caid => $hit_info)
	{
		if ($hit_info > 0 )
		{
			$hit_provider = explode(":",$hit_caid);
			$hit_caid = adaug0($hit_provider[0],4).":".adaug0($hit_provider[1],6);
			$usedProviders[$hit_caid] = $hit_info;
		}
	}
	
	
	
	ksort($usedProviders);
	$fp = @fopen($usedProvidersFile,"w");
	global $CCcam_providers;
	foreach ($usedProviders as $S_CAID => $data) 
	{
		if (!IsFakeProvider($S_CAID))
		{
			fwrite($fp, $S_CAID." ".$CCcam_providers[$S_CAID]."\n");
		}
	}
	fclose($fp);
       
}
//___________________________________________________________________________________________________
function UpdateClientsCountryIP()
{
       global $clients_file;
       $clients_data = file ($clients_file);
       foreach ($clients_data as $currentline) 
       {
               $inceput1 = substr($currentline,0,1);
               $inceput2 = substr($currentline,1,2);
               if (strstr($currentline,"| Shareinfo")) break;  

               if ($inceput1 == "|" && $inceput2 != " U")
               {
                       $active_client          = explode("|", $currentline);
                       $ac_Username                    = trim($active_client[1]);
                       $ac_IP                                          = trim($active_client[2]);
                       tara($ac_IP,$ac_Username);

               }
       }
}
//___________________________________________________________________________________________________
function UpdateMostActiveClients()
{
	global $activeclients_file;
	global $most_activeclients_file;

	$activeclients_data = file ($activeclients_file);
	foreach ($activeclients_data as $currentline)
	{
		if (strstr($currentline,"ACTIVE CLIENTS"))
		{
			$updateline = $currentline;
			break;
		}
	}
	sscanf ($updateline,"%d", $activeclients); // sscanf ($updateline,"%d", &$activeclients);

	if (file_exists($most_activeclients_file))
	{
		$most_activeclients_data = file ($most_activeclients_file);
		$savedline = $most_activeclients_data[0];
		sscanf ($savedline,"%d",$mostactiveclients); // sscanf ($savedline,"%d",&$mostactiveclients);
		if ($activeclients > $mostactiveclients)
			$savedline = $updateline;
	}
	else
		$savedline = $updateline;

	$fp = @fopen($most_activeclients_file,"w");
	fwrite($fp, $savedline);
	fclose($fp);
}
//___________________________________________________________________________________________________
function LoadUnknownSids()
{
	global $debug;
	global $unknownsids_file;
	global $unknownSids;

	if(file_exists($unknownsids_file))
	{
		$unknownsids_data = file($unknownsids_file);
		foreach ($unknownsids_data as $unknownsid)
		{
			$uUnknownSid = explode("|", trim($unknownsid));
			$uclients = explode(",", $uUnknownSid[2]);
			unset ($clientusage);
			foreach ($uclients as $uclientusage)
			{
				list($client,$usage) = explode("(", $uclientusage);
				$usage = trim($usage, ")");
				$clientusage[] = array($client,$usage);
			}
			sort($uclients);
			$unknownSids[trim($uUnknownSid[0])] = array($uUnknownSid[1], $clientusage);
		}

		ksort($unknownSids);
	}

/*
	if( reset($unknownSids) !== false && $debug)
	{
		foreach ($unknownSids as $unknownSid => $used)
		{
			echo $unknownSid.", ".$used[0].", ";
			$i = count($used[1]);
			foreach ($used[1] as $client)
			{
				echo $client[0]."(".$client[1].")";
				if ($i > 1)
					echo ", ";
				$i--;
			}
			echo "<br>";
		}
		echo "<br>";
	}
*/
}
//___________________________________________________________________________________________________
function saveUnknownSids()
{
	global $unknownsids_file;
	global $unknownSids;

	if (isset($unknownSids) && (is_writable($unknownsids_file) || ! file_exists($unknownsids_file)))
	{
		$fp = fopen($unknownsids_file,"w");
                if ($fp)
                {
			foreach ($unknownSids as $unknownSid => $used)
			{
				$line = "";
				$line = trim($unknownSid)."|".trim($used[0])."|";
				$i = count($used[1]);
				foreach ($used[1] as $client)
				{
					$line .= trim($client[0]);
					$line .= "(";
					$line .= trim($client[1]);
					$line .= ")";
					if ($i > 1)
						$line .= ",";
					$i--;
				}
				fwrite($fp,trim($line)."\n");
			}
			fclose($fp);
		}
	}
}
//___________________________________________________________________________________________________
function UpdateUnknownSids()
{
	global $debug;
	global $unknownSids;
	global $activeclients_file;

	if (!isset($unknownSids))
		LoadUnknownSids();

	checkFile($activeclients_file);
	$activeclients_data = file ($activeclients_file);

	foreach ($activeclients_data as $currentline)
	{
		$inceput1 = substr($currentline,0,1);
		$inceput2 = substr($currentline,1,2);
		if (strstr($currentline,"| Shareinfo")) break;

		if ($inceput1 == "|" && $inceput2 != " U")
		{
			$active_client = explode("|", $currentline);
			$ac_Username                    = trim($active_client[1]);
//			$ac_IP				= trim($active_client[2]);
//			$ac_Connected			= trim($active_client[3]);
//			$ac_Idle			= trim($active_client[4]);
//			$ac_ECM				= trim($active_client[5]);
//			$ac_EMM				= trim($active_client[6]);
//			$ac_Version			= trim($active_client[7]);
			$ac_LastShare			= trim($active_client[8]);

//			$ac_EcmTime     = "";
//			if (isset($active_client[9]))
//				$ac_EcmTime = trim($active_client[9]);

//			$clientActiv[$ac_Username]["Info"] = array ($ac_IP,$ac_Connected,$ac_Idle,$ac_ECM,$ac_EMM,$ac_Version,$ac_LastShare,$ac_EcmTime);
			$clientActiv[$ac_Username]["Info"] = array ($ac_LastShare);
                }
        }

	foreach ($clientActiv as $username => $client)
	{
		$lastused_Share = explode(" ", $client["Info"][0]);
		$lastused_ShareCount = count($lastused_Share);
		$text_lastshare = "";for ($k = 0; $k <= $lastused_ShareCount-2; $k++) $text_lastshare = $text_lastshare.$lastused_Share[$k]." ";
		if (IsUnknownSid($text_lastshare))
			addUnknownSid(trim($text_lastshare), trim($username));
	}

	ksort($unknownSids);

	saveUnknownSids();
}
//___________________________________________________________________________________________________
function addUnknownSid($sid, $client)
{
	global $debug;
	global $unknownSids;

	if (isset($unknownSids[$sid]) && in_array($unknownSids[$sid],$unknownSids))
	{

		// Sid has already been found, only increment counter

		$clientfound = false;
		$unknownSids[$sid][0]++;

		for ($i=0; $i<count($unknownSids[$sid][1]); $i++)
		{
			if ($unknownSids[$sid][1][$i][0] == $client)	// client already found
			{
				// increment usage
				$unknownSids[$sid][1][$i][1] = (string)((int)$unknownSids[$sid][1][$i][1] + 1);
				$clientfound = true;				
				break;
			}
		}

		if (! $clientfound)
			$unknownSids[$sid][1][] = array($client,"1");

	}
	else
	{

		// sid has been found for the first time
		// add sid and set counter to 1

		$unknownSids[$sid][0] = 1;
		$clientusage = array($client,"1");
		$unknownSids[$sid][1] = array($clientusage);
	}
}
//___________________________________________________________________________________________________
function getMostActiveClients()
{
	global $most_activeclients_file;

	$mostactiveclients = 0;

	if (file_exists($most_activeclients_file))
	{
                $most_activeclients_data = file ($most_activeclients_file);
                $savedline = $most_activeclients_data[0];
                sscanf ($savedline,"%d",$mostactiveclients); // sscanf ($savedline,"%d",&$mostactiveclients);
        }

	return $mostactiveclients;
}
//___________________________________________________________________________________________________
function initPairs()
{   
   global $pair_file;
   global $SERVER_PAIR;
   
   if (!isset($SERVER_PAIR) && file_exists($pair_file))
   {
      $pair_data = file ($pair_file);
      foreach ($pair_data as $currentline) 
      {  
         list($S_SERVER, $S_CLIENTS) = explode("/", $currentline);
         $S_SERVER = trim($S_SERVER);
         $S_CLIENTS = trim($S_CLIENTS);
         if (strstr($S_CLIENTS,";"))
         {
            $S_CLIENTS = explode(";", $S_CLIENTS); 
            foreach ($S_CLIENTS as $S_CLIENT) 
               $SERVER_PAIR[$S_SERVER][] = $S_CLIENT;
         }
         else
         {
            $SERVER_PAIR[$S_SERVER][] = $S_CLIENTS;
         }
      }
   }
}
//___________________________________________________________________________________________________
function initClients()
{   
   global $clients_file;
   global $clientConectat;
   
   if (!isset($clientConectat) && file_exists($clients_file))
   {
      $clients_data = file ($clients_file);
      foreach ($clients_data as $currentline) 
      {
         $inceput1 = substr($currentline,0,1);
         $inceput2 = substr($currentline,1,2);
         if (strstr($currentline,"| Shareinfo")) break;  
   
         if ($inceput1 == "|" && $inceput2 != " U")
         {
            $active_client       = explode("|", $currentline);
            $ac_Username         = trim($active_client[1]);
            $ac_IP               = trim($active_client[2]);
            $ac_Connected        = trim($active_client[3]);
            $ac_Idle             = trim($active_client[4]);
            $ac_ECM              = trim($active_client[5]);
            $ac_EMM              = trim($active_client[6]);
            $ac_Version          = trim($active_client[7]);
            $ac_LastShare        = trim($active_client[8]);
            
            $ac_EcmTime = "";
            if (isset($active_client[9])) 
               $ac_EcmTime = trim($active_client[9]);
            
            $clientConectat[$ac_Username]["Info"] = array ($ac_IP,$ac_Connected,$ac_Idle,$ac_ECM,$ac_EMM,$ac_Version,$ac_LastShare,$ac_EcmTime);
            tara($ac_IP,$ac_Username);
            
         }
      }
   }
}
//___________________________________________________________________________________________________
function getHostIP($host_DNS)
{
	$eDNSIP = ereg("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$",$host_DNS);
	
	if ($eDNSIP)
	  $host_IP  = $host_DNS;
	else
	{
	  $host_IP = gethostbyname(trim($host_DNS));
	  if ($host_IP == $host_DNS )
	     $host_IP = "unknown";
	}
	return $host_IP;
}
//___________________________________________________________________________________________________
function UpdateServersCountryIP()
{
   loadGlobalServers();
   loadECMServers();

   global $servers_file;
   global $globalServers;
   global $Server_Conectat_Local;
   
   global $SERVER_PAIR;
   global $clientConectat;
   initPairs();
   initClients();

   $servers_data = file ($servers_file);
   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host      = trim($server[1]);
         $server_Time      = trim($server[2]);
         $server_Type      = trim($server[3]);
         $server_Ver       = trim($server[4]);
         $server_Nodeid    = trim($server[5]);
         $server_Cards     = trim($server[6]);
         $server_Idents    = trim($server[7]);

         if ($server_Host != "")
         {
            list($host_DNS, $host_PORT) = explode(":", $server_Host);
            $taraSaved = taraNameSaved($server_Host);
            
            $checkIP = true;
            if (isset($SERVER_PAIR[$server_Host]))
            {
               
               foreach ($SERVER_PAIR[$server_Host] as $Client_afisat) 
               {
                  $IPdiferit = false;
                  $IPClient = trim($clientConectat[$Client_afisat]["Info"][0]);
                  $IPServer = trim($taraSaved[1]);
                  if ($IPClient == $IPServer)
                  {
                     $checkIP = false;
                     break;
                  }
               }
            }
            else
               $checkIP = false;
               
            if ($checkIP == true || $taraSaved[0]  == "" || $taraSaved[1] == "")
            {
               $host_IP = getHostIP($host_DNS);
               tara($host_IP,$server_Host);
               $globalServers[$server_Host] = array( $server_Nodeid,$host_IP,$taraSaved[0]["tara"]);
            }
            else
            {
               $globalServers[$server_Host] = array( $server_Nodeid,$taraSaved[1],$taraSaved[0]["tara"]);
            }

            $Server_Conectat_Local[$server_Nodeid] = $server_Host;

            $lastServer = $server_Host;
         }
      }
   }

   saveGlobalServers();
   saveGlobalNodeID();
}
//___________________________________________________________________________________________________
function saveGlobalServers()
{
   global $globalServers;
   global $globalServersfile;

   ksort($globalServers);
   $fp = @fopen($globalServersfile,"w");
   foreach ($globalServers as $S_NAME => $S_INFO)
   {
      if (strstr($S_INFO[1],"192.168.") || strstr($S_INFO[1],"127.0.0.1")) continue;
      fwrite($fp, $S_NAME."|".$S_INFO[0]."|".$S_INFO[1]."|".$S_INFO[2]."\n");
   }
   fclose($fp);
}
//___________________________________________________________________________________________________
function saveGlobalNodeID()
{
   global $globalNodeIDfile;
   global $Server_Conectat_Local;
   global $Server_Conectat_Global;
   global $globalNodeIDNames;

   $globalNodeID_data = file ($globalNodeIDfile);
   foreach ($globalNodeID_data as $currentline)
   {
      list($S_node, $S_host) = explode("|", $currentline);
      $S_node = trim($S_node);
      $S_host = trim($S_host);

      $globalNodeIDNames[$S_node] = $S_host;
   }

   foreach ($Server_Conectat_Global as $S_node => $S_host)
      if ($S_node!="") $globalNodeIDNames[$S_node] = $S_host;

   foreach ($Server_Conectat_Local as $S_node => $S_host)
      if ($S_node!="") $globalNodeIDNames[$S_node] = $S_host;

   $fp = @fopen($globalNodeIDfile,"w");
   foreach ($globalNodeIDNames as $S_node => $S_host)
      fwrite($fp, $S_node."|".$S_host."\n");
   fclose($fp);
}

//___________________________________________________________________________________________________
function UpdateServersECM()
{
   global $ECMservers;
   global $servers_file;

   $servers_data = file ($servers_file);
   $lastServer = "";
   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host      = trim($server[1]);
         $server_Time      = trim($server[2]);
         $server_Type      = trim($server[3]);
         $server_Ver       = trim($server[4]);
         $server_Nodeid    = trim($server[5]);
         $server_Cards     = trim($server[6]);
         $server_Idents    = trim($server[7]);

         if ($server_Host != "")
         {
            $lastServer = $server_Host;
            $ECMservers[$server_Host]["Info"] = array ($server_Time,$server_Type,$server_Ver,$server_Nodeid,$server_Cards);  
         }
         
         $hit_array = explode(" ",$server_Idents);
         if ($hit_array[0] != "")
         {
            $hit_provider  = explode(":",$hit_array[1]);
            $hit_exact     = explode("(",$hit_array[2]);
            $hit_exact2    = explode(")",$hit_exact[1]);

            $hit_ecm    = $hit_exact[0];
            $hit_ecmOK  = $hit_exact2[0];

            if (!isset($ECMservers[$lastServer]["Info"]["ECM_NOW"]["ECM"]))
               $ECMservers[$lastServer]["Info"]["ECM_NOW"]["ECM"] = 0;
            if (!isset($ECMservers[$lastServer]["Info"]["ECM_NOW"]["ECMOK"]))
               $ECMservers[$lastServer]["Info"]["ECM_NOW"]["ECMOK"] = 0;

            $ECMservers[$lastServer]["Info"]["ECM_NOW"]["ECM"]+= $hit_ecm;
            $ECMservers[$lastServer]["Info"]["ECM_NOW"]["ECMOK"]+= $hit_ecmOK;
         }
      }
   }

   loadECMServers();
   $modificat = 0;
   foreach ($ECMservers as $ECMserver => $ECMData)
   if (isset($ECMservers[$ECMserver]["Info"]["ECM_NOW"]))
   {
      $ecm_salvat_ecmok = $ECMservers[$ECMserver]["Info"]["ECM_SAVED"]["ECMOK"];
      $ecm_salvat_ecm   = $ECMservers[$ECMserver]["Info"]["ECM_SAVED"]["ECM"];
      $ecm_now_ecmok    = $ECMservers[$ECMserver]["Info"]["ECM_NOW"]["ECMOK"];
      $ecm_now_ecm      = $ECMservers[$ECMserver]["Info"]["ECM_NOW"]["ECM"];
      
      if ($ecm_now_ecmok != "" || $ecm_now_ecm !="")
      {
         if ($ecm_now_ecm > 500 || $ecm_salvat_ecmok == "" || $ecm_now_ecmok > $ecm_salvat_ecmok)
         {
            $ECMservers[$ECMserver]["Info"]["ECM_SAVED"]["ECM"]   = $ecm_now_ecm;
            $ECMservers[$ECMserver]["Info"]["ECM_SAVED"]["ECMOK"] = $ecm_now_ecmok;

            $modificat = 1;
         }
         else
         if ($ecm_salvat_ecmok == $ecm_now_ecmok && $ecm_now_ecm > $ecm_salvat_ecm)
         {
            $ECMservers[$ECMserver]["Info"]["ECM_SAVED"]["ECM"]   = $ecm_now_ecm;
            $ECMservers[$ECMserver]["Info"]["ECM_SAVED"]["ECMOK"] = $ecm_now_ecmok;

            $modificat = 1;
         }
      }
   }

   if ($modificat == 1)
      saveECMServers();
}
//___________________________________________________________________________________________________
function saveECMServers()
{
   global $ECM_file;
   global $ECMservers;

   $fp = @fopen($ECM_file,"w");
   foreach ($ECMservers as $ECMserver => $ECMData)
   {
      fwrite($fp, $ECMserver."|".$ECMData["Info"]["ECM_SAVED"]["ECM"]."|".$ECMData["Info"]["ECM_SAVED"]["ECMOK"]."\n");
   }
   fclose($fp);
}
//___________________________________________________________________________________________________
function loadECMServers($all = false)
{
   global $ECM_file;
   global $ECMservers;


   $ECM_data = file ($ECM_file);
   foreach ($ECM_data as $currentline)
   {
      list($DNS_SAVED, $ECM_SAVED, $ECMOK_SAVED) = explode("|", $currentline);
      $DNS_SAVED     = trim($DNS_SAVED);
      $ECM_SAVED     = trim($ECM_SAVED);
      $ECMOK_SAVED   = trim($ECMOK_SAVED);

      if (isset($ECMservers[$DNS_SAVED]) || $all == true)
      {
          $ECMservers[$DNS_SAVED]["Info"]["ECM_SAVED"]["ECM"]     = $ECM_SAVED;
          $ECMservers[$DNS_SAVED]["Info"]["ECM_SAVED"]["ECMOK"]   = $ECMOK_SAVED;
      }
   }
}
//___________________________________________________________________________________________________
function loadGlobalServers()
{
   global $globalServers;
   global $globalServersfile;
   global $Server_Conectat_Global;

   $globalServers_data = file ($globalServersfile);
   foreach ($globalServers_data as $currentline)
   {
      list($DNS_SAVED, $NODE_SAVED, $IP_SAVED, $TARA_SAVED) = explode("|", $currentline);
      $DNS_SAVED  = trim($DNS_SAVED);
      $NODE_SAVED = trim($NODE_SAVED);
      $IP_SAVED   = trim($IP_SAVED);
      $TARA_SAVED = trim($TARA_SAVED);
      $globalServers[$DNS_SAVED] = array( $NODE_SAVED,$IP_SAVED,$TARA_SAVED);

      if ($DNS_SAVED !="")
         $Server_Conectat_Global[$NODE_SAVED] = $DNS_SAVED;
   }
}
//___________________________________________________________________________________________________        
function loadLocalServers()
{
   global $servers_file;
   global $Server_Conectat_Local;

   $servers_data = file ($servers_file);
   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host    = trim($server[1]);
         $server_Nodeid = trim($server[5]);
         if ($server_Host != "")
         {
            $Server_Conectat_Local[$server_Nodeid] = $server_Host;
         }
      }
   }
}
//___________________________________________________________________________________________________
function loadServersHosts()
{
   global $servers_file;
   global $ServerHost_Conectat;

   $servers_data = file ($servers_file);
   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);

      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host    = trim($server[1]);
         $server_Time   = trim($server[2]);
         if ($server_Host != "")
         {
           $ServerHost_Conectat[$server_Host] = $server_Time;
         }
      }
   }
}
//___________________________________________________________________________________________________
function nodeIdName($nodeid)
{
	global $Server_Conectat_Global;
	global $Server_Conectat_Local;
	
	if (!isset($Server_Conectat_Global)) loadGlobalServers();
	if (!isset($Server_Conectat_Local)) loadLocalServers();
	
	$node = explode("_",$nodeid);   
	
	$ret = $nodeid;
	if (isset($Server_Conectat_Local[$node[0]]))
	{
		$Server_Host = $Server_Conectat_Local[$node[0]];
		$ret = $Server_Host."_".$node[1];
	}
	else
	if (isset($Server_Conectat_Global[$node[0]]))   
	{
		$Server_Host = $Server_Conectat_Global[$node[0]];
		$ret = "[".$Server_Host."]_".$node[1];
	}
	return $ret;

}
//___________________________________________________________________________________________________
function pingDomain($domain,$port,$timeout=5)
{
	global $LastPingError;
   $starttime = microtime(true);
   $conex      = fsockopen ($domain, $port, $errno, $errstr, $timeout);
   $stoptime = microtime(true);
   $status    = 1;
   
   

   if (!$conex)
   {
      $status = -1;  // Site is down
      $LastPingError = $errstr;
   }
   else
   {
		fclose($conex);
      
      $status = ($stoptime - $starttime) * 1000;
      $status = floor($status);
      
      if ($status == 0) $status = 1;
   }

   return $status;
}
//___________________________________________________________________________________________________
function SendMessage($HOST)
{
	return $OUT;
}
//___________________________________________________________________________________________________
function SavedPing($NAME)
{
	global $ping_file;
	
	$ping_data = file ($ping_file);
	foreach ($ping_data as $currentline) 
	{
		list($S_NAME,$S_PING, $S_COUNT,$S_BEST) = explode("|", $currentline);
		$S_NAME  = trim($S_NAME);
		$S_PING  = trim($S_PING);
		$S_COUNT = trim($S_COUNT);
		$S_BEST  = trim($S_BEST);
		
		if ($S_BEST == "") $S_BEST = $S_PING;
		
		if ($S_NAME == $NAME)
			return array($S_PING,$S_COUNT,$S_BEST);
	}
	
	return array("","");
}
//___________________________________________________________________________________________________
function SavePing($NAME,$PING)
{
	global $ping_file;
	$NAME = trim($NAME);
	$PING = trim($PING);
	
	$ping_data = file ($ping_file);
	foreach ($ping_data as $currentline) 
	{
		list($S_NAME, $S_PING, $S_COUNT,$S_BEST) = explode("|", $currentline);
		$S_NAME  = trim($S_NAME);
		$S_PING  = trim($S_PING);
		$S_COUNT = trim($S_COUNT);
		$S_BEST  = trim($S_BEST);
		
		$ping_file_data[$S_NAME] = array ($S_PING,$S_COUNT,$S_BEST);
	}
	
	$OLD_PING  = 0;if (isset($ping_file_data[$NAME][0])) $OLD_PING  = (int)$ping_file_data[$NAME][0];               
	$OLD_COUNT = 0;if (isset($ping_file_data[$NAME][1])) $OLD_COUNT = (int)$ping_file_data[$NAME][1];
	$OLD_BEST  = 0;if (isset($ping_file_data[$NAME][2])) $OLD_BEST  = (int)$ping_file_data[$NAME][2];
	
	$NEW_COUNT = $OLD_COUNT+1;
	if ($NEW_COUNT > 31) 
	{
	   $NEW_COUNT = 31;
	}
	
	$NEW_PING =$PING;
	
	if ($OLD_PING != 0)  
	{
      $NEW_PING_FACTOR = 1;
      if ($NEW_PING > $OLD_PING) $NEW_PING_FACTOR = 3;

      $NEW_PING = (int)( ($PING*$NEW_PING_FACTOR + $OLD_PING*($OLD_COUNT)) / ($OLD_COUNT+$NEW_PING_FACTOR));
	}
	
	$NEW_BEST = $OLD_BEST;
	if ($OLD_BEST == 0 || $PING < $OLD_BEST)
		$NEW_BEST = $PING;
		
	if ($NEW_PING < $NEW_BEST)
		$NEW_BEST = $NEW_PING;
	      
	$ping_file_data[$NAME] = array ($NEW_PING,$NEW_COUNT,$NEW_BEST);
	
	$fp = @fopen($ping_file,"w");
	foreach ($ping_file_data as $S_NAME => $S_INFO) 
	{
		fwrite($fp, $S_NAME."|".$S_INFO[0]."|".$S_INFO[1]."|".$S_INFO[2]."\n");
	}
	fclose($fp);
       
}
//___________________________________________________________________________________________________
function whois($IP)
{
	$SERVER = "whois.ripe.net";
	
	@$CON=fsockopen($SERVER,43, $errno, $errstr, 10);
	if (!$CON) 
	{
	return "";
	}
	@fputs($CON,$IP."\r\n");
	unset($OUT);
	
	while(!feof($CON))
	{
		$OUT.=fread($CON,1000);
	}
	if (!(strpos($OUT,"ERROR")===false && strpos($OUT,"NOT FOUND")===false && strpos($OUT,"No data found")===false && strpos($OUT,"No match for")===false))
		$OUT="?";
	else
	{
		foreach($OUT as $linie)
	   	echo $linie."<BR>";
	}
	return $OUT;
}
//___________________________________________________________________________________________________
function clientIP($IP,$exclude="")
{
   global $country_data;
   global $pagina;
   
   $exclude = trim($exclude);
   $CLIENTI="";
   $i=0;
   foreach ($country_data as $currentline) 
   {
      list($IP_SAVED, $TARA_CODE, $CLIENT) = explode("|", $currentline);
      $IP_SAVED = trim($IP_SAVED);
      $TARA_CODE = trim($TARA_CODE);
      $CLIENT = trim($CLIENT);
      if ($IP == $IP_SAVED && !strstr($CLIENT,":") )
      {
         if ($exclude != $CLIENT)
         {
            if ($i==0)  $CLIENTI = $CLIENTI." "."<A HREF=".$pagina."?username=".$CLIENT.">".$CLIENT."</A>";
            else        $CLIENTI = $CLIENTI.", "."<A HREF=".$pagina."?username=".$CLIENT.">".$CLIENT."</A>";
            
            //"<A HREF=".$pagina."?username=".$CLIENT.">".$CLIENT."</A>"

            $i++;
         }
      }
   }
   return trim($CLIENTI);
}
//___________________________________________________________________________________________________
function taraName($NAME)
{
   global $country_whois;
   if ($country_whois == false)
      return "";
         
   global $countrycode_file;
   global $countrycode_data;
   if (!isset($countrycode_data))
      return "";      
   
   $NAME = strtoupper(trim($NAME));
   $TARA="";
   foreach ($countrycode_data as $currentline) 
   {
      list($TARA_CODE, $TARA_NAME) = explode("     ", $currentline);
      $TARA_CODE = strtoupper(trim($TARA_CODE));
      
      if ($TARA_CODE == $NAME)
      {
         $TARA = $TARA_NAME;
         break; 
      }
   }
   return $TARA;
}
//___________________________________________________________________________________________________
function taraNameSaved($NAME)
{
   global $country_whois;
   if ($country_whois == false)
      return array("","");
         
   global $country_data;
   
   $NAME == trim($NAME);
   $TARA["tara"]="";
   $TARA["info"]="";
   $IP="";
   
   foreach ($country_data as $currentline) 
   {
      list($IP_CACHE, $TARA_CACHE, $TARA_USER, $TARA_ORAS) = explode("|", $currentline);
      $IP_CACHE   = trim($IP_CACHE);
      $TARA_CACHE = trim($TARA_CACHE);
      $TARA_USER  = trim($TARA_USER);
      $TARA_ORAS  = trim($TARA_ORAS);
         
      if ($NAME == $TARA_USER)
      {
         $TARA["tara"] = $TARA_CACHE;
         $TARA["info"] = $TARA_ORAS;
         $IP = $IP_CACHE;
         break; 
      }
   }
   return array($TARA,$IP);
}
//___________________________________________________________________________________________________
function taraSaved($IP,$NAME="")
{
   global $country_whois;
   if ($country_whois == false)
      return "";
   
   global $country_data;
   
   $NAME == trim($NAME);
   $TARA["tara"]="";
   $TARA["info"]="";
   foreach ($country_data as $currentline) 
   {
      list($IP_CACHE, $TARA_CACHE, $TARA_USER, $TARA_ORAS) = explode("|", $currentline);
      $IP_CACHE   = trim($IP_CACHE);
      $TARA_CACHE = trim($TARA_CACHE);
      $TARA_USER  = trim($TARA_USER);
      $TARA_ORAS  = trim($TARA_ORAS);
      
      if ($IP == $IP_CACHE)
      {
         if ($NAME == "" || $NAME == $TARA_USER)
         {
            $TARA["tara"] = $TARA_CACHE;
            $TARA["info"] = $TARA_ORAS;
            break; 
         }
      }
   }
   return $TARA;
}

//___________________________________________________________________________________________________
function saveIPTaraName($IP,$TARA,$NAME)
{      
   if ($IP == "unknown")
      return; 
   if ($NAME == "")
      return;

   global $country_file;
   global $country_data;
       
       
   foreach ($country_data as $currentline)
   {
      list($S_IP, $S_TARA, $S_NAME, $S_ORAS) = explode("|", $currentline);
      $S_IP = trim($S_IP);
      $S_TARA = trim($S_TARA);
      $S_NAME = trim($S_NAME);
      $S_ORAS = trim($S_ORAS);
      $country_file_data[$S_NAME] = array ($S_IP,$S_TARA,$S_ORAS);
   }
       
   if (!isset($country_file_data[$NAME]) ||
              $country_file_data[$NAME][0] != $IP ||
              $country_file_data[$NAME][1] != $TARA["tara"] ||
              $country_file_data[$NAME][2] != $TARA["info"] )
   {
      if (! (isset($country_file_data[$NAME]) && $TARA["tara"] =="") )
      {
         $country_file_data[$NAME] = array ($IP,$TARA["tara"],$TARA["info"]);

         $fp = @fopen($country_file,"w");
         foreach ($country_file_data as $S_NAME => $S_INFO)
         {
            fwrite($fp, $S_INFO[0]."|".$S_INFO[1]."|".$S_NAME."|".$S_INFO[2]."\n");
         }
         fclose($fp);

         $country_data = file ($country_file);
      }
   }
}
//___________________________________________________________________________________________________
function tara($IP,$NAME="")
{
	if ($IP == "unknown")
	{
		$TARA["tara"]="??";
   	$TARA["info"]="UNKNOWN";
      return $TARA;
   }
      
   $NAME == trim($NAME);
   $TARA=taraSaved($IP);
   if ($TARA["tara"] !="")
   {
      saveIPTaraName($IP,$TARA,$NAME);
      return $TARA;
   }       

   $TARA["tara"]="";
   $TARA["info"]="";
   
   global $country_whois;
   if ($IP =="127.0.0.1")
	{
   	$TARA["tara"]="<>";
   	$TARA["info"]="";
   }
   else
   if ($country_whois == true)
   {
      
      // apnic.net> - Asia pacific
      // ripe.net> - Europe
      // arin.net> - North America
      // lacnic.net> - Latin America
      // afrinic.net> - Africa and Indian Ocean


      $SERVERE=array("whois.ripe.net","whois.afrinic.net","whois.arin.net","whois.lacnic.net","whois.apnic.net");
      foreach($SERVERE as $SERVER)
      {
         @$CON=fsockopen($SERVER,43, $errno, $errstr, 10);
         if (!$CON)
         {
            $TARA["tara"]="?";
            $TARA["info"]="";
            continue;
         }

         @fputs($CON,$IP."\r\n");
         unset($OUT);
         $OUT = "";
         while(!feof($CON))
         {
            $OUT.=fread($CON,1000);
         }
         
         $TARA["tara"]="?";
         $TARA["info"]="";

         if (strpos($OUT,"ERROR")===false && strpos($OUT,"NOT FOUND")===false && strpos($OUT,"No data found")===false && strpos($OUT,"No match for")===false)
         {
         	$netname = "";
         	$TARA["info"]="";
         	
            $OUT_LIST = explode("\n",htmlspecialchars($OUT));
            foreach($OUT_LIST as $linie)
            {
            	$linie = trim($linie);
            	if ($netname!="" && $linie == "")
            		break;
            		
               if ($TARA["tara"] == "?" && strstr(strtoupper($linie),"COUNTRY:"))
               {
                  list($temp, $rest) = explode(":", $linie);
                  $TARA["tara"] = trim(strtoupper($rest));
               }
               
               if (strstr(strtoupper($linie),"NETNAME:"))
               {
               	$netname = $linie;
                  list($temp, $rest) = explode(":", $linie);
                  if ($TARA["info"]!="") $TARA["info"] = $TARA["info"].";";
                  $TARA["info"] = $TARA["info"]."[NETNAME] ".trim($rest)." ";
               }

               if (strstr(strtoupper($linie),"DESCR:"))
               {
                  list($temp, $DESCRIERE) = explode(":", $linie);

                  $TARA["info"] = $TARA["info"]."; ".trim($DESCRIERE);

                  if (strstr($DESCRIERE,"for private"))
                  {
                     $TARA["tara"]="<>";
                  }

               }
            }
            
            if (strlen($TARA["tara"])==2)
               break;
         }
      }
   }
   
   saveIPTaraName($IP,$TARA,$NAME);

   return $TARA;
}

//___________________________________________________________________________________________________  
function isNewerCCcamVersion($cccam_version1, $cccam_version2)
{
        $is_newer = false;
        list($cccam_version1,$cccam_major1,$cccam_minor1) = explode(".", $cccam_version1);
        list($cccam_version2,$cccam_major2,$cccam_minor2) = explode(".", $cccam_version2);
        if ((int)$cccam_version2 > (int)$cccam_version1)
                $is_newer = true;
        else if ((int)$cccam_version2 == (int)$cccam_version1)
        {
                if ((int)$cccam_major2 > (int)$cccam_major1)
                        $is_newer = true;
                else if((int)$cccam_major2 == (int)$cccam_major1)
                {
                        if ((int)$cccam_minor2 > (int)$cccam_minor1)
                                $is_newer = true;
                }
        }

        return $is_newer;
}

//___________________________________________________________________________________________________  
function isNewerOrEqualCCcamVersion($cccam_version1, $cccam_version2)
{
        $is_newerorequal = false;
        list($cccam_version1,$cccam_major1,$cccam_minor1) = explode(".", $cccam_version1);
        list($cccam_version2,$cccam_major2,$cccam_minor2) = explode(".", $cccam_version2);

        if ((int)$cccam_version2 > (int)$cccam_version1)
                $is_newerorequal = true;
	else if ((int)$cccam_version2 == (int)$cccam_version1)
        {
                if ((int)$cccam_major2 > (int)$cccam_major1)
                        $is_newerorequal = true;
                else if((int)$cccam_major2 == (int)$cccam_major1)
                {
                        if ((int)$cccam_minor2 >= (int)$cccam_minor1)
                                $is_newerorequal = true;
                }
        }

        return $is_newerorequal;
}

//___________________________________________________________________________________________________
function isnotlocalCAId($caid, $node_cccam_version="")
{
	global $notlocalcaids;

	$isnotlocalinCCcam = false;
        foreach ($notlocalcaids as $checkcaid)
        {
                if ($checkcaid[0] == ltrim($caid,"0"))
		{
			$isnotlocal_cccamversion = $checkcaid[1];
			if ($node_cccam_version == "" || $isnotlocal_cccamversion == "")
				$isnotlocalinCCcam = true;
			else
			{
				if (!isNewerOrEqualCCcamVersion($isnotlocal_cccamversion, $node_cccam_version))
					$isnotlocalinCCcam = true;
			}
		}
        }	
	return $isnotlocalinCCcam;
}

//___________________________________________________________________________________________________
function file_delete($file)
{
	global $debug;

	if (file_exists($file))
	{
		if ($debug)
			return true;
		else
			return (unlink($file));
	}
	return false;
}

//___________________________________________________________________________________________________
function file_count($file)
{
	$count = 0;

	if (file_exists($file))
	{
		$array = file($file);
		$count = count($array);
	}
	return $count;
}

//___________________________________________________________________________________________________

if (file_exists("CCcam.providers"))     
        $providers_ident = file ("CCcam.providers");
else
if (file_exists("ident.info"))  
        $providers_ident = file ("ident.info");
        
        
if (isset($providers_ident))
{
        foreach ($providers_ident as $currentline) 
        {
                $inceput = substr($currentline,0,1);
                if ($inceput != ";" && $inceput != "#" && $currentline!="")
                {
                        list($caid,$nume) = explode(" ", $currentline,2);
                        if ( isset($caid) && $caid!="" )
                        {
                                if (strstr($caid,";")) 
                                        list($caid,$caid2) = explode(";", $caid);
                                
                                $caid = trim($caid);
                                $nume = trim($nume);
                                
                                if (strstr($nume,"\"")) 
                                {
                                        $numeexplode = explode("\"", $nume);
                                        $nume = $numeexplode[1];
                                }
                                
                                $inceput_caid = substr($caid,0,2);
                                
                                //- daca incepe cu 01 sau 05 se insereaza "00:" pe pozitia 3
                                //- daca incepe cu 0D se taie ultimile 2 caractere si se insereaza ":0000" pe pozitia 5
                                //- in rest se insereaza ":00" pe pozitia 5 
                                
                                if ($inceput_caid == "01") $caid_new = substr($caid,0,2)."00:".substr($caid,2,6);
                                else
                                if ($inceput_caid == "05") $caid_new = substr($caid,0,2)."00:".substr($caid,2,6);
                                else
                                if ($inceput_caid == "0D") 
                                {
                                        if (substr($caid,6,2) == "00")
                                                $caid_new = substr($caid,0,4).":0000".substr($caid,4,2);
                                        else
                                                $caid_new = substr($caid,0,4).":0000".substr($caid,6,2);
                                }
                                else
                                        $caid_new = substr($caid,0,4).":00".substr($caid,4,4);
                                        
                        
                        
                                list($ca,$id) = explode(":", $caid_new);
        
                                $ca = sterg0($ca);
                                $id = sterg0($id);
        
                                $caid_new = strtolower($caid_new);
                                $caidstrip = $ca.":".$id;
                                $caidstrip = strtolower($caidstrip);
                                
                                $CCcam_providers[$caid_new] = $nume;
                                $CCcam_providersShort[$caidstrip] = $nume;
                                $CCcam_providers2[$caid] = $nume;
                        } 
                }
        }
        
}
/*
//save CCcam.providers 
$fp = @fopen("CCcam.providers.save","w");
foreach ($CCcam_providers2 as $caid => $nume) 
{
	
	if ($nume != "fake ID")
	{
		//echo $nume;
      fwrite($fp, $caid ." \"".$nume."\"\n");
   }
}
fclose($fp);
*/

	if (defined('CONFIG_NONPUBLIC') && file_exists("nonpublic/common_nonpublic.php") && !defined('COMMON_NONPUBLIC'))
		include "nonpublic/common_nonpublic.php";

	$timp_lastupdate= "";

	if (file_exists($update_log)) 
	{
		$update_log_data = file ($update_log);
		$timp_lastupdate = $update_log_data[0];
	}

	if ($username != "")
	{
		$skipUpdate = true;

		include "meniu.php";
		include "client.php";
		exit;
	}

	if ($server_nodeDns != "")
	{
		$skipUpdate = true;

		include "meniu.php";
		include "server.php";
		exit;
	}
   
	if ($node!="")
	{
		$skipUpdate = true;

		include "meniu.php";
		include "node.php";
		exit;
	}
   
	if ($provider!="")
	{
		$skipUpdate = true;

		include "meniu.php";
		include "provider.php";
		exit;
	}
   
	if ($pingAll!="")
	{
		$skipUpdate = true;
      
		include "meniu.php";
		include "pingAll.php";
		exit;
	}

	if ($serverstats_checkPayserver!="" && $use_yaps)
	{
		$skipUpdate = true;

		include "meniu.php";
		include "checkPayserverAll.php";
		exit;
	}

	if ($server_show_checkSecurity_all!="" && file_exists("nonpublic/showSecurityAll_nonpublic.php"))
        {
		$skipUpdate = true;

		include "meniu.php";
		include "nonpublic/showSecurityAll_nonpublic.php";
		exit;
	}

	if ($server_checkSecurity_all!="" && file_exists("nonpublic/checkSecurityAll_nonpublic.php") && $use_portscan_all)
	{
		$skipUpdate = true;

		include "meniu.php";
		include "nonpublic/checkSecurityAll_nonpublic.php";
		exit;
	}
?>
