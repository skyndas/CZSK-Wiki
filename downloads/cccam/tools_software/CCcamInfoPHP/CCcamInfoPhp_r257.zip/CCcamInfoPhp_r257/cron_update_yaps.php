<?php
   include "common.php";
   include "payservercheck.php";

   /* old YaPS functions, obsolete for YaPS version 4.0
      can be removed later!

   if (yapsAvailable($yapservice, "date", $secure) && !yapsUptodate($yapservice, $yaps_payserver, $secure)){
      yapsUpdate($yapservice, $yaps_payserver, $secure);
   }
   */

   if (yapsAvailable() && !yapsUptodate()){
      yapsUpdate();
   }

?>
