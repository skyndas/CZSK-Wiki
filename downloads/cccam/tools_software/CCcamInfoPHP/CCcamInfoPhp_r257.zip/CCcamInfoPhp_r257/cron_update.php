<?php
   $cron_p= ""; if(isset($_GET['p'])) $cron_p = $_GET['p'];
   $cron_profil = (int)(trim($cron_p));
   $cron_update = true;
   $doUpdate = false;
   include "common.php";

   echo "Disclosure is ".DISCLOSURE.".<br>";
   if(function_exists('isCronupdateActive') && isCronupdateActive())
   {
      echo "function isCronupdateActive() exists and result is true!<br>";
      $doUpdate = true;
   }
   else if (function_exists('isCronupdateActive') && !isCronupdateActive())
      echo "function isCronupdateActive() exists and result is false!<br>";
   else if (!defined('COMMON_PRIVATE'))
   {
      echo "function isCronupdateActive() does not exist, thus using cron_update as default!<br>";
      $doUpdate = true;
   }
   if ($doUpdate)
   {
      echo "\$doUpdate = true, doing update.";
      $forceupdate = 1;
      include "update.php";
   }
   else
      echo "\$doUpdate = false, doing no update!";

?>
