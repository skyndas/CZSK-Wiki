<HTML>
<HEAD>
<LINK HREF="cccam.css" REL="Stylesheet" TYPE="text/css">
<style type="text/css">
<!--
.style1 {color: #AFCC00}
-->
</style>
</HEAD>
<BODY>

<?php

   $profile = $_GET['profile'];
   if ($profile == "")
   {
      if ($cccam_host!="")
      {
         include "common.php";
         include "meniu.php";
      }
   }
   else
   {
      include "config.php";
      include "common.php";
      echo "<font size='1' color'#494949'>&nbsp;</font><font size='1'><span class='style1'>&nbsp;<B>".$programversion." - <font size=2 color=yellow>".$meniu_lv_lang."</B>&nbsp; </span></font><BR>";
      echo "<BR>";
   }
?>

<script language=javascript> 
function trim(string)
{
    while(string.substr(0,1)==" ")
        string = string.substring(1,string.length) ;

    while(string.substr(string.length-1,1)==" ")
        string = string.substring(0,string.length-2) ;

    return string;
}

function SaveConfigFile(profile)
{
    server = trim(document.all("server").value);
    port = trim(document.all("port").value);
    user = trim(document.all("user").value);
    pass = trim(document.all("pass").value);
    ftpuser = trim(document.all("ftpuser").value);
    ftppass = trim(document.all("ftppass").value);
    cccamconfigfilepath = trim(document.all("cccamconfigfilepath").value);
    keyfilepath = trim(document.all("keyfilepath").value);

    if (server == "" )
    {
        alert("<?php echo $getconfigserver_lv_serverismandatory ?>");
        return;
    }

    if ((port == "") && (user != "" ) && (pass != ""))
    {
        alert("<?php echo $getconfigserver_lv_portismandatory ?>");
        return;
    }

    if (user == "" )
    {
        if (pass != "")
        {
            alert("<?php echo $getconfigserver_lv_userismandatory ?>");
            return;
        }
    }

    if (user != "")
    {
        if (pass == "")
        {
            alert("<?php echo $getconfigserver_lv_passismandatory ?>");
            return;
        }
    }

    if (ftpuser == "" )
    {
        if (ftppass != "")
        {
            alert("<?php echo $getconfigserver_lv_ftpuserismandatory ?>");
            return;
        }
    }

    if (ftpuser != "")
    {
        if (ftppass == "")
        {
            alert("<?php echo $getconfigserver_lv_passismandatory ?>");
            return;
        }
        if (cccamconfigfilepath == "")
        {
            alert("<?php echo $getconfigserver_lv_cfgpathismandatory ?>");
            return;
        }
        if (keyfilepath == "")
        {
            alert("<?php echo $getconfigserver_lv_keypathismandatory ?>");
            return;
        }
    }
		
    if (profile == "edit")
        location.href="configserver.php?profile=edit&server=" + server + "&port=" + port + "&user=" + user + "&pass=" + pass + "&ftpuser=" + ftpuser + "&ftppass=" + ftppass + "&cccamconfigfilepath=" + cccamconfigfilepath + "&keyfilepath=" + keyfilepath;
    else
        location.href="configserver.php?profile=new&server=" + server + "&port=" + port + "&user=" + user + "&pass=" + pass + "&ftpuser=" + ftpuser + "&ftppass=" + ftppass + "&cccamconfigfilepath=" + cccamconfigfilepath + "&keyfilepath=" + keyfilepath;
}

function setFocus()
{
    document.configform.server.focus();
}
</script>

<?php
// include "common.php";

   $server="";
   $port="";
   $user="";
   $pass="";
   $ftpuser="";
   $ftppass="";
   $cccamconfigfilepath="";
   $keyfilepath="";
	
   if ($profile == "edit")
   {
      $server = $_GET['server'];
      $port = $_GET['port'];
      $user = $_GET['user'];
      $pass = $_GET['pass'];
      $ftpuser = $_GET['ftpuser'];
      $ftppass = $_GET['ftppass'];
      $cccamconfigfilepath = $_GET['cccamconfigfilepath'];
      $keyfilepath = $_GET['keyfilepath'];
   }

   echo "<form name='configform' method='post' action=''>";
   echo "<table border=0 cellpadding=2 cellspacing=1 style=background-color:#363636>";

   echo "<tr>";

   // headline
   // CCcam web interface server, port, user, password
   echo "<td colspan='4' height='32'>";
   echo "<FONT COLOR=white>";
   echo "<b>".$getconfigserver_lv_web_credentials."</b>";
   echo "</FONT>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";
   echo "<td>";
   echo "<div align='right'>";
   echo $generic_lv_server.":";
   echo "</td>";

   echo "<td>";
   echo "<input type='text' name='server' value='".$server."' size=20>";
   echo "</td>";

   echo "<td>";
   echo "<div align='right'>";
   echo $getconfigserver_lv_port.":";
   echo "</td>";

   echo "<td>";
   echo "<input type='text' name='port' value='".$port."' size=20>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td>";
   echo "<div align='right'>".$getconfigserver_lv_user.":";
   echo "</td>";

   echo "<td>";
   echo "<input type='text' name='user' value='".$user."' size=20>";
   echo "</td>";

   echo "<td>";
   echo "<div align='right'>".$getconfigserver_lv_pass.":";
   echo "</td>";

   echo "<td>";
   echo "<input type='password' name='pass' value='".$pass."' size=20>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   // horizontal separator
   echo "<td colspan='4'>";
   echo "<hr>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   // headline
   // ftp user credentials
   echo "<td colspan='4' height='32'>";
   echo "<FONT COLOR=white>";
   echo "<b>".$getconfigserver_lv_ftp_credentials."</b>";
   echo "</FONT>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td>";
   echo "<div align='right'>".$getconfigserver_lv_ftpuser.":";
   echo "</td>";

   echo "<td>";
   echo "<input type='text' name='ftpuser' value='".$ftpuser."' size=20>";
   echo "</td>";

   echo "<td>";
   echo "<div align='right'>".$getconfigserver_lv_ftppass.":";
   echo "</td>";

   echo "<td>";
   echo "<input type='password' name='ftppass' value='".$ftppass."' size=20>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   // horizontal separator
   echo "<td colspan='4'>";
   echo "<hr>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   // headline
   // ftp path for CCcam configuration and key files
   echo "<td colspan='4' height='32'>";
   echo "<FONT COLOR=white>";
   echo "<b>".$getconfigserver_lv_ftp_paths."</b>";
   echo "</FONT>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td colspan='2'>";
   echo "<div align='right'>".$getconfigserver_lv_cccam_path.":";
   echo "</td>";

   echo "<td colspan='2'>";
   echo "<div align='right'>";
   echo "<input type='text' name='cccamconfigfilepath' value='".$cccamconfigfilepath."' size=32>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td colspan='2'>";
   echo "<div align='right'>".$getconfigserver_lv_key_path.":";
   echo "</td>";

   echo "<td colspan='2'>";
   echo "<div align='right'>";
   echo "<input type='text' name='keyfilepath' value='".$keyfilepath."' size=32>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   // horizontal separator
   echo "<td colspan='4'>";
   echo "<hr>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td colspan='4'>";
   echo "<div align='right'>";
   echo "<input type='button' name='Save' value='".$getconfigserver_lv_saveconfiguration."' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"SaveConfigFile('$profile')\"";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td colspan='4'>";
   showNotice($getconfigserver_lv_notice);
   echo "</td>";

   echo "</tr>";

   echo "</table>";

   echo "</form>";

   echo "<script>setFocus();</script>";

   exit;

?>
  
<BR>
</BODY>
</HTML>

