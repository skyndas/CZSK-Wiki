<?php

$generic_lv_uptime						= "Uptime";
$generic_lv_clients						= "Clients";
$generic_lv_connectedclients			= "Connected clients";
$generic_lv_activeclients				= "Active clients";
$generic_lv_username					= "Username";
$generic_lv_host						= "Host";
$generic_lv_connected					= "Connected";
$generic_lv_idletime					= "Idle time";
$generic_lv_version						= "Version";
$generic_lv_lastusedshare				= "Last used share";
$generic_lv_ecmtime						= "Ecm time";
$generic_lv_nodeid						= "NodeID";
$generic_lv_handled						= "Handled";
$generic_lv_servers						= "Servers";
$generic_lv_shares						= "Shares";
$generic_lv_providers					= "Providers";
$generic_lv_entitlements				= "Entitlements";
$generic_lv_ago							= "ago";
$generic_lv_server		 				= "Server";
$generic_lv_serverdown					= "Server is down or updating ... Please try again later";
$generic_lv_country						= "Country";
$generic_lv_type						= "Type";
$generic_lv_reshare						= "Reshare";
$generic_lv_re							= "RE";
$generic_lv_noreshare					= "NO";
$generic_lv_yesreshare					= "YES";
$generic_lv_caidident					= "CAID/Ident";
$generic_lv_caididents					= "CAID/Idents";
$generic_lv_nodes						= "Nodes";
$generic_lv_note						= "Note";
$generic_lv_ping						= "Ping";
$generic_lv_recentecmhandled			= "Recent ECM handled";
$generic_lv_provider					= "Provider";
$generic_lv_caididentslocal				= "CAID/Idents LOCAL";
$generic_lv_offline						= "OFFLINE";
$generic_lv_notice				= "Notice:";
$generic_lv_collexp1				= "Click on ";
$generic_lv_collexp2				= " to collapse/expand view!";
//-------- new : START
$generic_lv_collexp				= "Collapse/Expand view!";
$generic_lv_most_activeclients				= "Most active clients";
$generic_lv_memory				= "Memory used (actual/possible)";
$generic_lv_cccam_webif_link				= "Web Interface Link";
$generic_lv_define_cccam_webif_link			= "Define CCcam Web Interface Link";
$generic_lv_cccam_webif_available			= "web interface available";
$generic_lv_cccam_webif_not_available			= "web interface not available";
$generic_lv_cccam_webif_link_not_defined			= "web interface link not defined!";
$generic_lv_newcamd_webif_available			= "web interface available";
$generic_lv_newcamd_webif_not_available			= "web interface not available";
$generic_lv_newcamd_webif_link_not_defined			= "web interface link not defined!";
$generic_lv_define_newcs_webif_link			= "Define NewCS/OSCam/SBox Web Interface Link";
$generic_lv_newcs_webif_link				= "Web Interface Link";
$generic_lv_webif_link_status				= "Status";
$generic_lv_portsecurity_unknown			= "Security unknown";
$generic_lv_portsecurity_secure				= "Security secure";
$generic_lv_portsecurity_moderate_secure		= "Security moderate secure";
$generic_lv_portsecurity_unsecure			= "Security unsecure";
$generic_lv_portsecurity_localip			= "local IP";
$generic_lv_warning_payserver				= "Payserver";
$generic_lv_no_language_specific_changelog		= "Language specific changelog does not exist. Showing english version instead!";
$generic_lv_no_changelog				= "Changelog does not exist!";
$generic_lv_count				= "Count";
$generic_lv_localip_secure				= "Local private IP addresses are secure by definition.";
$generic_lv_portscan_excluded				= "Node is excluded from cron and complete security check";
$generic_lv_portsecurity_excluded			= "Excluded from cron and complete security check";
$generic_lv_known_by_google				= "DynDns address known by Google";
$generic_lv_portcheck_done				= "Security check done";
$generic_lv_not_known_by_google				= "DynDns address not known by Google";
$generic_lv_google_flood_protection			= "Google flood protection active, try again later!";
$generic_lv_contact					= "Contact";
//-------- new : END

//File: index.php
$index_lv_currenttime					= "Current time";
$index_lv_totalhandledecm				= "Total handled client ecm's";
$index_lv_totalhandledemm				= "Total handled client emm's";
$index_lv_totalhandledlocal				= "Total handled LOCAL ecm's";
$index_lv_peakload						= "Peak load";
$index_lv_ecmhandled					= "ECM handled";
$index_lv_providername					= "CAId/Provider Name";
$index_lv_recent						= "Recent";
$index_lv_resetnodestats		= "Reset Node Statistics";
$index_lv_resetnodenow			= "RESET NOW";
$index_lv_resetstats			= "Reset all Statistics";
$index_lv_resetnow			= "RESET NOW";
//-------- new : START
$index_lv_resetnodestats_title			= "Resetting Node Statistics for Server";
$index_lv_save					= "Save";
$index_lv_unknownsids				= "Recently requested unknown SIDs : ";
$index_lv_action_unknownsid			= "Action";
$index_lv_delete_unknownsid			= "Delete";
$index_lv_found_unknownsid			= "found";
$index_lv_knownsids			= "Actually requested known SIDs : ";
$index_lv_newer_cccam_versions		= "Unknown/newer CCcam versions : ";
$index_lv_newer_client_cccam_versions	= "Unknown/newer client CCcam versions";
$index_lv_newer_server_cccam_versions	= "Unknown/newer server CCcam versions";
$index_lv_delete_all_unknownsid		= "Delete all recently discovered unknown SIDs";
//-------- new : END

//File: menuiu.php
$meniu_lv_lang							= "Language: English";
$meniu_lv_home							= "Home";
$meniu_lv_pairs							= "Pairs";
$meniu_lv_updatebutton					= "Update";
$meniu_lv_updatetimes					= "Update times";
$meniu_lv_areyousure					= "Are you sure ?";
$meniu_lv_lastupdate					= "Last update";
$meniu_lv_selectactiveprofile			= "Select active profile or click";
$meniu_lv_new							= "New";
$meniu_lv_definenewprofile				= "to define new profile";
$meniu_lv_deleteprofile					= "Delete";
$meniu_lv_currentprofile				= "Actual";
$meniu_lv_selectlang					= "Select language";
$meniu_lv_editprofile					= "Edit current";
$meniu_lv_filter                                        = "Filter";
//-------- new : START
$meniu_lv_refresh_active				= "Refresh is active";
$meniu_lv_refresh_not_active				= "Refresh is not active";
$meniu_lv_refresh_page					= "Refresh page every";
$meniu_lv_refresh_minutes				= "minutes.";
$meniu_lv_cronupdate_active				= "Cron update is active";
$meniu_lv_cronupdate_not_active				= "Cron update is not active";
$meniu_lv_cron_update					= "Update from cronjob.";
$meniu_lv_cronportcheck_active				= "Cron security check is active";
$meniu_lv_cronportcheck_not_active			= "Cron security check is not active";
$meniu_lv_cron_portcheck				= "Security check (portscan/DynDns check) from cronjob.";
$meniu_lv_disclosure_public				= "public disclosure";
$meniu_lv_disclosure_nonpublic				= "non public disclosure";
$meniu_lv_disclosure_private				= "private disclosure";
$meniu_lv_configuration					= "Configure settings";
$meniu_lv_reload_active					= "Reload on button is active";
$meniu_lv_reload_not_active				= "Reload on button is not active";
$meniu_lv_reload_on_button				= "Reload on button.";
$meniu_lv_note_active					= "Server notes are available";
$meniu_lv_note_not_active				= "Server notes are not available";
$meniu_lv_servernote					= "Server notes";
$meniu_lv_configurebutton				= "Configure";
$meniu_lv_globalsettings				= "Global settings";
$meniu_lv_editorsettings				= "Editor settings";
$meniu_lv_yapssettings					= "YaPS settings";
$meniu_lv_caidfiltersettings				= "CAId filter default settings";
$meniu_lv_notlocalcaidsettings				= "not local CAIds settings";
$meniu_lv_resetstatisticssettings			= "Reset statistics settings";
$meniu_lv_cronupdatesettings				= "Cron Update settings";
$meniu_lv_tagssettings					= "Tag settings";
$meniu_lv_portscansettings				= "Portscan settings";
$meniu_lv_webserversettings				= "Webserver settings";
$meniu_lv_select_settings				= "Select settings you want to configure";
//-------- new : END

//File: update.php
$update_lv_updatefailed					= "Update failed";
$update_lv_unabletoconnect				= "Unable to connect to";
$update_lv_servernotdefined				= "Server not defined in config.php";
$update_lv_nodata						= "no data";
$update_lv_updatetime					= "Update time";
$update_lv_updated						= "Updated";
$update_lv_error						= "error";
$update_lv_info							= "Info";
$update_lv_total						= "TOTAL";

//File: getconfigserver.php
$getconfigserver_lv_serverismandatory 	= "Server is mandatory (Host or IP)";
$getconfigserver_lv_portismandatory 	= "Port is mandatory if user and password are defined";
$getconfigserver_lv_userismandatory 	= "User is mandatory if password is defined";
$getconfigserver_lv_passismandatory 	= "Password is mandatory if user is defined";
$getconfigserver_lv_port 				= "Port";
$getconfigserver_lv_user 				= "User";
$getconfigserver_lv_pass 				= "Password";
$getconfigserver_lv_saveconfiguration 	= "Save configuration";
//-------- new : START
$getconfigserver_lv_web_credentials	= "Set CCcam Web Interface server, port, username and password";
$getconfigserver_lv_ftp_credentials	= "Set CCcam Server Ftp user and credentials";
$getconfigserver_lv_ftp_paths		= "Set CCcam Server Ftp file paths";
$getconfigserver_lv_ftpuser		= "Ftp Username";
$getconfigserver_lv_ftppass		= "Ftp Password";
$getconfigserver_lv_cccam_path		= "CCcam configuration path";
$getconfigserver_lv_key_path		= "Key files path";
$getconfigserver_lv_notice		= "Do not edit the config_userspecific.php file directly!";
$getconfigserver_lv_cfgpathismandatory	= "CCcam configuration path is mandatory if ftp user and ftp password are defined";
$getconfigserver_lv_keypathismandatory	= "CCcam key path is mandatory if ftp user and ftp password are defined";
$getconfigserver_lv_ftpuserismandatory	= "Ftp user is mandatory if ftp password is defined";
//-------- new : END

//File: sendmessage.php
$sendmessage_lv_from					= "From";
$sendmessage_lv_message					= "Message";
$sendmessage_lv_messagetoall			= "Send message to the all clients";
$sendmessage_lv_messagetoclients		= "Send message to the following client(s)";
$sendmessage_lv_to						= "To";
$sendmessage_lv_messageE1				= "Sending message to client, trying Enigma1 format";
$sendmessage_lv_errorE1					= "Error";
$sendmessage_lv_tryingE2				= "trying Enigma2 format";
$sendmessage_lv_messagesent				= "Message sent";
$sendmessage_lv_messagenotsent			= "Error! Message NOT sent";
$sendmessage_lv_messagesentwitherrors	= "Message sent with errors";

//File: client.php
$client_lv_offline						= "offline";
$client_lv_localprivateip				= "Local private IP";
$client_lv_cccamversion					= "CCcam Version";
$client_lv_ispinfo						= "ISP Info";
$client_lv_currentusage					= "Current Usage";
$client_lv_averageusage					= "Average Usage";
$client_lv_handledecm					= "Handled ECM ( this session )";
$client_lv_configuration				= "Client Message Configuration";
//-------- new : START
$client_lv_ecm_per_hour					= "ECM/hour";
$client_lv_cccam_webinterface				= "CCcam Web Interface";
//-------- new : END

//File: clientstats.php
$clientstats_lv_avu						= "AVU";
$clientstats_lv_usage					= "Usage";
$clientstats_lv_sendmessage				= "Send Message";
$clientstats_lv_messagetextempty		= "Message text is empty";
$clientstats_lv_messagetext				= "Message text";
$clientstats_lv_currentusage			= "Current Usage (ECM requests/h)";
$clientstats_lv_averageusage			= "Average Usage (ECM requests/h)";
$clientstats_lv_sendtoall				= "Send to ALL";
$clientstats_lv_send					= "Send";
$clientstats_lv_noportdefined			= "no port defined";
$clientstats_lv_fromfield				= "From";
$clientstats_lv_fromismandatory			= "From field is mandatory";
//-------- new : START
$clientstats_lv_offline_over_time_limit				= "Clients offline more than 4 weeks";
$clientstats_lv_last_seen_online			= "Last seen online";
$clientstats_lv_last_seen_online_ago			= "ago";
//-------- new : END

//File: node.php
$node_lv_nodedns						= "NodeDNS";

//File: common.php
$common_lv_pageloading					= "Page Loading Time";
$common_lv_pingverybad					= "very bad";
$common_lv_pingveryslow					= "very slow";
$common_lv_pingslow						= "slow";
$common_lv_pinggood						= "good";
$common_lv_pingverygood					= "very good";
$common_lv_pingexcellent				= "excellent";
$common_lv_notsaved						= "not saved";
$common_lv_weeks						= "weeks";
$common_lv_week							= "week";
$common_lv_days							= "days";
$common_lv_day							= "day";
$common_lv_hours						= "hours";
$common_lv_hour							= "hour";
$common_lv_mins							= "mins";
$common_lv_min							= "min";
$common_lv_secs							= "secs";
$common_lv_sec							= "sec";
$common_lv_yapsdatabasestatus					= "YaPS Database Details";
$common_lv_localdatabasestatus				= "Local YaPS Database Details";
$common_lv_yapsdatabaseversion				= "Database version";
$common_lv_yapsdatabaserows					= "Database rows";
$common_lv_yapspayserverhits					= "Payserver hits";
$common_lv_yapssecureconnection				= "Secure connection";
$common_lv_yapssecureenabled					= "enabled";
$common_lv_yapssecuredisabled					= "disabled";
$common_lv_localdatabaseversion				= "Database version (local copy)";
$common_lv_fileopenerror				= "Error opening file";
$common_lv_checkpermissions				= "Check permissions";
$common_lv_updatelocalcopyfirst			= "You should update your local copy of the Payserver Database prior to checking!";
//-------- new : START
$common_lv_ok						= "success";
$common_lv_not_ok					= "failed!";
$common_lv_no_files_in_dir				= "no files in directory!";
$common_lv_no_files_deleted				= "no files deleted!";
$common_lv_file_does_not_exist				= "(doesn't exist!)";
$common_lv_unknown_providerid				= "unknown ProviderID";
$common_lv_resetnodestats_title				= "Resetting Node Statistics for Server";
$common_lv_resetnodestats_title_statistic		= "Statistic";
$common_lv_resetnodestats_title_reset		= "Reset";
$common_lv_resetnodestats_title_files		= "Files";
$common_lv_resetnodestats_reset_yes 			= "yes";
$common_lv_resetnodestats_reset_no 			= "no";
$common_lv_fileopenreaderror				= "Can't open file for reading!";
$common_lv_fileopenwriteerror				= "Can't open file for writing!";
$common_lv_recent_portcheck_unavailable			= "No recent portcheck data available for this node!";
$common_lv_portcheck_no_nodes_available			= "No nodes available for portcheck/DynDns check!";
$common_lv_portcheck_done				= "Security check (portscan/DynDns check) finished.";
$common_lv_portcheck_summary				= "Security check (portscan/DynDns check) summary";
$common_lv_yapservice					= "YaPS";
$common_lv_yapsavailable				= "available";
//-------- new : END

//File: server.php
$server_lv_handledecm					= "Handled ECM";
$server_lv_handledecmsaved				= "Handled ECM ( saved )";
$server_lv_handledecmnow				= "Handled ECM ( now )";
$server_lv_nodeidserver					= "NodeID/Server (extra sources)";
$server_lv_ipclients					= "IP/Clients";
$server_lv_typever						= "Type/Version";
$server_lv_connected					= "Is Connected";
$server_lv_ispinfo						= "ISP Info";
$server_lv_lastpingerror				= "Very slow";
$server_lv_pingnow						= "PING NOW";
$server_lv_besteverresponse				= "Best ever responce time (ping)";
$server_lv_averageresponse				= "Average responce time (ping)";
$server_lv_currentresponse				= "Current responce time (ping)";
$server_lv_unresolvedip						= "Unresolved IP";
$server_lv_localprivateip					= "Local private IP";
$server_lv_save							= "Save";
$server_lv_reverse_lookup					= "Reverse DNS lookup";
$server_lv_scannow                                              = "SCAN NOW";
$server_lv_securitycheck                                = "Security Check (portscan/DynDns check)";
$server_lv_legendscan                                   = "Legend :";
$server_lv_legendscan_port                              = "Port";
$server_lv_legendscan_status                            = "Status";
$server_lv_legendscan_openport                          = "OPEN Port";
$server_lv_legendscan_closedport                        = "CLOSED Port";
$server_lv_scan_service                                 = "Service";
$server_lv_scan_port                                    = "Port";
$server_lv_scan_status                                  = "Status";
$server_lv_scan_legend                                  = "SHOW LEGEND";
//-------- new : START
$server_lv_cccam_webinterface				= "CCcam Web Interface";
$server_lv_cccam_webinterface_goto			= "GOTO";
$server_lv_cccam_no_webinterface			= "NOT AVAILABLE";
$server_lv_security_check_result			= "Recent security check (portscan/DynDns check) result";
$server_lv_cron_exclude				= "Exclude node from crond security check (portscan/DynDns check).";
$server_lv_recent_portcheck_result			= "Recent Security check (portscan) details";
$server_lv_shownow						= "SHOW NOW";
$server_lv_legendscan_unknownport			= "UNKNOWN Port";
$server_lv_securitycheck_portscan			= "Security Check (portscan)";
$server_lv_securitycheck_dyndns				= "Search DynDns address on Google";
$server_lv_dyndns_checknow				= "SEARCH NOW";
$server_lv_dyndns_check_result				= "Search DynDns address on Google result";
//-------- new : END

//File: serverstats.php
$serverstats_lv_serversconnected		= "Servers connected";
$serverstats_lv_rating					= "Rating";
$serverstats_lv_pingall					= "Ping ALL";
$serverstats_lv_lastseen				= "Last seen online";
$serverstats_lv_payservercheck				= "Check Nodes for Payserver";
$serverstats_lv_payserverchecknow			= "CHECK NOW";
$serverstats_lv_payserverupdate				= "Update local copy of Payserver Database";
$serverstats_lv_payserverupdatenow			= "UPDATE NOW";
$serverstats_lv_updatelocalcopyfirst			= "You should update your local copy of the Payserver Database prior to checking!";
$serverstats_lv_nopayserver			= "no Payserver";
$serverstats_lv_payserver			= "Payserver!";
$serverstats_lv_payserveryaps				= "YaPS";
$serverstats_lv_payserverprivate				= "private database";
$serverstats_lv_noupdateneeded				= "No update needed";
$serverstats_lv_yapsentriescopied			= "Payserver entries copied";
$serverstats_lv_yapsserviceoffline			= "YaPS not available! Using local copy instead!";
//-------- new : START
$serverstats_lv_notlocalinCCcam				= "not local in CCcam!";
$serverstats_lv_manualpayservercheck			= "Check manually entered DynDns address for Payserver";
$serverstats_lv_portscancheckall			= "Check security (portscan/DynDns check) for all Nodes";
$serverstats_lv_portscancheckallnow			= "CHECK NOW";
$serverstats_lv_portscancheckall_notice			=
"The time, the security check (portscan/DynDns check) will take for all nodes, depends on the number of configured server nodes. The security check (portscan/DynDns check) may take several minutes. Thus it is recommended to exclude server nodes from the security check (portscan/DynDns check) that are known to be secure. Each server node can be excluded seperately. This affects the manually initiated security check (portscan/DynDns check) and the crond security check (portscan/DynDns check), if configured.";
$serverstats_lv_excludeportcheckall			= "Exclude all Nodes for complete or crond security check (portscan/DynDns check)";
$serverstats_lv_excludeportcheckallnow			= "EXCLUDE ALL NOW";
$serverstats_lv_includeportcheckall			= "Include all Nodes for complete or crond security check (portscan/DynDns check)";
$serverstats_lv_includeportcheckallnow			= "INCLUDE ALL NOW";
$serverstats_lv_excludedportscancheckall_notice		= "All configured server nodes are excluded for complete or crond security check (portscan/DynDns check).";
$serverstats_lv_includedportscancheckall_notice		= "All configured server nodes are included for complete or crond security check (portscan/DynDns check), except local server nodes which are considered to be secure.";
$serverstats_lv_includeportscancheckall_notice		= "All configured server nodes will be included for complete or crond security check (portscan/DynDns check), except local server nodes which are considered to be secure.";
$serverstats_lv_excludeportscancheckall_notice		= "All configured server nodes will be excluded for complete or crond security check (portscan/DynDns check).";
$serverstats_lv_showportscancheckall			= "Show previous and actual security check results (portscan/DynDns check) for all Nodes";
$serverstats_lv_showportscancheckallnow			= "SHOW NOW";
$serverstats_lv_security_changed_to			= "changed to";
$serverstats_lv_security_status				= "Security status";
$serverstats_lv_security_status_changed			= "Security status changed";
$serverstats_lv_security_check_done			= "Security check (portscan/DynDns check) done.";
$serverstats_lv_knownbygooglechecknow			= "CHECK NOW";
$serverstats_lv_manualknownbygooglecheck		= "Check manually entered DynDns address if known by Google";
$serverstats_lv_dyndns_check_result			= "Search DynDns address on Google result";
$serverstats_lv_clearfilter				= "Clear display filter";
$serverstats_lv_clearfilternow				= "CLEAR NOW";
//-------- new : END

//File: providerstats.php
$providerstats_lv_ident					= "Ident";
$providerstats_lv_local					= "Local";
$providerstats_lv_usedproviderslist		= "Used Providers List";

//File: provider.php
$provider_lv_notfound					= "not found";
$provider_lv_used						= "Used";

//File: nodestats.php
$nodestats_lv_resharenodes				= "Reshare Nodes";
//-------- new : START
$nodestats_lv_notlocalinCCcam				= "not local in CCcam!";
//-------- new : END

//File: pairstats.php
$pairstats_lv_newpairfound				= "New pair found";
$pairstats_lv_clientswithnopair			= "Connected Clients with no pair";
$pairstats_lv_client					= "Client";
$pairstats_lv_noserver					= "no server";
//-------- new : START
$pairstats_lv_notlocalinCCcam				= "not local in CCcam!";
//-------- new : END

//File: pingAll.php
$pingall_lv_saved						= "Saved";
$pingall_lv_comment						= "Comment";
$pingall_lv_average						= "Average";

//File: entitlementstats.php
$entitlementstats_lv_cardreader			= "card reader";
$entitlementstats_lv_nocard				= "no or unknown card inserted ";

//File: editor.php
//-------- new : START
$editor_lv_open					= "Open";
$editor_lv_save					= "Save";
$editor_lv_save_recent_file			= "Save recent file";
/*
$editor_lv_info					= "Welcome to CCcam Editor!

Please be sure to define the appropriate ftp username, ftp password and the according paths
for CCcam configuration and key files before editing. This can be done under the \"server profile\" settings.

* C: Line CAId/ProviderID Filter
  This textarea contains predefined CAIds and ProviderIds to filter in C: Lines. The CAIds and ProviderIds
  can be defined under \"CAId filter default settings\". The predefined CAIds and ProviderIDs will be
  dynamically merged with the unused and/or Fake CAIds and ProviderIDs.

* F: Line CAId/ProviderID Filter
  This textarea contains predefined CAIds and ProviderIds to filter in F: Lines. The CAIds and ProviderIds
  can be defined statically under \"CAId filter default settings\".

* Textarea geometry
  You can change the textarea geometry under \"Editor settings\".

* lops.payserver (local payserver service)
  The lops.payserver file contains private payserver entries, which are used during payserver check
  independent from YaPS. This file is located in the CCcamInfoPHP folder.

Be careful with editing files!";
*/
$editor_lv_info                                 = "Welcome to CCcam Editor!

Please be sure to define the appropriate ftp username, ftp password and the according paths
for CCcam configuration and key files before editing. This can be done under the \"server profile\" settings.

* lops.payserver (local payserver service)
  The lops.payserver file contains private payserver entries, which are used during payserver check
  independent from YaPS. This file is located in the CCcamInfoPHP folder.

This editor is only a prerelease version. There are more functions to come!

Be careful with editing files!";
//-------- new : END
$editor_lv_clinefilter				= "C: Line CAId/ProviderID Filter";
$editor_lv_flinefilter                          = "F: Line CAId/ProviderID Filter";
$editor_lv_clinefilternotice		= "Add the text from the above Textarea to your C: Lines before the first closing paranthesis to filter unwanted CAIds, ProviderIDs.<br>You can predefine your own C: Line filter under global settings in addition to the automatically generated C: Line filter!";
$editor_lv_flinefilternotice		= "Add the text from the above Textarea to your F: Lines before the first closing paranthesis to filter unwanted CAIds, ProviderIDs.<br>You must define your own F: Line filter under global settings before using it!";
$editor_lv_no_file			= "no file!";
?>

