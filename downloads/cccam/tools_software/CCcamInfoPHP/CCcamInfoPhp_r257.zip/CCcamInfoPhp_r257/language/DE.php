<?php

$generic_lv_uptime						= "Laufzeit";
$generic_lv_clients						= "Clients";
$generic_lv_connectedclients			= "Verbundene Clients";
$generic_lv_activeclients				= "Aktive Clients";
$generic_lv_username					= "Benutzer";
$generic_lv_host						= "Land / IP";
$generic_lv_connected					= "Verbunden";
$generic_lv_idletime					= "Leerlaufzeit";
$generic_lv_version						= "Version";
$generic_lv_lastusedshare				= "Letzte benutzte Freigabe";
$generic_lv_ecmtime						= "ECM Zeit";
$generic_lv_nodeid						= "KnotenID";
$generic_lv_handled						= "Behandelt";
$generic_lv_servers						= "Server";
$generic_lv_shares						= "Freigaben";
$generic_lv_providers					= "Anbieter";
$generic_lv_entitlements				= "Berechtigungen";
$generic_lv_ago							= "vorher";
$generic_lv_server		 				= "Server";
$generic_lv_serverdown					= "Server ist nicht erreichbar oder wird aktualisiert... Bitte versuchen Sie es sp�ter nochmal";
$generic_lv_country						= "Land";
$generic_lv_type						= "Typ";
$generic_lv_reshare						= "Weitergabe";
$generic_lv_re							= "Weitergabe";
$generic_lv_noreshare					= "NEIN";
$generic_lv_yesreshare					= "JA";
$generic_lv_caidident					= "CAID/Ident";
$generic_lv_caididents					= "CAID/Idents";
$generic_lv_nodes						= "Knoten";
$generic_lv_note						= "Notiz";
$generic_lv_ping						= "Ping";
$generic_lv_recentecmhandled			= "Zuletzt behandelte ECM ";
$generic_lv_provider					= "CAId/Provider";
$generic_lv_caididentslocal				= "CAID/Idents LOKAL";
$generic_lv_offline						= "OFFLINE";
$generic_lv_notice                              = "Hinweis:";
$generic_lv_collexp1                            = "Mit ";
$generic_lv_collexp2                            = " Ansicht erweitern/verringern!";
$generic_lv_collexp				= "Ansicht erweitern/verringern!";
$generic_lv_most_activeclients				= "Meiste aktive Clients";
$generic_lv_memory				= "Speicher benutzt (aktuell/m�glich)";
$generic_lv_cccam_webif_link				= "Web Interface Link";
$generic_lv_define_cccam_webif_link			= "Definiere CCcam Web Interface Link";
$generic_lv_cccam_webif_available			= "Web Interface verf�gbar";
$generic_lv_cccam_webif_not_available			= "Web Interface nicht verf�gbar";
$generic_lv_cccam_webif_link_not_defined			= "Web Interface Link nicht definiert!";
$generic_lv_newcamd_webif_available			= "Web Interface verf�gbar";
$generic_lv_newcamd_webif_not_available			= "Web Interface nicht verf�gbar";
$generic_lv_newcamd_webif_link_not_defined			= "Web Interface Link nicht definiert!";
$generic_lv_define_newcs_webif_link			= "Definiere NewCS/OSCam/SBox Web Interface Link";
$generic_lv_newcs_webif_link				= "Web Interface Link";
$generic_lv_webif_link_status				= "Status";
$generic_lv_portsecurity_unknown			= "Sicherheit unbekannt";
$generic_lv_portsecurity_secure				= "Sicherheit sicher";
$generic_lv_portsecurity_moderate_secure		= "Sicherheit weitestgehend sicher";
$generic_lv_portsecurity_unsecure			= "Sicherheit unsicher";
$generic_lv_portsecurity_localip			= "lokale IP";
$generic_lv_warning_payserver				= "Payserver";
$generic_lv_no_language_specific_changelog		= "Sprachspezifisches Changelog ist nicht vorhanden. Das englische Changelog wird stattdessen angezeigt!";
$generic_lv_no_changelog				= "Changelog ist nicht vorhanden!";
$generic_lv_count					= "Anzahl";
$generic_lv_localip_secure				= "Lokale private IP Adressen sind per Definition sicher.";
$generic_lv_portscan_excluded			= "Keine Sicherheits�berpr�fung mittels Cronjob";
$generic_lv_portsecurity_excluded		= "Keine Sicherheits�berpr�fung mittels Cronjob f�r diesen Knoten";
$generic_lv_known_by_google			= "DynDns Adresse bei Google bekannt";
$generic_lv_portcheck_done				= "Sicherheits�berpr�fung durchgef�hrt";
$generic_lv_not_known_by_google				= "DynDns Adresse nicht bekannt bei Google";
$generic_lv_google_flood_protection                     = "Google Flooding Schutz aktiv, bitte sp�ter nochmal versuchen!";
$generic_lv_contact					= "Kontakt";

//File: index.php
$index_lv_currenttime					= "Jetzige Zeit";
$index_lv_totalhandledecm				= "Gesamt behandelte Client ECMs";
$index_lv_totalhandledemm				= "Gesamt behandelte Client EMMs";
$index_lv_totalhandledlocal				= "Gesamt behandelte LOKALE ECMs";
$index_lv_peakload						= "Spitzenlast";
$index_lv_ecmhandled					= "ECM behandelt";
$index_lv_providername					= "CAId/Provider Name";
$index_lv_recent						= "Zuletzt";
$index_lv_resetnodestats			= "Knoten Statistiken zur�cksetzen";
$index_lv_resetnodenow				= "ZUR�CKSETZEN jetzt";
$index_lv_resetstats				= "Alle Knoten Statistiken zur�cksetzen";
$index_lv_resetnow				= "ZUR�CKSETZEN jetzt";
$index_lv_resetnodestats_title			= "Knoten Statistiken zur�cksetzen f�r Server";
$index_lv_save					= "Sichern";
$index_lv_unknownsids                           = "Zuletzt angefragte unbekannte SIDs : ";
$index_lv_action_unknownsid                     = "Aktion";
$index_lv_delete_unknownsid                     = "L�schen";
$index_lv_found_unknownsid			= "gefunden";
$index_lv_knownsids				= "Aktuell angefragte bekannte SIDs : ";
$index_lv_newer_cccam_versions          = "Unbekannte/neuere CCcam Versionen : ";
$index_lv_newer_client_cccam_versions   = "Unbekannte/neuere Client CCcam Versionen";
$index_lv_newer_server_cccam_versions   = "Unbekannte/neuere Server CCcam Versionen";
$index_lv_delete_all_unknownsid		= "L�sche alle vorher entdeckten unbekannten SIDs";

//File: menuiu.php
$meniu_lv_lang							= "Sprache: Deutsch";
$meniu_lv_home							= "Index";
$meniu_lv_pairs							= "Paare";
$meniu_lv_updatebutton					= "Aktualisieren";
$meniu_lv_updatetimes					= "Aktualisierungszeiten";
$meniu_lv_areyousure					= "Sind Sie sicher?";
$meniu_lv_lastupdate					= "Letzte Aktualisierung";
$meniu_lv_selectactiveprofile			= "Aktives Profil w�hlen oder";
$meniu_lv_new							= "Neu";
$meniu_lv_definenewprofile				= "anklicken, um ein neues Profil zu definieren";
$meniu_lv_deleteprofile					= "L�schen";
$meniu_lv_currentprofile				= "Aktuell";
$meniu_lv_selectlang					= "Sprache ausw�hlen";
$meniu_lv_editprofile					= "Aktuelles bearbeiten";
$meniu_lv_filter					= "Filter";
$meniu_lv_refresh_active				= "Neuladen der Seite ist aktiv";
$meniu_lv_refresh_not_active				= "Neuladen der Seite ist nicht aktiv";
$meniu_lv_refresh_page					= "Neuladen der Seite alle";
$meniu_lv_refresh_minutes				= "Minuten.";
$meniu_lv_cronupdate_active				= "Cron Aktualisierung ist aktiv";
$meniu_lv_cronupdate_not_active				= "Cron Aktualisierung ist nicht aktiv";
$meniu_lv_cron_update					= "Aktualisierung mittels Cronjob.";
$meniu_lv_cronportcheck_active				= "Cron Sicherheits�berpr�fung ist aktiv";
$meniu_lv_cronportcheck_not_active			= "Cron Sicherheits�berpr�fung ist nicht aktiv";
$meniu_lv_cron_portcheck				= "Sicherheits�berpr�fung (portscan/DynDns Check) mittels Cronjob.";
$meniu_lv_disclosure_public                             = "public Vertraulichkeit";
$meniu_lv_disclosure_nonpublic                          = "non public Vertraulichkeit";
$meniu_lv_disclosure_private                            = "private Vertraulichkeit";
$meniu_lv_configuration					= "Konfiguriere Einstellungen";
$meniu_lv_reload_active					= "Aktualisierung �ber Button ist aktiv";
$meniu_lv_reload_not_active				= "Aktualisierung �ber Button ist nicht aktiv";
$meniu_lv_reload_on_button				= "Aktualisierung �ber Button.";
$meniu_lv_note_active					= "Server Notizen sind vorhanden";
$meniu_lv_note_not_active				= "Server Notizen sind nicht verhanden";
$meniu_lv_servernote					= "Server Notizen";
$meniu_lv_configurebutton				= "Konfiguriere";
$meniu_lv_globalsettings				= "Globale Einstellungen";
$meniu_lv_editorsettings				= "Editor Einstellungen";
$meniu_lv_yapssettings					= "YaPS Einstellungen";
$meniu_lv_caidfiltersettings				= "CAId Filter Standard Einstellungen";
$meniu_lv_notlocalcaidsettings				= "nicht lokale CAIds Einstellungen";
$meniu_lv_resetstatisticssettings			= "Statistiken zur�cksetzen Einstellungen";
$meniu_lv_cronupdatesettings				= "Cron Aktualisierung Einstellungen";
$meniu_lv_tagssettings					= "Tag Einstellungen";
$meniu_lv_portscansettings				= "Portscan Einstellungen";
$meniu_lv_webserversettings				= "Webserver Einstellungen";
$meniu_lv_select_settings				= "W�hle zu �ndernde Einstellungen";

//File: update.php
$update_lv_updatefailed					= "Aktualisierung fehlgeschlagen";
$update_lv_unabletoconnect				= "Keine Verbindung zur";
$update_lv_servernotdefined				= "Server nicht definiert im config.php";
$update_lv_nodata						= "keine Datei";
$update_lv_updatetime					= "Aktualisierungszeit";
$update_lv_updated						= "Aktualisierung";
$update_lv_error						= "Fehler";
$update_lv_info							= "Info";
$update_lv_total						= "TOTAL";

//File: getconfigserver.php
$getconfigserver_lv_serverismandatory 	= "Servereintrag ist Pflicht (Host oder IP)";
$getconfigserver_lv_portismandatory 	= "Porteintrag ist Pflicht wenn Benutzer und Kennwort definiert sind";
$getconfigserver_lv_userismandatory 	= "Benutzereintrag ist Pflicht wenn Kennwort definiert ist";
$getconfigserver_lv_passismandatory 	= "Kennwort ist Pflicht wenn Benutzer definiert ist";
$getconfigserver_lv_port 				= "Port";
$getconfigserver_lv_user 				= "Benutzername";
$getconfigserver_lv_pass 				= "Kennwort";
$getconfigserver_lv_saveconfiguration 	= "Konfiguration speichern";
$getconfigserver_lv_web_credentials	= "CCcam Web Interface Server, Port, Benutzername und Passwort";
$getconfigserver_lv_ftp_credentials	= "CCcam Server Ftp Benutzerkennung";
$getconfigserver_lv_ftp_paths		= "CCcam Server Ftp Pfad";
$getconfigserver_lv_ftpuser		= "Ftp Benutzername";
$getconfigserver_lv_ftppass		= "Ftp Passwort";
$getconfigserver_lv_cccam_path		= "Pfad CCcam Konfigurationen";
$getconfigserver_lv_key_path		= "Pfad Key Dateien";
$getconfigserver_lv_notice		= "Die Datei config_userspecific.php sollte nicht direkt editiert werden!";
$getconfigserver_lv_cfgpathismandatory	= "Eingabe des Pfads zu den CCcam Konfigurationsdateien ist Pflicht, wenn Ftp Benutzer und Ftp Kennwort definiert sind";
$getconfigserver_lv_keypathismandatory	= "Eingabe des Pfads zu den CCcam Key Dateien ist Pflicht, wenn Ftp Benutzer und Ftp Kennwort definiert sind";
$getconfigserver_lv_ftpuserismandatory	= "Ftp Benutzereintrag ist Pflicht, wenn Ftp Kennwort definiert ist";

//File: sendmessage.php
$sendmessage_lv_from					= "Von";
$sendmessage_lv_message					= "Nachricht";
$sendmessage_lv_messagetoall			= "Nachricht zu alle Clients senden";
$sendmessage_lv_messagetoclients		= "Nachricht zu folgende client(s) senden";
$sendmessage_lv_to						= "An";
$sendmessage_lv_messageE1				= "Es wird versucht eine Nachricht zum Client zu senden mit Enigma1 Format";
$sendmessage_lv_errorE1					= "Fehler";
$sendmessage_lv_tryingE2				= "Versuch mit Enigma2 Format";
$sendmessage_lv_messagesent				= "Nachricht �bermittelt";
$sendmessage_lv_messagenotsent			= "Fehler! Nachricht wurde nicht �bermittelt";
$sendmessage_lv_messagesentwitherrors	= "Nachricht wurde mit Fehlern �bermittelt";

//File: client.php
$client_lv_offline						= "offline";
$client_lv_localprivateip				= "Lokale private IP";
$client_lv_cccamversion					= "CCcam Version";
$client_lv_ispinfo						= "Internet Anbieter Info";
$client_lv_currentusage					= "Laufende Benutzung";
$client_lv_averageusage					= "Durchschnittliche Benutzung";
$client_lv_handledecm					= "Behandelte ECM ( laufende Sitzung )";
$client_lv_configuration				= "Client-Konfiguration Nachricht";
$client_lv_ecm_per_hour					= "ECM/Stunde";
$client_lv_cccam_webinterface				= "CCcam Web Interface";

//File: clientstats.php
$clientstats_lv_avu						= "AVU";
$clientstats_lv_usage					= "Benutzung";
$clientstats_lv_sendmessage				= "Nachricht senden";
$clientstats_lv_messagetextempty		= "Nachricht Text ist leer";
$clientstats_lv_messagetext				= "Nachricht Text";
$clientstats_lv_currentusage			= "Laufende Benutzung (ECM Anforderungen/Stunde)";
$clientstats_lv_averageusage			= "Durchschnittliche Benutzung (ECM Anforderungen/Stunde)";
$clientstats_lv_sendtoall				= "An alle senden";
$clientstats_lv_send					= "Senden";
$clientstats_lv_noportdefined			= "Kein Port definiert";
$clientstats_lv_fromfield				= "Absender";
$clientstats_lv_fromismandatory			= "Absender obligatorisch";
$clientstats_lv_offline_over_time_limit                         = "Clients offline mehr als 4 Wochen";
$clientstats_lv_last_seen_online			= "Zuletzt online gesehen";
$clientstats_lv_last_seen_online_ago			= "vorher";

//File: node.php
$node_lv_nodedns						= "KnotenDNS";

//File: common.php
$common_lv_pageloading					= "Seitenaufbau Zeit";
$common_lv_pingverybad					= "Sehr schlecht";
$common_lv_pingveryslow					= "Sehr langsam";
$common_lv_pingslow						= "Langsam";
$common_lv_pinggood						= "Gut";
$common_lv_pingverygood					= "Sehr gut";
$common_lv_pingexcellent				= "Ausgezeichnet";
$common_lv_notsaved						= "nicht gespeichert";
$common_lv_weeks						= "Wochen";
$common_lv_week							= "Woche";
$common_lv_days							= "Tage";
$common_lv_day							= "Tag";
$common_lv_hours						= "Stunden";
$common_lv_hour							= "Stunde";
$common_lv_mins							= "Minuten";
$common_lv_min							= "Minute";
$common_lv_secs							= "Sekunden";
$common_lv_sec							= "Sekunde";
$common_lv_yapsdatabasestatus					= "YaPS Datenbank Details";
$common_lv_localdatabasestatus				= "Lokale YaPS Datenbank Details";
$common_lv_yapsdatabaseversion				= "Datenbank Version";
$common_lv_yapsdatabaserows					= "Datenbank Eintr�ge";
$common_lv_yapspayserverhits					= "Payserver Treffer";
$common_lv_yapssecureconnection				= "Sichere Verbindung";
$common_lv_yapssecureenabled					= "aktiviert";
$common_lv_yapssecuredisabled					= "deaktiviert";
$common_lv_localdatabaseversion				= "Datenbank Version (lokale Kopie)";
$common_lv_fileopenerror                              = "Fehler beim �ffnen der Datei";
$common_lv_checkpermissions                            = "Dateirechte �berpr�fen";
$common_lv_updatelocalcopyfirst                      = "Vor dem �berpr�fen erst die lokale Kopie der Payserver Datenbank aktualisieren!";
$common_lv_ok						= "erfolgreich";
$common_lv_not_ok					= "fehlgeschlagen!";
$common_lv_no_files_in_dir				= "keine Dateien im Verzeichnis!";
$common_lv_no_files_deleted				= "keine Dateien gel�scht!";
$common_lv_file_does_not_exist				= "(existiert nicht!)";
$common_lv_unknown_providerid				= "unbekannte ProviderID";
$common_lv_resetnodestats_title			= "Knoten Statistiken zur�cksetzen f�r Server";
$common_lv_resetnodestats_title_statistic		= "Statistik";
$common_lv_resetnodestats_title_reset		= "Zur�cksetzen";
$common_lv_resetnodestats_title_files		= "Dateien";
$common_lv_resetnodestats_reset_yes			= "ja";
$common_lv_resetnodestats_reset_no			= "nein";
$common_lv_fileopenreaderror				= "Datei kann nicht zum Lesen ge�ffnet werden!";
$common_lv_fileopenwriteerror				= "Datei kann nicht zum Schreiben ge�ffnet werden!";
$common_lv_recent_portcheck_unavailable			= "Keine Ergebnisse der letzten Sicherheits�berpr�fung (Portscan/DynDns Check) f�r diesen Knoten verf�gbar!";
$common_lv_portcheck_no_nodes_available			= "Keine Knoten vorhanden f�r die Sicherheits�berpr�fung (Portscan/DynDns Check)!";
$common_lv_portcheck_done				= "Sicherheits�berpr�fung (Portscan/DynDns Check) abgeschlossen.";
$common_lv_portcheck_summary				= "Sicherheits�berpr�fung (Portscan/DynDns Check) Zusammenfassung";
$common_lv_yapservice                                   = "YaPS";
$common_lv_yapsavailable                                = "verf�gbar";

//File: server.php
$server_lv_handledecm					= "Behandelte ECM";
$server_lv_handledecmsaved				= "Behandelte ECM ( gespeichert )";
$server_lv_handledecmnow				= "Behandelte ECM ( jetzt )";
$server_lv_nodeidserver					= "KnotenID/Server (extra Quellen)";
$server_lv_ipclients					= "IP/Clients";
$server_lv_typever						= "Typ/Version";
$server_lv_connected					= "Ist verbunden";
$server_lv_ispinfo						= "Internetanbieter Info";
$server_lv_lastpingerror				= "Sehr langsam";
$server_lv_pingnow						= "PING jetzt";
$server_lv_besteverresponse				= "Historisch beste Antwortzeit (ping)";
$server_lv_averageresponse				= "Durchschnitt Antwortzeit (ping)";
$server_lv_currentresponse				= "Antwortzeit (ping)";
$server_lv_unresolvedip						= "Nicht aufl�sbare IP";
$server_lv_localprivateip					= "Lokale private IP";
$server_lv_save							= "Speichern";
$server_lv_reverse_lookup					= "Reverse DNS Aufl�sung";
$server_lv_scannow                                              = "PR�FE jetzt";
$server_lv_securitycheck                                = "Sicherheits�berpr�fung (portscan/DynDns Check)";
$server_lv_legendscan                                   = "Legende :";
$server_lv_legendscan_port                              = "Port";
$server_lv_legendscan_status                            = "Status";
$server_lv_legendscan_openport                          = "OFFENER Port";
$server_lv_legendscan_closedport                        = "GESCHLOSSENER Port";
$server_lv_scan_service                                 = "Dienst";
$server_lv_scan_port                                    = "Port";
$server_lv_scan_status                                  = "Status";
$server_lv_scan_legend                                  = "LEGENDE anzeigen";
$server_lv_cccam_webinterface				= "CCcam Web Interface";
$server_lv_cccam_webinterface_goto			= "GEHE ZU";
$server_lv_cccam_no_webinterface			= "NICHT VERF�GBAR";
$server_lv_security_check_result				= "Letztes Ergebnis der Sicherheits�berpr�fung (Portscan/DynDns Check)";
$server_lv_cron_exclude                         = "Knoten bei der Sicherheits�berpr�fung (Portscan/DynDns Check) mittels Crond auslassen.";
$server_lv_recent_portcheck_result			= "Letztes Ergebnis der Sicherheits�berpr�fung (Portscan) Details";
$server_lv_shownow						= "ZEIGE jetzt";
$server_lv_legendscan_unknownport			= "UNBEKANNTER Port";
$server_lv_securitycheck_portscan			= "Sicherheits�berpr�fung (portscan)";
$server_lv_securitycheck_dyndns				= "Suche DynDns Adresse bei Google";
$server_lv_dyndns_checknow				= "SUCHE jetzt";
$server_lv_dyndns_check_result				= "Ergebnis der DynDns Adresssuche bei Google";

//File: serverstats.php
$serverstats_lv_serversconnected		= "Server verbunden";
$serverstats_lv_rating					= "Rang";
$serverstats_lv_pingall					= "Ping alle";
$serverstats_lv_lastseen				= "Zuletzt online";
$serverstats_lv_payservercheck                               = "Pr�fe Knoten auf Payserver";
$serverstats_lv_payserverchecknow                            = "PR�FE jetzt";
$serverstats_lv_payserverupdate                               = "Aktualisiere lokale Kopie der Payserver Datenbank";
$serverstats_lv_payserverupdatenow                            = "AKTUALISIERE jetzt";
$serverstats_lv_updatelocalcopyfirst			= "Vor dem �berpr�fen erst die lokale Kopie der Payserver Datenbank aktualisieren!";
$serverstats_lv_nopayserver                     = "kein Payserver";
$serverstats_lv_payserver                       = "Payserver!";
$serverstats_lv_payserveryaps                           = "YaPS";
$serverstats_lv_payserverprivate                                = "private Datenbank";
$serverstats_lv_noupdateneeded                          = "Aktualisierung nicht notwendig";
$serverstats_lv_yapsentriescopied                       = "Payserver Eintr�ge kopiert";
$serverstats_lv_yapsserviceoffline			= "YaPS nicht verf�gbar! Verwende stattdessen lokale YaPS Datenbank!";
$serverstats_lv_notlocalinCCcam				= "nicht lokal in CCcam!";
$serverstats_lv_manualpayservercheck			= "Pr�fe DynDns Adresse auf Payserver";
$serverstats_lv_portscancheckall			= "Pr�fe Sicherheit (Portscan/DynDns Check) f�r alle Knoten";
$serverstats_lv_portscancheckallnow			= "PR�FE jetzt";
$serverstats_lv_portscancheckall_notice			= 
"Die Zeit, die die Sicherheits�berp�fung (Portscan/DynDns Check) f�r alle Knoten ben�tigt, h�ngt von der Anzahl der konfigurierten Server Knoten ab. Die Sicherheits�berp�fung (Portscan/DynDns Check) kann mehrere Minuten dauern. Aus diesem Grund wird empfohlen, Knoten, die als sicher bekannt sind, von der Sicherheits�berp�fung (Portscan/DynDns Check) auszuschliessen. Jeder Server Knoten kann einzeln ausgeschlossen werden. Das betrifft die manuell gestartete Sicherheits�berp�fung (Portscan/DynDns Check) �ber alle Server Knoten, als auch die crond Sicherheits�berp�fung (Portscan/DynDns Check) �ber alle Knoten, sofern konfiguriert.";
$serverstats_lv_excludeportcheckall			= "Alle Knoten von der kompletten oder crond Sicherheits�berp�fung (Portscan/DynDns Check) ausschliessen";
$serverstats_lv_excludeportcheckallnow			= "AUSSCHLIESSEN jetzt";
$serverstats_lv_includeportcheckall			= "Alle Knoten von der kompletten oder crond Sicherheits�berp�fung (Portscan/DynDns Check) ausschliessen";
$serverstats_lv_includeportcheckallnow			= "EINSCHLIESSEN jetzt";
$serverstats_lv_excludedportscancheckall_notice		= "Alle konfigurierten Server Knoten werden von der kompletten oder crond Sicherheits�berp�fung (Portscan/DynDns Check) ausgenommen.";
$serverstats_lv_includedportscancheckall_notice		= "Alle Server Knoten werden in die komplette oder crond Sicherheits�berp�fung (Portscan/DynDns Check) aufgenommen, ausser den lokalen Server Knoten, die per Definition als sicher gelten.";
$serverstats_lv_includeportscancheckall_notice		= "Alle Server Knoten werden in die komplette oder crond Sicherheits�berp�fung (Portscan/DynDns Check) aufgenommen, ausser den lokalen Server Knoten, die per Definition als sicher gelten.";
$serverstats_lv_excludeportscancheckall_notice		= "Alle konfigurierten Server Knoten werden von der kompletten oder crond Sicherheits�berp�fung (Portscan/DynDns Check) ausgenommen.";
$serverstats_lv_showportscancheckall			= "Zeige die vorherigen und aktuellen Ergebnisse der Sicherheits�berpr�fung (Portscan/DynDns Check) f�r alle Knoten";
$serverstats_lv_showportscancheckallnow			= "ZEIGE jetzt";
$serverstats_lv_security_changed_to			= "ge�ndert in";
$serverstats_lv_security_status                         = "Sicherheitsstatus";
$serverstats_lv_security_status_changed                 = "Sicherheitsstatus ge�ndert";
$serverstats_lv_security_check_done                     = "Sicherheits�berpr�fung (Portscan/DynDns Check) durchgef�hrt.";
$serverstats_lv_knownbygooglechecknow			= "PR�FE jetzt";
$serverstats_lv_manualknownbygooglecheck                = "Pr�fe, ob DynDns Adresse bei Google bekannt ist";
$serverstats_lv_dyndns_check_result			= "Ergebnis der DynDns Adresssuche bei Google";
$serverstats_lv_clearfilter				= "Anzeige Filter l�schen";
$serverstats_lv_clearfilternow				= "L�SCHE jetzt";

//File: providerstats.php
$providerstats_lv_ident					= "Ident";
$providerstats_lv_local					= "Lokale";
$providerstats_lv_usedproviderslist		= "Benutzte Anbieterliste";

//File: provider.php
$provider_lv_notfound					= "nicht gefunden";
$provider_lv_used						= "benutzt";

//File: nodestats.php
$nodestats_lv_resharenodes				= "Weitergabe Knoten";
$nodestats_lv_notlocalinCCcam				= "nicht lokal in CCcam!";

//File: pairstats.php
$pairstats_lv_newpairfound				= "Neues Paar gefunden";
$pairstats_lv_clientswithnopair			= "Verbundene Clients ohne Server";
$pairstats_lv_client					= "Client";
$pairstats_lv_noserver					= "kein Server";
$pairstats_lv_notlocalinCCcam				= "nicht lokal in CCcam!";

//File: pingAll.php
$pingall_lv_saved						= "Gespeichert";
$pingall_lv_comment						= "Kommentar";
$pingall_lv_average						= "Durchschnitt";

//File: entitlementstats.php
$entitlementstats_lv_cardreader 		= "Kartenleser";
$entitlementstats_lv_nocard 			= "Keine oder unbekannte Karte eingesteckt ";

//File: editor.php
$editor_lv_open                                 = "�ffnen";
$editor_lv_save                                 = "Sichern";
$editor_lv_save_recent_file                     = "Sichere letzte Datei";
/*
$editor_lv_info                                 = "Willkommen zum CCcam Editor!

Vor Benutzung des Editor m�ssen der ftp Benutzername, das ftp Password und die entsprechenden Pfade f�r die
CCcam Konfigurations- und Keydateien eingestellt werden. Die Einstellungen k�nnen unter den Einstellungen
zu dem jeweiligen \"Server Profil\" hinterlegt werden.

* C: Line CAId/ProviderID Filter
  Dieses Textfeld beinhaltet vordefinierte CAIds und ProviderIds, die in den C: Lines gefiltert werden
  sollen. Die CAIds und ProviderIds k�nnen unter \"CAId Filter Standardeinstellungen\" vorgegeben werden.
  Die vordefinierten CAIds und ProviderIDs werden dann dynamisch mit den unbenutzten und/oder FAKE
  CAIds und ProviderIDs erg�nzt.

* F: Line CAId/ProviderID Filter
  Dieses Textfeld beinhaltet vordefinierte CAIds und ProviderIds, die in den F: Lines gefiltert werden
  sollen. Die CAIds und ProviderIds k�nnen unter \"CAId Filter Standardeinstellungen\" vorgegeben werden.

* Textfeld Gr��e
  Die Textfeld Gr��e des Editors kann unter den \"Editor Einstellungen\" ge�ndert werden.

* lops.payserver (local payserver service)
  Die lops.payserver Datei beinhaltet selbst definierte private Payserver Eintr�ge, die zus�tzlich bei
  einer Payserver �berpr�fung zu der YaPS Datenbank �berpr�ft werden. Die Datei befindet sich im
  CCcamInfoPHP Verzeichnis.

Geht mit der notwendigen Sorgfalt ans Bearbeiten der Dateien!";
*/
$editor_lv_info                                 = "Willkommen zum CCcam Editor!

Vor Benutzung des Editor m�ssen der ftp Benutzername, das ftp Password und die entsprechenden Pfade f�r die
CCcam Konfigurations- und Keydateien eingestellt werden. Die Einstellungen k�nnen unter den Einstellungen
zu dem jeweiligen \"Server Profil\" hinterlegt werden.

* lops.payserver (local payserver service)
  Die lops.payserver Datei beinhaltet selbst definierte private Payserver Eintr�ge, die zus�tzlich bei
  einer Payserver �berpr�fung zu der YaPS Datenbank �berpr�ft werden. Die Datei befindet sich im
  CCcamInfoPHP Verzeichnis.

Dieser Editor ist nur eine Vorabversion. Es wird noch weitere Funktionen im Editor geben!

Geht mit der notwendigen Sorgfalt ans Bearbeiten der Dateien!";

$editor_lv_clinefilter                          = "C: Line CAId/ProviderID Filter";
$editor_lv_flinefilter                          = "F: Line CAId/ProviderID Filter";
$editor_lv_clinefilternotice            = "F�gt den Text aus dem obigen Textfeld in Euren C: Lines vor der ersten schlie�enden geschweiften Klammer ein, um unerw�nschte CAIds, ProviderIDs zu filtern.<br>Ein eigener C: Line Filter kann unter \"Globale Einstellungen\" zus�tzlich zu dem automatisch generierten C: Line Filter definiert werden!";
$editor_lv_flinefilternotice            = "F�gt den Text aus dem obigen Textfeld in Euren F: Lines vor der ersten schlie�enden geschweiften Klammer ein, um unerw�nschte CAIds, ProviderIDs zu filtern.<br>Ein eigener C: Line Filter kann unter \"Globale Einstellungen\" zus�tzlich zu dem automatisch generierten F: Line Filter definiert werden! Definiert den F: Line Filter<br>vor der ersten Benutzung der Funktion!";
$editor_lv_no_file			= "keine Datei!";
?>
