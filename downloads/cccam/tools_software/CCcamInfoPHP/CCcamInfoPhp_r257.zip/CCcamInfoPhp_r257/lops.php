<?php
//-------------------------------------
// LOPS - Local Payserver Service
//-------------------------------------

define('LOPS',"lops.php");

//-------------------------------------
// FUNCTIONS
//-------------------------------------

//___________________________________________________________________________________________________
function LoPSCheck($peer, $database, $server)
{
   $isPayServer = false;

   return $isPayServer;
}
//___________________________________________________________________________________________________
function LoPSInfo($mode, $database, $server=NULL, $lversion=NULL)
{
   // if no database exists return version 0
   if(!file_exists($database)) return 0;

   // load database
   $xml = simplexml_load_file($database);

   switch($mode)
   {
      case "rows" :                                                     // database rows
      break;

      case "dbver" :                                                    // database version
      break;

      case "date" :                                                     // database human readable version
      break;

      case "needupdate" :                                               // check if YaPS needs to be updated
      break;

      case "update" :                                                   // print update text
      break;
   }

   // purge arrays
   if(isset($result)) unset($result);
   if(isset($rversion)) unset($rversion);
   if(isset($lversion)) unset($lversion);

   // output result
   return $output;
}

?>
