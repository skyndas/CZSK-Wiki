<?php include "common.php"?>

<html>
<link type="text/css" href="javascript/jquery.ui.all.css" rel="stylesheet" />
<script type="text/javascript" src="javascript/jquery-1.4.2.js"></script>
<script type="text/javascript" src="javascript/ui/jquery.ui.core.js"></script>
<script type="text/javascript" src="javascript/ui/jquery.ui.widget.js"></script>
<script type="text/javascript" src="javascript/ui/jquery.ui.mouse.js"></script>
<script type="text/javascript" src="javascript/ui/jquery.ui.resizable.js"></script>
<head>

</head>

<BODY>

<style type="text/css">	
    .ui-resizable-se {
        bottom: 17px;
	}
</style>

<script language=javascript> 
function OpenFile(file)
{
    location.href = "editor.php?" + file;
}
function SaveFile(file)
{
    location.href = "editor.php?" + file + "&save";
}
</script>

<script type=text/javascript>
$(function() {
    $("#resizable").resizable({
         handles: "se"
    });
});
</script>

<?php

   if (!$update_from_button  && $use_reload_on_button && isReloadActive())
   {
      $update_info = true;
      $update_servers = true;
      $update_activeclients = true;
   }

   include "meniu.php";

   // init variables
   $CCcam_cfg = "CCcam.cfg";
   $CCcam_prio = "CCcam.prio";
   $CCcam_providers = "CCcam.providers";
   $CCcam_channelinfo = "CCcam.channelinfo";
   $CCcam_private_payserver = $lops["db"];

   $cccam_configuration_path = $CCCamWebInfo[$active_profie][4];
   $cccam_key_path = $CCCamWebInfo[$active_profie][5];
   $ftpuser = $CCCamWebInfo[$active_profie][6];
   $ftppassword = $CCCamWebInfo[$active_profie][7];

   if(isset($_POST['Save']))
   {		
      $data_config = $_POST['config'];
      $data_repl = str_replace("\\", "", $data_config);

      if($_SERVER['QUERY_STRING'] == $CCcam_cfg."&save")
      {
         $file = "ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."//".$CCcam_cfg;
      }

      if($_SERVER['QUERY_STRING'] == $CCcam_channelinfo."&save")
      {
         $file = "ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."//".$CCcam_channelinfo;
      }

      if($_SERVER['QUERY_STRING'] == $CCcam_prio."&save")
      {
         $file = "ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."//".$CCcam_prio;
      }

      if($_SERVER['QUERY_STRING'] == $CCcam_providers."&save")
      {
         $file = "ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."//".$CCcam_providers;
      }

      if($_SERVER['QUERY_STRING'] == $CCcam_private_payserver."&save")
      {
         $file = $CCcam_private_payserver;
      }

      if(file_exists($file))
      {
         unlink($file);
      }

      if (!$file_handle = fopen($file,"w"))
      {
         echo "<h5>Error opening file $file_np. Check permissions.\n</h5>";
      }

      if (!fwrite($file_handle, $data_repl))
      {
         echo "<h5>Error writing file $file_np. Check permissions.\n</h5>";
      }  
      fclose($file);
   }

   echo "<table width=\"550\">";
   echo "<tr>";
   echo "<td colspan='2' align='left'><font size='4'><b>CCcam EDITOR</b></font>";
   echo "</td>";

   if ($use_caidfilter)
   {
      echo "<td>";
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['CLINESIDFILTER']."\");' style='cursor:hand;'><FONT COLOR=white>".$editor_lv_clinefilter."</FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
      echo "</td>";
      echo "<td>";
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['FLINESIDFILTER']."\");' style='cursor:hand;'><FONT COLOR=white>".$editor_lv_flinefilter."</FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
      echo "</td>";
   }
   echo "</tr></table>";

   if ($use_caidfilter)
   {
      echo "<table id=\"".$idtable['CLINESIDFILTER']."\" style='display:none;' border=0 cellpadding=0 cellspacing=1>";
      echo "<tr><td>";
      echo "<br><FONT COLOR=white><b>".$editor_lv_clinefilter."</b></FONT><br>";
      if ($pagina_secure != "")
         $url = "https";
      else
         $url = "http";
      $url .= "://127.0.0.1/CCcamInfoPHP/providerstats.php";

      /* debug information
      echo $url;
      */

      $htm = file_get_contents($url);
      $pat = "";
      for ($i=0;$i<count($caidfilterpattern);$i++)
      {
         if ($i>0) $pat = $pat.'|';
         $pat=$pat.'providerstats.php\?provider='.$caidfilterpattern[$i];
      }
      $mat=preg_match_all ('/'.$pat.'/is', $htm, $match);
      echo "<textarea readonly class='TEXTAREANORMAL' cols=$caidfiltergeometry[1] name='filterProvider' rows=$caidfiltergeometry[0]>";
      $out="";
      for ($i=0;$i<$mat;$i++)
      {
         $len0=strlen($match[0][$i]);
         $len1=stripos($match[0][$i],'=');
         $len2=stripos($match[0][$i],'>');
         $fin=substr($match[0][$i],($len1-$len0+1),($len2-$len1-1));
         echo (',');
         echo($fin);
      }
      echo "</textarea>";

      echo "<br><br>";
      showNotice($editor_lv_clinefilternotice);
      echo "<br>";

//    echo "<script>setFocus();</script>";

      echo "<hr></hr>";
      echo "</td></tr>";
      echo "</table>";

      echo "<table id=\"".$idtable['FLINESIDFILTER']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
      echo "<tr><td>";
      echo "<br><FONT COLOR=white><b>".$editor_lv_flinefilter."</b></FONT><br>";
      echo "<textarea readonly class='TEXTAREANORMAL' cols=$caidfiltergeometry[1] name='filterProvider' rows=$caidfiltergeometry[0]>";
      echo "</textarea>";

      echo "<br><br>";
      showNotice($editor_lv_flinefilternotice);
      echo "<br>";

//    echo "<script>setFocus();</script>";

      echo "<hr></hr>";
      echo "</td></tr>";
      echo "</table>";
   }

   echo "<form name='form1' method='POST' enctype='text/multinorm' action='".$PHP_SELF."?".$_SERVER['QUERY_STRING']."&save' >" ;
// --------- BUTTONS BEGIN
   echo "<table width=\"550\">";
   echo "<tr>";
   echo "<td>".$editor_lv_open.":</td>";
   echo "<td><input type='button' name='cccamconfig' value='CCcam.cfg' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"OpenFile('CCcam.cfg')\"></td>";
   echo "<td><input type='button' name='cccamprio' value='CCcam.prio' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"OpenFile('CCcam.prio')\"></td>";
   echo "<td><input type='button' name='cccamchannelinfo' value='CCcam.channelinfo' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"OpenFile('CCcam.channelinfo')\"></td>";
   echo "<td><input type='button' name='cccamproviders' value='CCcam.providers' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"OpenFile('CCcam.providers')\"></td>";
   echo "<td><input type='button' name='cccamprivatepayserver' value='".$CCcam_private_payserver."' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"OpenFile('".$CCcam_private_payserver."')\"></td>";
   echo "<td><div style='width:120;text-align:right'>".$editor_lv_save_recent_file.": </div></td>";
   echo "<td><input type='submit' name='Save' value='".$editor_lv_save."' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px'></td>";
   echo "</tr><table>";

// --------- BUTTONS END

   echo "<table><tr>";
   echo "</tr><tr><td valign='top'>";

   echo "<a class='editor'></a>";

   echo "</td><td>";

   echo "<table width='100%'><tr><td><b></b></td></tr>" ;
   echo "<tr valign='top' ><td valign='top' class='content'>" ;
   echo "<pre>" ;

   if(!$_SERVER['QUERY_STRING'] && !isset($_POST['Save']))
   {
      echo "<textarea id='resizable' class='resizable' name='config' cols=".$editorgeometry[1]." rows=".$editorgeometry[0]." wrap=".$editorwrap." readonly>" ;
   }
   else
   {
      echo "<textarea id='resizable' class='resizable' name='config' cols=".$editorgeometry[1]." rows=".$editorgeometry[0]." wrap=".$editorwrap.">" ;
   }

   if(isset($_POST['Save']))
   {
      $editing_file = "";
      list($savedfile, $action) = explode("&", $_SERVER['QUERY_STRING']);
      echo $editor_lv_info;
   }	
   else if($_SERVER['QUERY_STRING'] == $CCcam_cfg)
   {
      $editing_file = "ftp://".$cccam_host.$cccam_configuration_path."/".$CCcam_cfg;
      echo file_get_contents("ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."/".$CCcam_cfg , "w");
   }
   else if($_SERVER['QUERY_STRING'] == $CCcam_prio)
   {
      $editing_file = "ftp://".$cccam_host.$cccam_configuration_path."/".$CCcam_prio;
      echo file_get_contents("ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."/".$CCcam_prio , "w");
   }
   else if($_SERVER['QUERY_STRING'] == $CCcam_channelinfo)
   {
      $editing_file = "ftp://".$cccam_host.$cccam_configuration_path."/".$CCcam_channelinfo;
      echo file_get_contents("ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."/".$CCcam_channelinfo , "w");
   }
   else if($_SERVER['QUERY_STRING'] == $CCcam_providers)
   {
      $editing_file = "ftp://".$cccam_host.$cccam_configuration_path."/".$CCcam.providers;
      echo file_get_contents("ftp://".$ftpuser.":".$ftppassword."@".$cccam_host.$cccam_configuration_path."/".$CCcam.providers , "w");
   }
   else if($_SERVER['QUERY_STRING'] == $CCcam_private_payserver)
   {
      $editing_file = "file://localhost/".$CCcam_private_payserver;
      $array = file($CCcam_private_payserver);
      for ( $i = 0; $i < count ( $array ); $i++ )
      {
         echo $array[$i];
      }
   }
   else
   {
      $editing_file = "";
      echo $editor_lv_info;
   }

   echo "</textarea>";
   echo "</td></tr>";
   echo "<tr><td class=\"Editor_Info\">";

   if ($editing_file == "")
   {
      if ($savedfile != "")
         echo "File ".$savedfile." has been successfully saved.";
      else
         echo "<img border=\"0\" src=\"images/edit_disabled.png\" width='".$icon_width."' height='".$icon_height."'> ".$editor_lv_no_file;
   }
   else
      echo "<img border=\"0\" src=\"images/edit.png\" width='".$icon_width."' height='".$icon_height."'> ".$editing_file;

   echo "</td></tr>";
   echo "</form>";
// echo "<br>";
   echo "</pre>";
   echo "</td></tr></table>";
   echo "</td></tr></table>";
   echo "<br>";

   ENDPage();
?>
