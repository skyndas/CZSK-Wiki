<?php
	define('REFRESH',"refresh.php");

	ob_start();

	if ($use_auto_refresh && isRefreshActive())
	{
		$refresh_url = basename($pagina);
		$refresh_interval = (int)getRefreshInterval();
		$refresh_interval = $refresh_interval * 60;
		$header = "refresh:".$refresh_interval.";url=".$refresh_url;
		if ($update_on_refresh)
		{
			if ($use_embedded_webserver)
				$header .= "?refreshupdate=1&forceupdate=1";
			else
				$header .= "?forceupdate=1";
		}
		header( $header );
	}
?>

