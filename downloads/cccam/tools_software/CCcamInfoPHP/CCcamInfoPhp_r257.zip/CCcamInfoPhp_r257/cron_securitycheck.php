<?php
   $cron_p= "";

   if(isset($_GET['p']))
   {
      $cron_p = $_GET['p'];
      $cron_profil = (int)(trim($cron_p));
   }
   else
      if (file_exists("cronprofile.ini"))
      {
         echo "cronprofile.ini exists.<br>"; // debug

         $cron_profile_ini = file("cronprofile.ini");
         $cron_profil = (int)(trim($cron_profile_ini[0]));
      }

   $cron_securitycheck = true;
   $doSecuritycheck = false;
   include "common.php";
   include "yaps.php";

   echo "\$cron_profil is ".$cron_profil."<br>"; // debug

   echo "Disclosure is ".DISCLOSURE.".<br>"; // debug
   if($use_cronsecuritycheck && $use_portscan_all && function_exists('isSecuritycheckActive') && isSecuritycheckActive())
   {
      echo "function isSecuritycheckActive() exists and result is true!<br>"; // debug
      $doSecuritycheck = true;
   }
   else if (function_exists('isSecuritycheckActive') && !isSecuritycheckActive())
      echo "function isSecuritycheckActive() exists and result is false!<br>"; // debug
   else if (!defined('COMMON_NONPUBLIC'))
      echo "function isSecuritycheckActive() does not exist, thus doing nothing<br>"; // debug

   if ($doSecuritycheck)
   {
      // suspend cron_update
      if (isCronupdateActive())
      {
         echo "suspending cronupdate.<br>"; // debug

         $resume_cron_update = true;
         suspendCronUpdate();
      }
      else
         $resume_cron_update = false;

      echo "\$doSecuritycheck = true, doing security check.<br>"; // debug

      if(function_exists('checkSecurityAll'))
      {
         echo "function checkSecurityAll() does exist.<br>"; // debug

         checkSecurityAll();
      }

      // resume cron_update
      if ($resume_cron_update)
      {
         echo "resuming cronupdate.<br>"; // debug

         resumeCronUpdate();
      }

   }
   else
      echo "\$doSecuritycheck = false, doing no security check!"; // debug

?>
