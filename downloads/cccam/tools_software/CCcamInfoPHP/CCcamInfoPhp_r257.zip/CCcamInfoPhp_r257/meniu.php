<HTML>
<HEAD>
<LINK HREF="cccam.css" REL="Stylesheet" TYPE="text/css">
<style type="text/css">
<!--
.style1 {color: #AFCC00}
-->
</style>
</HEAD>
<BODY>
<?php
   include "update.php";

   $cccam_version = "";
   if (file_exists($caminfo_file))
   {
      $caminfo_data = file ($caminfo_file);

      if (count($caminfo_data)>0)
         foreach ($caminfo_data as $currentline) 
         {
            $liniesplit = explode("H2>", $currentline);
            foreach ($liniesplit as $linie) 
            {
               if (strstr($linie,"Welcome to CCcam")) 
               {
                  $cccam_version = $linie;
               }
            }
         }
   }

?>

<script type="text/javascript" language="Javascript"> 
function toggleDisplay(nod) { 
if( document.getElementById(nod).style.display == "none" ) {
    document.getElementById(nod).style.display = "block"; 
  } else { 
    document.getElementById(nod).style.display = "none"; }
}
function NewProfile()
{
    //location.href="meniu.php?profile=new";
    location.href="getconfigserver.php?profile=new";
}
function DeleteProfile(server,port,user,pass,cccamconfigfilepath,keyfilepath,ftpuser,ftppass)
{
    var answer = confirm("<?php echo $meniu_lv_areyousure ?>");
    if (answer)
    {
        location.href="configserver.php?profile=delete&server=" + server + "&port=" + port + "&user=" + user + "&pass=" + pass + "&cccamconfigfilepath=" + cccamconfigfilepath + "&keyfilepath=" + keyfilepath + "&ftpuser=" + ftpuser + "&ftppass=" + ftppass;
    }
}
function EditProfile(server,port,user,pass,cccamconfigfilepath,keyfilepath,ftpuser,ftppass)
{
    location.href="getconfigserver.php?profile=edit&server=" + server + "&port=" + port + "&user=" + user + "&pass=" + pass + "&cccamconfigfilepath=" + cccamconfigfilepath + "&keyfilepath=" + keyfilepath + "&ftpuser=" + ftpuser + "&ftppass=" + ftppass;
}
function doRefresh(pagina)
{
    if (document.autorefreshForm.autorefresh.checked == true)
        location.href = pagina + "?autorefresh=yes";
    else
        location.href = pagina + "?autorefresh=no";
}
function doCronUpdate(pagina)
{
    if (document.cronUpdateForm.cronupdate.checked == true)
        location.href = pagina + "?cronupdate=yes";
    else
        location.href = pagina + "?cronupdate=no";
}
function doCronSecuritycheck(pagina)
{
    if (document.cronSecuritycheckForm.cronsecuritycheck.checked == true)
        location.href = pagina + "?cronsecuritycheck=yes";
    else
        location.href = pagina + "?cronsecuritycheck=no";
}
function doReloadOnButton(pagina)
{
    if (document.reloadOnButtonForm.reloadOnButton.checked == true)
        location.href = pagina + "?reloadonbutton=yes";
    else
        location.href = pagina + "?reloadonbutton=no";
}

</script>

<BR>

<font face='Arial' size=4 color=white>

<?php

   $pagina = basename($pagina);

   if ($cccam_version != "")
   {
      echo "<b>".$cccam_version."b>";
   }

   echo "( <font size=3 color=gray><SPAN onclick='toggleDisplay(\"".$idtable['PROFILES']."\");' style='cursor:hand;'>".$cccam_host." <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN></font> )";

?>

</font>

<?php
   echo "<font size='1' color='#494949'></font><font size='1'><B>";

   if ($use_settings)
   {
      if (detect_ie())
         echo "&nbsp;&nbsp;<SPAN class='style1' onclick='toggleDisplay(\"".$idtable['SETTINGS']."\");' style='cursor:hand;'><img border=\"0\" src=\"images/configuration.png\" title=\"".$meniu_lv_configuration."\" width='12' height='12' align=\"middle\"></SPAN>&nbsp;&nbsp;&nbsp;";
      else
         echo "&nbsp;&nbsp;<SPAN class='style1' onclick='toggleDisplay(\"".$idtable['SETTINGS']."\");' style='cursor:hand;'><img border=\"0\" src=\"images/configuration.png\" title=\"".$meniu_lv_configuration."\" width='12' height='12' style='vertical-align:text-bottom'></SPAN>&nbsp;&nbsp;&nbsp;";
   }

   if ($use_changelog)
      echo "<SPAN class='style1' onclick='toggleDisplay(\"".$idtable['CHANGELOG']."\");' style='cursor:hand;'>".$programversion." <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN> - <font size=2 color=yellow>";
   else
      echo "<SPAN class='style1'>".$programversion." <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN> - <font size=2 color=yellow>";

   echo "<SPAN onclick='toggleDisplay(\"".$idtable['LANGUAGES']."\");' style='cursor:hand;'>".$meniu_lv_lang." <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN></font></B>&nbsp; </font>";

   echo "<BR>";

// echo "<font size='1' color'#494949'>&nbsp;</font><font size='1'><span class='style1'>&nbsp;<B>".$programversion." - <font size=2 color=yellow><SPAN onclick='toggleDisplay(\"".$idtable['CHANGELOG']."\");' style='cursor:hand;'>".$meniu_lv_lang." <img border=\"0\" src=\"images/arrow.gif\" width=\"12\" height=\"12\"></SPAN></font></B>&nbsp; </span></font><BR>";

   echo "<table id=\"".$idtable['PROFILES']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";
   echo "<tr><td>&nbsp;</td></tr><tr><td>$meniu_lv_selectactiveprofile&nbsp<input type='button' name='NewProfile' value='$meniu_lv_new' style='width:60px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"NewProfile()\"</A> $meniu_lv_definenewprofile:</td></tr>";
   echo "<tr>";
   echo "<td>";

// echo "<td class=\"Node_IDr\"><A HREF=".$pagina."?username=$username>".$username."</A></td>";
   $index=-1;
   foreach ($CCCamWebInfo as $cccam_host_profil => $cccam_profil_hostname) 
   {
      $ccamhost_path        = $work_path.$cccam_profil_hostname[0]."/";
      $ccamhost_update_log  = $ccamhost_path."update.log";
   		
      $ccamhost_TIMP_Update= "";

      if (file_exists($ccamhost_update_log)) 
      {
         $ccamhost_update_log_data = file ($ccamhost_update_log);
         $ccamhost_timp_lastupdate = $ccamhost_update_log_data[0];
         $diff = time() - $ccamhost_timp_lastupdate;
         $ccamhost_TIMP_Update = $menui_lv_lastupdate." : ".get_formatted_timediff($ccamhost_timp_lastupdate)." ".$generic_lv_ago;
         if ( $diff > (3* INT_DAY))
            $ccamhost_TIMP_Update = "<FONT color=red>".$ccamhost_TIMP_Update."</FONT>";
         if ( $diff < (12* INT_HOUR))
            $ccamhost_TIMP_Update = "<FONT color=green>".$ccamhost_TIMP_Update."</FONT>";
      }

      $server = $cccam_profil_hostname[0];
      $port = $cccam_profil_hostname[1];
      $user = $cccam_profil_hostname[2];
      $pass = $cccam_profil_hostname[3];
      $cccamconfigfilepath = $cccam_profil_hostname[4];
      $keyfilepath = $cccam_profil_hostname[5];
      $ftpuser = $cccam_profil_hostname[6];
      $ftppass = $cccam_profil_hostname[7];

      $linkprofil = "<input type='button' name='EditProfile' value='$meniu_lv_editprofile' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditProfile('$server','$port','$user','$pass','$cccamconfigfilepath','$keyfilepath','$ftpuser','$ftppass')\"</A><A class=\"server_profile\" HREF=".$pagina."?setProfil=".$cccam_host_profil.">"; 
      // if ($cccam_host == $cccam_profil_hostname[0])
      $index++;
      if ($index == $active_profie)	//(DT2)
      {
         $linkprofil = $linkprofil."<A class=\"tabel_param\" HREF=".$pagina."?setProfil=".$cccam_host_profil.">";
      // $linkprofil = $linkprofil.$meniu_lv_currentprofile."&nbsp;&nbsp;"."<FONT color=red>(".$cccam_host_profil.") ".$cccam_profil_hostname[0]."</FONT></A>"; 
         $linkprofil = $linkprofil."<FONT color=red>(".$cccam_host_profil.") ".$cccam_profil_hostname[0]."</FONT></A>"; 
      }
      else
      {
         $linkprofil = "<input type='button' name='DeleteProfile' value='$meniu_lv_deleteprofile' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"DeleteProfile('$server','$port','$user','$pass','$cccamconfigfilepath','$keyfilepath','$ftpuser','$ftppass')\"</A><A class=\"server_profile\" HREF=".$pagina."?setProfil=".$cccam_host_profil.">"; 
         $linkprofil = $linkprofil." (".$cccam_host_profil.") ".$cccam_profil_hostname[0]."</A>"; 
      }

      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$linkprofil;   
      echo "&nbsp;";
      echo $ccamhost_TIMP_Update;   
      echo "<BR>";
   }

   echo "</td>";
   echo "</tr>";

   echo "<tr><td><BR></td></tr>";

   echo "</table>";
?>

<?php
   unset($files);
   $dir='language';
   if (is_dir($dir))
   {
      if ($handle = opendir($dir))
      {
         $files = array();
         while (false !== ($file = readdir($handle)))
         {
            if (is_file($dir."/".$file) && $file != basename($_SERVER['PHP_SELF']))
            {
               $files[] = $file;
            }
         }
      }
      closedir($handle);
      if (is_array($files))
         sort($files);
   }

   echo "<table id=\"".$idtable['LANGUAGES']."\" style='display:none;' border=0 cellpadding=4 cellspacing=0>";
   echo "<tr>";
   echo "<td>$meniu_lv_selectlang</td>";

   foreach ($files as $country) 
   {
      if (strstr($country,".php"))
      {
         $lang=strtoupper(substr($country,0,2));
         $gif=strtolower($lang).".gif";
         echo "<td><input type=\"image\" src=\"language/$gif\" title=\"$lang\" value=\"$lang\" ";
         echo "onclick=\"parent.location='index.php?language=".$lang."&forceupdate=1&page=".$pagina."'\"></td>";
         echo "</td>";
      }
   }

   echo "</tr>";

   echo "</table>";
?>

<?php
   echo "<table id=\"".$idtable['SETTINGS']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";
   echo "<tr><td>&nbsp;</td></tr><tr><td>".$meniu_lv_select_settings.":</td></tr><tr><td>&nbsp;</td></tr>";
   echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='GlobalSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_globalsettings."</td></tr>";
   echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='EditorSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_editorsettings."</td></tr>";
   echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='YapsSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_yapssettings."</td></tr>";

   if ($use_caidfilter)
   {
      echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='CAIdFilterSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_caidfiltersettings."</td></tr>";
   }

   echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='notlocalCAIdSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_notlocalcaidsettings."</td></tr>";

   if ($use_resetstatistics)
   {
      echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='ResetStatsSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_resetstatisticssettings."</td></tr>";
   }

   if (function_exists('isCronupdateActive'))
   {
      echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='CronUpdateSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"CronUpdateSettings()\"> ".$meniu_lv_cronupdatesettings."</td></tr>";
   }

   if ($use_tags)
   {
      echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='TagSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_tagssettings."</td></tr>";
   }

   if ($use_securitycheck && $use_portscan)
   {
      echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' name='PortscanSettings' value='".$meniu_lv_configurebutton."' style='width:100px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"EditGlobalSettings()\"> ".$meniu_lv_portscansettings."</td></tr>";
   }

   echo "<tr><td>&nbsp;</td></tr>";
   echo "</table>";

// echo "<script>setFocus();</script>";
   echo "<br>";
?>

<input class="normalbutton" type="button" value="<?php echo $meniu_lv_home?>" onClick="parent.location='index.php'">
<input class="normalbutton" type="button" value="<?php echo $generic_lv_clients?>" onClick="parent.location='clientstats.php'">
<input class="normalbutton" type="button" value="<?php echo $generic_lv_servers?>" onClick="parent.location='serverstats.php'">
<input class="normalbutton" type="button" value="<?php echo $meniu_lv_pairs?>" onClick="parent.location='pairstats.php'">
<input class="normalbutton" type="button" value="<?php echo $generic_lv_shares?>" onClick="parent.location='nodestats.php'">
<input class="normalbutton" type="button" value="<?php echo $generic_lv_providers?>" onClick="parent.location='providerstats.php'">
<input class="normalbutton" type="button" value="<?php echo $generic_lv_entitlements?>" onClick="parent.location='entitlementstats.php'">
<?php
   if ($use_editor)
   {
      echo "&nbsp;&nbsp;";
?>
<input class="editbutton" type="button" value="Editor" onclick="parent.location='editor.php'">
<!--
&nbsp;&nbsp;
<input class="updatebutton" type="button" value="Profile" onclick="parent.location='profiles.php'">
-->
<?php
   }

   if ($use_syslog)
   {
      echo "&nbsp;&nbsp;";
?>
<input class="syslogbutton" type="button" value="Syslog" onclick="parent.location='index.php'">
<!--
&nbsp;&nbsp;
<input class="updatebutton" type="button" value="Profile" onclick="parent.location='profiles.php'">
-->
<?php
   }

   if ($update_from_button)
   {
      echo "&nbsp;&nbsp;";
      echo "<input class=\"updatebutton\" type=\"button\" value=\"$meniu_lv_updatebutton\" ";

      if ($sort!="")
         echo "onclick=\"parent.location='".$pagina."?forceupdate=1&sort=".$sort."'\">";
      // echo "onclick=\"parent.location='index.php?forceupdate=1&page=".$pagina."&sort=".$sort."'\">";
      else
         echo "onclick=\"parent.location='".$pagina."?forceupdate=1'\">";
      // echo "onclick=\"parent.location='index.php?forceupdate=1&page=".$pagina."'\">";
   }

   if (isRefreshActive() && isRefreshablePage())
   {
      if (detect_ie())
         $refresh_image_tag = " <img border=\"0\" src=\"images/refresh_active.png\" title=\"".$meniu_lv_refresh_active."\" align=\"top\">";
      else
         $refresh_image_tag = " <img border=\"0\" src=\"images/refresh_active.png\" title=\"".$meniu_lv_refresh_active."\" style='vertical-align:text-bottom'>";
   }
   else
   {
      if (detect_ie())
         $refresh_image_tag = " <img border=\"0\" src=\"images/refresh_inactive.png\" title=\"".$meniu_lv_refresh_not_active."\" align=\"top\">";
      else
         $refresh_image_tag = " <img border=\"0\" src=\"images/refresh_inactive.png\" title=\"".$meniu_lv_refresh_not_active."\" style='vertical-align:text-bottom'>";
   }

   if (function_exists('isCronupdateActive') && isCronupdateActive() == true)
   {
      if (detect_ie())
         $cron_image_tag = " <img border=\"0\" src=\"images/cron_active.png\" title=\"".$meniu_lv_cronupdate_active."\" width='10' height='11' align=\"center\">&nbsp;";
      else
         $cron_image_tag = " <img border=\"0\" src=\"images/cron_active.png\" title=\"".$meniu_lv_cronupdate_active."\" width='10' height='11' style='vertical-align:text-bottom'>&nbsp;";
   }
   else if (function_exists('isCronupdateActive') && isCronupdateActive() == false)
   {
      if (detect_ie())
         $cron_image_tag = " <img border=\"0\" src=\"images/cron_inactive.png\" title=\"".$meniu_lv_cronupdate_not_active."\" width='10' height='11' align=\"center\">&nbsp;";
      else
         $cron_image_tag = " <img border=\"0\" src=\"images/cron_inactive.png\" title=\"".$meniu_lv_cronupdate_not_active."\" width='10' height='11' style='vertical-align:text-bottom'>&nbsp;";
   }

   if ($use_reload_on_button && isReloadActive() == true)
   {
      if (detect_ie())
         $reload_image_tag = " <img border=\"0\" src=\"images/reload_active.png\" title=\"".$meniu_lv_reload_active."\" width='13' height='13' align=\"center\">&nbsp;";
      else
         $reload_image_tag = " <img border=\"0\" src=\"images/reload_active.png\" title=\"".$meniu_lv_reload_active."\" width='13' height='13' style='vertical-align:text-bottom'>&nbsp;";
   }
   else if ($use_reload_on_button && isReloadActive() == false)
   {
      if (detect_ie())
         $reload_image_tag = " <img border=\"0\" src=\"images/reload_inactive.png\" title=\"".$meniu_lv_reload_not_active."\" width='13' height='13' align=\"center\">&nbsp;";
      else
         $reload_image_tag = " <img border=\"0\" src=\"images/reload_inactive.png\" title=\"".$meniu_lv_reload_not_active."\" width='13' height='13' style='vertical-align:text-bottom'>&nbsp;";
   }

   if (function_exists('isSecuritycheckActive') && isSecuritycheckActive() == true)
   {
      if (detect_ie())
         $securitycheck_image_tag = " <img border=\"0\" src=\"images/portcheck_active.png\" title=\"".$meniu_lv_cronportcheck_active."\" width='12' height='12' align=\"center\">";
      else
         $securitycheck_image_tag = " <img border=\"0\" src=\"images/portcheck_active.png\" title=\"".$meniu_lv_cronportcheck_active."\" width='12' height='12' style='vertical-align:text-bottom'>";
   }
   else if (function_exists('isSecuritycheckActive') && isSecuritycheckActive() == false)
   {
      if (detect_ie())
         $securitycheck_image_tag = " <img border=\"0\" src=\"images/portcheck_inactive.png\" title=\"".$meniu_lv_cronportcheck_not_active."\" width='12' height='12' align=\"center\">";
      else
         $securitycheck_image_tag = " <img border=\"0\" src=\"images/portcheck_inactive.png\" title=\"".$meniu_lv_cronportcheck_not_active."\" width='12' height='12' style='vertical-align:text-bottom'>";
   }

   if ($use_server_note && function_exists('isNoteAvailable'))
      if (isNoteAvailable() == true && filesize($server_note_file) != 0)
      {
         if (detect_ie())
            $note_image_tag = " <img border=\"0\" src=\"images/note_active.png\" title=\"".$meniu_lv_note_active."\" width='11' height='11' align=\"center\">&nbsp;";
         else
            $note_image_tag = " <img border=\"0\" src=\"images/note_active.png\" title=\"".$meniu_lv_note_active."\" width='11' height='11' style='vertical-align:text-bottom'>&nbsp;";
      }
      else
      {
         if (detect_ie())
            $note_image_tag = " <img border=\"0\" src=\"images/note_inactive.png\" title=\"".$meniu_lv_note_not_active."\" width='11' height='11' align=\"center\">&nbsp;";
         else
            $note_image_tag = " <img border=\"0\" src=\"images/note_inactive.png\" title=\"".$meniu_lv_note_not_active."\" width='11' height='11' style='vertical-align:text-bottom'>&nbsp;";
      }

   if ($use_auto_refresh)
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['REFRESH']."\");' style='cursor:hand;'>$refresh_image_tag</SPAN>";

   if ($use_cronupdate)
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['CRONUPDATE']."\");' style='cursor:hand;'>$cron_image_tag</SPAN>";

   if ($use_cronsecuritycheck)
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['CRONSECURITYCHECK']."\");' style='cursor:hand;'>$securitycheck_image_tag</SPAN>";

   if ($use_reload_on_button)
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['RELOADONBUTTON']."\");' style='cursor:hand;'>$reload_image_tag</SPAN>";

   if ($use_server_note)
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['SERVERNOTE']."\");' style='cursor:hand;'>$note_image_tag</SPAN>";
   else
      echo "&nbsp;";

   echo "<SPAN onclick='toggleDisplay(\"".$idtable['TIMEUPDATE']."\");' style='cursor:hand;'> ".$TIMP_Update." <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
// echo " ".$TIMP_Update;

//-------- AUTOREFRESH Setup : START
   echo "<table id=\"".$idtable['REFRESH']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";

   echo "<tr>";

   if ($use_auto_refresh)
   {
      echo "<td width=\"300\" height=\"70\">";
?>
<FORM NAME="autorefreshForm" METHOD="GET" ACTION="
<?php
      echo $pagina;
?>
"><input TYPE="checkbox" VALIGN="center" NAME="autorefresh" VALUE="yes" onclick=doRefresh("<?php echo $pagina ?>") 
<?php
      if (isRefreshActive())	echo "checked";
?>
> 
<?php echo $meniu_lv_refresh_page ?>
 <INPUT TYPE="text" CLASS="TEXTAREANORMALC" SIZE="1" MAXLENGTH="2" NAME="saveRefreshInterval" ID="saveRefreshInterval" TABINDEX="1" VALUE="<?php
      $refreshinterval = getRefreshInterval();
      echo $refreshinterval;
?>">
<?php echo $meniu_lv_refresh_minutes."&nbsp;&nbsp;" ?>
<INPUT TYPE="submit" VALUE=<?php echo $index_lv_save?> TABINDEX="1" CLASS="savetextbutton">
</FORM>
<?php
      echo "</td></tr>";
   }
   echo "</table>";
//-------- AUTOREFRESH Setup : END

//-------- CRONUPDATE Setup : START
   if (function_exists('isCronupdateActive'))
   {
      echo "<table id=\"".$idtable['CRONUPDATE']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";

      echo "<tr>";

      if ($use_cronupdate)
      {
         echo "<td width=\"300\" height=\"70\">";
?>
<FORM NAME="cronUpdateForm" METHOD="GET" ACTION="
<?php
         echo $pagina;
?>
"><input type="checkbox" valign="center" name="cronupdate" value="yes" onclick=doCronUpdate("<?php echo $pagina ?>") 
<?php
         if (isCronupdateActive())  echo "checked";
?>
> 
<?php echo $meniu_lv_cron_update ?>
</FORM>
<?php
         echo "</td></tr>";
      }
      echo "</table>";
   }
//-------- CRONUPDATE Setup : END

//-------- CRONSECURITYCHECK Setup : START
   if (function_exists('isSecuritycheckActive'))
   {
      echo "<table id=\"".$idtable['CRONSECURITYCHECK']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";

      echo "<tr>";

      if ($use_cronsecuritycheck)
      {
         echo "<td width=\"800\" height=\"70\">";
?>
<FORM NAME="cronSecuritycheckForm" METHOD="GET" ACTION="
<?php
         echo $pagina;
?>
"><input type="checkbox" valign="center" name="cronsecuritycheck" value="yes" onclick=doCronSecuritycheck("<?php echo $pagina ?>") 
<?php
         if (isSecuritycheckActive())  echo "checked";
?>
> 
<?php echo $meniu_lv_cron_portcheck ?>
</FORM>
<?php
         echo "</td></tr>";
      }
      echo "</table>";
   }
//-------- CRONSECURITYCHECK Setup : END

//-------- RELOAD ON BUTTON : START
   if ($use_reload_on_button)
   {
      echo "<table id=\"".$idtable['RELOADONBUTTON']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";

      echo "<tr>";

      echo "<td width=\"800\" height=\"70\">";
?>
<FORM NAME="reloadOnButtonForm" METHOD="GET" ACTION="
<?php
      echo $pagina;
?>
"><input type="checkbox" valign="center" name="reloadOnButton" value="yes" onclick=doReloadOnButton("<?php echo $pagina ?>") 
<?php
      if (isReloadActive())  echo "checked";
?>
> 
<?php echo $meniu_lv_reload_on_button ?>
</FORM>
<?php
      echo "</td></tr>";
      echo "</table>";
   }
//-------- RELOAD ON BUTTON : END

//-------- SERVER NOTE Edit/Show : START
   if ($use_server_note)
   {
      if (!detect_ie())
         echo "<br>";

      echo "<table id=\"".$idtable['SERVERNOTE']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";

      echo "<tr>";

      echo "<br>";
      echo "<td width=\"300\" height=\"70\">";
?>
<FORM NAME="ServerNoteForm" METHOD="POST" ACTION="
<?php
      echo $pagina;
?>
">
<?php echo "<b><FONT COLOR=white>".$meniu_lv_servernote."</FONT></b>" ?>
 <TEXTAREA CLASS="TEXTAREANORMAL" cols=<?php echo $servernotegeometry[1] ?> rows=<?php echo $servernotegeometry[0] ?> NAME="saveServerNote" ID="saveServerNote" TABINDEX="1">
<?php
      if (isNoteAvailable())
      {
         $server_note = "";

         if (filesize($server_note_file) == 0)
            unlink($server_note_file);
         else
         {
            $fh = fopen($server_note_file, 'r');
            $server_note = fread($fh, filesize($server_note_file));
            fclose($fh);
         }
         echo $server_note;
      }
?>
</TEXTAREA>
<?php
      echo "</td>";
      echo "</tr>";
      echo "<tr>";
      echo "<td align=right>";
?>
<INPUT TYPE="submit" VALUE=<?php echo $index_lv_save?> TABINDEX="1" CLASS="savetextbutton">
</FORM>
<?php
      echo "</td></tr>";
   }
   echo "</table>";
//-------- SERVER NOTE Edit/Show : END

//-------- CHANGELOG Show : START
   if ($use_changelog)
   {
      echo "<table id=\"".$idtable['CHANGELOG']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";
      echo "<tr><td>";

      showChangelog();

      if ($use_todolog && function_exists('showToDo'))
      {
         echo "<br>";
         showToDo();
      }

      echo "</td></tr>";
      echo "</table>";
   }
//-------- CHANGELOG Show : END

   echo "<table id=\"".$idtable['TIMEUPDATE']."\" style='display:none;' border=0 cellpadding=0 cellspacing=0>";
   echo "<br>";
   echo "<tr>";
   echo "<td><B>".$meniu_lv_updatetimes." :</B><BR>";

   if (file_exists($update_log)) 
   {
      $update_log_data = file ($update_log);
      if (isset($update_log_data))
         foreach ($update_log_data as $update_log) 
         {
            if ($update_log != $update_log_data[0]) 
            {
               list($text1,$text2) = explode(":", $update_log);
               format1($text1,$text2);
            }
         }
   }
   echo "</td>";
   echo "</table>";

   if ($server_offline == true)
   {
      echo "<BR><BR>";
      echo $update_failed;

      if ($cccam_host == "")
      {
         include "getconfigserver.php";
         exit;
      }
   // if ($cccam_host == "") exit;
   }
   else
   {
      UpdateHitProviders();
   }

   if (detect_ie())
	echo "<br><br>";
?>
