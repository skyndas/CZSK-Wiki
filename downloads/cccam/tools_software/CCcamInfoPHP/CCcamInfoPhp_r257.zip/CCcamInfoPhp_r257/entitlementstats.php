<HTML>
<HEAD>
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<LINK HREF="cccam.css" REL="Stylesheet" TYPE="text/css">
<style type="text/css">
<!--
.style1 {color: #AFCC00}
-->
</style>
</HEAD>
<BODY>

<?php include "common.php"?>

<?php
	if ($use_jump_to_top)
	{
?>
<script type="text/javascript" src="javascript/jumptop.js"></script>
<?php
	}
?>

<?php

	if (!$update_from_button && $use_reload_on_button)
	{
		if (isReloadActive())
			$forceupdate = true;
		$update_entitlements = true;
	}

	include "meniu.php";
	
	if (file_exists($entitlements_file))
		$entitlements_data = file ($entitlements_file);
		
	foreach ($entitlements_data as $currentline) 
	{

		if (!strstr($currentline,"</H2>")) 		
		{
			$line=$currentline;
			if (strstr($line,"card reader"))
			{
				$line=str_replace($line,"card reader",$entitlementstats_lv_cardreader)." ".substr($line,12);
			}
			elseif (strstr($line,"no or unknown card inserted"))
			{
				$line=str_replace($line,"no or unknown card inserted",$entitlementstats_lv_nocard);
			}
			
			echo $line."<BR>";
		}
	}	
	//___________________________________________________________________________________________________
	
	ENDPage();
?>
<BR></BODY></HTML>
