

    CCcamInfoPHP svn r257
    Installation on Apache / Linux:

    Simply copy the folder from the archive CCcamInfoPHP in the htdocs folder of Apache server. If necessary, adjust or the access rights (see Changelog). The files must include the userid and groupid of the Apache server.

    WAMP Installation / Windows:

    Simply copy the folder from the archive CCcamInfoPHP in the www folder of WAMP server.
    The option in the file $ use_embedded_webserver must be set to true config_userspecific.tmpl.php.

    Some functions require a relatively long execution time, so setting
    ;;;;;;;;;;;;;;;;;;;
    ; Resource Limits;
    ;;;;;;;;;;;;;;;;;;;
    ; Maximum execution time of each script, in seconds
    ; PHP: Runtime Configuration - Manual
    ; Note: This directive is hard coded to 0 for the CLI SAPI
    max_execution_time = 30
    in php.ini (wamp \ bin \ apache \ Apache2.2.17 \ bin) must be adjusted by WAMP.

    ********************************

    * Identifying the unknown provider or fake IDs using the file CCcam.providers
    Provider Fake IDs can be defined by the provider ID eight places in the file CCcam.providers is entered, it must occur in the provider name of the text "fake". If an unknown provider ID should be defined, in the provider name, however, the text "unknown ProviderID" occur. Here, the upper and lower case must be observed. In addition, all provider identifiers that are not included in the file CCcam.providers be regarded as an unknown provider identifiers.

    Fake Provider IDs are shown in red, unknown provider identifiers in pink. Fake IDs providers are given priority over unknown provider identifiers in terms of their color in the presentation.

    Here even the fixes to the previous version. The files from the archives just copy the folder CCcamInfoPHP.

