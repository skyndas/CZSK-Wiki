<?php
//---------------------------------------
// CONFIG
//---------------------------------------

if (file_exists("config_userspecific.php") && !defined('CONFIG_USERSPECIFIC'))
        include "config_userspecific.php";

$update_from_button = $use_embedded_webserver ? false : true; 		// set to true if you want Update button ( usefull if update is from remote server and takes too long)
// $update_from_button = false;
$update_entitlements = $use_embedded_webserver ? false : true;		// set to true if you want entitlements being updated from button
// $update_entitlements = false;
$update_on_refresh = $use_embedded_webserver ? true : false;		// set to true if you want an update on page refresh
$update_entitlements_from_cron = false;					// set to true if you want entitlements being updated from cron
$update_entitlements_on_refresh = false;				// set to true if you want entitlements being updated on refresh
$update_yaps_database = false;						// set to true if you want yaps payserver database being updated from button

$fullReshare = true; 							// shows maximum reshare if more than one route for same node
									// set to true to see actual reshare instead of YES/NO
$country_whois = true; 							// use whois for country detection

//-------- DEFINES : START
if (file_exists("defines.php") && !defined('DEFINES'))
        include "defines.php";
//-------- DEFINES : END

//-------- COUNTRYFLAGS Options : START
$use_country_flags = true;						// set to true if you want country flags instead of the country code
$country_flags_path = "flags/";						// do not modify! path to country flags images relative to CCcamInfoPHP root
//-------- COUNTRYFLAGS Options : END

$language = "EN";
if (file_exists("language/".$language.".php"))
	include "language/".$language.".php";
else
{
	echo "Language file ".$language.".php not found, check language directory.";
	exit;
}

$server_username = "linux";

//-------- DEBUG BROWSER Options : START
$use_debug_browser = true;						// set to true if you want to see browser detect result on bottom of the page
//-------- DEBUG BROWSER Options : END

//-------- SIDS Options : START
$use_known_sids = true;							// set to true if you want to see simultaneously requested sids
$use_unknown_sids = true;						// set to true if you want to see the recently discovered unknown sids
$use_trashbin_icon = true;						// set to true if you want a trashbin icon instead of "Delete"
//-------- SIDS Options : END

//-------- TAGS Options : START
$use_tags = true;							// set to true if you generally want to use tags
$use_payserver_tag = true;						// set to true if you want to use payserver tags
$use_security_tag = true;						// set to true if you want to use port security tags
$use_localip_tag = true;
$use_webif_tag = true;							// set to true if you want to use tags for web interface links
$use_excluded_tag = true;						// set to true if you want to use excluded tags
//-------- TAGS Options : END

//-------- PROVIDERS Options : START
$use_fake_providers = false;						// set to true if you want to use a CCcam_fake.providers instead of CCcam.providers as source
$use_unknown_providers = true;						// set to true if you want to use a CCcam.providers instead of CCcam_unknown.providers as source
$fake_providers_needle = "Fake";
$unknown_providers_needle = "unknown ProviderID";
//-------- PROVIDERS Options : END

//-------- EDITOR Options : START
$use_editor = true;							// set to true if you want to use the CCcamInfoPHP editor

$editorgeometry = array("32","132");					// set geometry for the editing area in the editor (lines, columns)
$editorwrap = "on";							// set to "on" for line wrap in the editor, otherwise to off

$backup_path = "backup";						// do not modify!

//-------- EDITOR Options : END

//-------- SECURITY CHECK Options : START
$use_securitycheck = true;						// set to true if you want to use portscan and/or Google dyndns check
//-------- SECURITY CHECK Options : END

//-------- PORTSCAN Options : START
//$use_portscan = true;							// set to true if you want to use the portscan in server.php
$use_portscan = true;
//-------- PORTSCAN Options : END

//-------- GOOGLE DYNDNS CHECK Options : START
$use_google_dyndns_check = true;					// set to true if you want to use Google dyndns check
$use_google_dyndns_check_server_node = true;				// set to true if you want to search for complete server node DynDns inclusive port number
//-------- GOOGLE DYNDNS CHECK Options : END

//-------- CHANGELOG Options : START
$use_changelog = true;							// set to true if you want the changelog to be shown
$changeloggeometry = array("24","132");					// set geometry for the changelog textarea (lines, columns)
//-------- CHANGELOG Options : END

//-------- RESETSTATS Options : START
$use_resetstatistics = true;						// set to true if you want to reset statistics

// $resetstatistics[] = array("ECM.data","",true);		        // ECM statistics
$resetstatistics[] = array("ECM.data","",false);

// $resetstatistics[] = array("activeclients.data","",true);		// activeclients statistics
$resetstatistics[] = array("activeclients.data","",false);

$resetstatistics[] = array("mostactiveclients.data","",true);		// mostactiveclients statistics
// $resetstatistics[] = array("mostactiveclients.data","",false);

// $resetstatistics[] = array("caminfo.data","",true);			// caminfo statistics
$resetstatistics[] = array("caminfo.data","",false);

$resetstatistics[] = array("clients.data","",true);			// clients statistics
//$resetstatistics[] = array("clients.data","",false);

// $resetstatistics[] = array("country.data","",true);			// country statistics
$resetstatistics[] = array("country.data","",false);

// $resetstatistics[] = array("entitlements.data","",true);		// entitlements statistics
$resetstatistics[] = array("entitlements.data","",false);

$resetstatistics[] = array("notes","notes/",false);			// saved notes

$resetstatistics[] = array("contacts","contacts/",false);		// saved contacts

$resetstatistics[] = array("online.data","",true);			// server online statistics
// $resetstatistics[] = array("online.data","",false);

$resetstatistics[] = array("pair.data","",true);			// pairs statistics
// $resetstatistics[] = array("pair.data","",false);

// $resetstatistics[] = array("servers.data","",true);			// servers statistics
$resetstatistics[] = array("servers.data","",false);

// $resetstatistics[] = array("shares.data","",true);			// shares statistics
$resetstatistics[] = array("shares.data","",false);

// $resetstatistics[] = array("update.log","",true);			// CCcamInfoPHP update log
$resetstatistics[] = array("update.log","",false);

$resetstatistics[] = array("usage.data","",true);			// client ECM usage statistics
// $resetstatistics[] = array("usage.data","",false);

$resetstatistics[] = array("webiflinks","webiflinks/",false);		// web interface links

$resetstatistics[] = array("syslog","syslog/",false);			// syslog files

$resetstatistics[] = array("backup","backup/",false);			// backup

// $resetstatistics[] = array("unknownsids.data","",false);		// unknown sids
$resetstatistics[] = array("unknownsids.data","",true);

$resetstatistics[] = array("portcheck.data","",false);			// node portcheck data
// $resetstatistics[] = array("portcheck.data","",true);

$resetstatistics[] = array("portcheck.results","portchecks/",false);	// recent node portcheck data
// $resetstatistics[] = array("portcheck.results","portchecks/",true);

$use_resetstatistics_status_icons = true;                               // set to true if you want icons instead of "(ok)"/"(not ok)"
//-------- RESETSTATS Options : END

//-------- NOTLOCALCAIDS Options : START
$use_notlocalcaids = true;						// set to true if you want not locally handled CAIds to be marked
$notlocalcaids = array(array("d95",""),array("919","2.2.0"),array("1830","2.2.0"),array("1831","2.2.1"),array("1834",""),array("1838",""),array("183d","2.2.0"),array("1843","2.2.1"));
									// CAIds to be marked as not locally handled by CCcam
									// first of the 2 tupel is the CAID and second is the lowest CCcam version that supports the CAID or is empty
//-------- NOTLOCALCAIDS Options : END

//-------- PAYSERVERCHECK Options : START
$use_payservercheck = true;						// set to true if you want to use payserver check
$use_manual_payservercheck = true;					// set to true if you want to check a DynDns for payserver before adding the node to your CCcam.cfg
//-------- PAYSERVERCHECK Options : END

//-------- YAPS Options : START
$use_yaps = true;							// set to false if you don't want to check against YaPS

$yaps["server"] = "yaps.mine.nu";					// YaPS service server default: yaps.mine.nu
$yaps["secure"] = true;							// use SSL connection  default: true
$yaps["db"] = "yaps.xml";						// YaPS local database default: yaps.xml
$yaps["version"]= "3.4";						// Don't edit, it's for the YaPS auto updater!

/* added for compatibility and better human readability */
$yaps["humanreadable"] = true;						// Always set to true for compatibility
$yaps["humanreadabledb"] = "yaps.payserver";
$yaps["humanreadablever"] = "yaps.version";

$update_payservers_from_button = false;					// change it to true if You always want to update from button

$unique_payserver = false;						// set to true if you want each payserver dns to be checked only once and not per port
//-------- YAPS Options : END

//-------- LOPS Options : START
$lops["db"] = "lops.payserver";						// do not modify!
//-------- LOPS Options : END

//-------- CCCAMWEBINTERFACE Options : START
$use_cccam_webif = true;						// set to true if you want to use cccam default web interface link on CCcam-s2s server
$only_local_ip = true;							// set to true if you want to test only in the local area network
//-------- CCCAMWEBINTERFACE Options : END

//-------- WEBINTERFACELINK Options : START
$use_webif_link = true;							// set to true if you want to use web interface links for NewCamd/OSCam cardserver
//-------- WEBINTERFACELINK Options : END

//-------- NOTESPOPUP Options : START
$use_notes_popup = true;						// set to true if you want notes as icon popup instead of plain text
//-------- NOTESPOPUP Options : END

//-------- CONTACTS Options : START
$use_contacts = true;							// set to true if you want use contacts for server nodes
//-------- CONTACTS Options : END

//-------- CONTACTSPOPUP Options : START
$use_contacts_popup = true;						// set to true if you want contacts as icon popup instead of plain text
//-------- CONTACTSPOPUP Options : END

//-------- ECMSTATUSICONS Options : START
$use_ecm_status_icons = true;						// set to true if you want icons instead of "(ok)"/"(not ok)" ecm status
//-------- ECMSTATUSICONS Options : END

//-------- ICONSIZE Options : START
$icon_height = "10";							// do not modify!
$icon_width = "10";							// do not modify!
//-------- ICONSIZE Options : END

//-------- RANKINGICONS Options : START
$use_ranking_icons = true;						// set to true if you want to use ranking icons instead of the plain value
$ranking_icon_height = "10";						// do not modify!
$ranking_icon_width = "50";						// do not modify!
//-------- RANKINGICONS Options : END

//-------- AUTOREFRESH Options : START
$use_auto_refresh = true;						// set to true if you want to use auto refresh

$initial_refresh_active = false;					// do not modify!
$initial_refresh_interval = "5";					// do not modify! auto refresh interval in minutes

$refresh_on_page[] = "index.php";					// use auto refresh on these pages (do not modify!)
$refresh_on_page[] = "clientstats.php";
$refresh_on_page[] = "serverstats.php";

$refresh_on_subpages = false;						// set to true if you want to use refresh also on subpages
//-------- AUTOREFRESH Options : END

//-------- RELOAD ON BUTTON : START
$use_reload_on_button = $use_embedded_webserver ? true : false;		// set to true if you want the choice to reload on button;
$initial_reload_active = false;						// set to true if you want to reload/update on button
//-------- RELOAD ON BUTTON : END

//-------- JUMP TO TOP ANCHOR Options : START
$use_jump_to_top = true;						// set to true if you want to use the jump to top of page anchor
//-------- JUMP TO TOP ANCHOR Options : END

//-------- MOSTACTIVECLIENT Options : START
$use_most_activeclients = true;						// set to true if you want to use most active client statistic
//-------- MOSTACTIVECLIENT Options : END

//-------- MEMORYSTATISTICS Options : START
$use_memory_statistics = true;						// set to true if you want to see memory statistics on the bottom of each page
//-------- MEMORYSTATISTICS Options : END

//-------- CRONUPDATE Options : START
$use_cronupdate = ($update_on_refresh) ? false : true;
$initial_cronupdate_active = false;					// do not modify!
//-------- CRONUPDATE Options : END

//-------- FORMATTED LASTSHARE Options : START
$use_formatted_lastshare = true;
//-------- FORMATTED LASTSHARE Options : END

//-------- PING ALL SORT : START
$use_pingall_sort = SORT_NONE;						// alternative sorting orders available, see defines.php
//-------- PING ALL SORT : END

if (file_exists("nonpublic/config_nonpublic.php") && !defined('CONFIG_NONPUBLIC'))
        include "nonpublic/config_nonpublic.php";

if (!defined('DISCLOSURE'))
        define('DISCLOSURE', 'public');

?>

