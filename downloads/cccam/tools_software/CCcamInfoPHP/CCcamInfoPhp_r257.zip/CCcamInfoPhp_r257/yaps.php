<?php
//-------------------------------------
// YAPS - Yet another Payserver Service
//-------------------------------------

define('YAPS',"yaps.php");

//-------------------------------------
// PARAMS
//-------------------------------------

/* moved to config.php
//-------- YAPS Options : START
$yaps["server"] = "yaps.mine.nu";					// YaPS service server default: yaps.mine.nu
$yaps["secure"] = true;							// use SSL connection  default: true
$yaps["db"] = "yaps.xml";						// YaPS local database default: yaps.xml
$yaps["version"]= "3.4";						// Don't edit, it's for the YaPS auto updater!
//-------- YAPS Options : END
*/

//-------------------------------------
// FUNCTIONS
//-------------------------------------

//___________________________________________________________________________________________________

/* not needed by now, using recent function calls as wrapper functions

function YaPSChecknew($peer, $database, $server)
{
   // init variables
   $isPayServer = false;
   $i = 0;
   $xml = simplexml_load_file($database);
   $ssl == true ? $host = "https://".$server.":443" : $host = "http://".$server.":80";

   // reading hostnames
   foreach($xml->xpath("/yaps/blacklist/hostname") as $fqdn)
   {
      // cut hostname by .
      $domain = explode(".", $fqdn);
      $check  = explode(".", $peer);

      // check hostname
      if(($domain[0] == $check[0]) && similar_text($fqdn, $peer) > 14)
      {
         // set $isPayServer to true if hostname is blacklisted and quit
         $isPayServer = true;
         break;
      }  
   }
  
   // purge arrays
   unset($xml);
   unset($domain);
   unset($check);  

// not needed in our CCcamInfoPHP, functionality has been moved to payserver.php
// handle blacklist status
// switch($isPayServer)
// {
//    case true :					// if hostname is blacklisted
//       return "<a href=\"".$host."/?check=".$peer."\" target=\"_blank\"><font color=\"red\">! Risk !</font></A>";
//       break;
//
//    case false :					// if hostname is not blacklisted
//       return "<font color=#5EFB6E>OK</font>";
//       break;
//
//    default :						// if status is unknow
//       return "Unknow Error";
// }

   return $isPayServer;
}
*/
//___________________________________________________________________________________________________
function YaPSDBDownload($server, $database, $ssl = false, $humanreadable = false, $humanreadabledb = "", $humanreadablever = "")
{
   // init variables  
   $ssl == true ? $host = "https://".$server.":443" : $host = "http://".$server.":80";
   $download = $host."/?export";
   $version  = $host."/?db";

   // check if YaPS needs to download database  
   if(YaPSInfo("dbver", $database) < file_get_contents($version))
   {
      // get xml content
      $content  = file_get_contents($download);

      // create YaPS local database file
      // and put xml content into it      
      $fh = fopen($database, "w");
      fwrite($fh, $content);
      fclose($fh);

      // purge arrays
      unset($content);

      // create 

      // new local database created
      $ret = true;
   }
   else
   {
      // local database already up2date, nothing to do
      $ret = false;
   }

   /* added for compatibility with existing code and better human readability */

   /* debug
   echo $server." ".$database." ".$ssl." ".$humanreadable." ".$humanreadabledb." ".$humanreadablever;
   */

   if ($humanreadable && file_exists($database) && $humanreadabledb != "" && $humanreadablever != "")
   {
      $xml = simplexml_load_file($database);

      // write version info

      $fh = fopen($humanreadablever, "w");
      $version = $xml->xpath("/yaps/database/version");
      $date = date("d.m.Y", "$version[0]");

      /* debug
      var_dump($version);
      echo "<br>".$version[0]." ".$date."<br>";
      */

      fputs($fh, $date);
      fclose($fh);

      // write human readable database

      $fh = fopen($humanreadabledb, "w");

      // reading hostnames
      foreach($xml->xpath("/yaps/blacklist/hostname") as $fqdn)
      {
         // write fully qualfied domain name
         fputs($fh, $fqdn);
         fputs($fh, "\n");
      }

      fclose($fh);

      // purge arrays
      unset($xml);

   }
   return $ret;
}
//___________________________________________________________________________________________________
function YaPSInfo($mode, $database, $server=NULL, $ssl=NULL, $lversion=NULL)
{
   /* added for availability check of YaPS */
   if ($mode != "available")
   {

      // if no database exists return version 0
      if(!file_exists($database)) return 0;

      // load database
      $xml = simplexml_load_file($database);
   }

   switch($mode)
   {
      case "rows" :                                                     // database rows
         $result = $xml->xpath("/yaps/database/rows");
         $output = $result[0];
      break;

      case "dbver" :                                                    // database version
         $result = $xml->xpath("/yaps/database/version");
         $output = $result[0];
      break;

      case "date" :                                                     // database human readable version
         $result = $xml->xpath("/yaps/database/version");
         $output = date("d.m.Y", "$result[0]");
      break;

      case "needupdate" :                                               // check if YaPS needs to be updated
         $ssl == true ? $host = "https://".$server.":443" : $host = "http://".$server.":80";
         $rversion = $host."/?yaps";
         $rversion = file_get_contents($rversion);

         $lversion < $rversion ? $output = 1 : $output = 0;
      break;

      case "update" :                                                   // print update text
         $ssl == true ? $host = "https://".$server.":443" : $host = "http://".$server.":80";
         $update = $host."/?update";
         $result = file_get_contents($update);
         $output = $result;
      break;

      /* added for availability check */

      case "available" :
         $ssl == true ? $host = "https://".$server.":443" : $host = "http://".$server.":80";
         $dummy = $host."/?yaps";
         $result = file_get_contents($dummy);
         $output = $result;
      break;
   }

   // purge arrays
   if(isset($result)) unset($result);
   if(isset($rversion)) unset($rversion);
   if(isset($lversion)) unset($lversion);

   // output result
   return $output;
}
//___________________________________________________________________________________________________
function YaPSGoogleResult($hostname, $port="")
{
   $response = "";
   $pattern  = "resultStats";

   if (($h = fsockopen('www.google.com', 80)) !== false)
   {
/*
   added handling of empty port
*/
      if ($port == "")
         fwrite($h,"GET /search?hl=en&q=%22".urlencode($hostname)."%22 HTTP/1.1\r\n");
      else
         fwrite($h,"GET /search?hl=en&q=%22".urlencode($hostname."+".$port)."%22 HTTP/1.1\r\n");

      fwrite($h,"Host: www.google.com\r\n");
      fwrite($h, "User-Agent: YaPS\r\n");
      fwrite($h,"Connection: close\r\n\r\n");
 
      while (!feof($h))
      {
         $line = fread($h, 8096);
         if(preg_match("/302 Moved/", $line))
         {
            $response = "error";
            break;
         }
         if(preg_match("/".$pattern."/", $line))
         {
            $response = $line;
            break;
         }
      }
      fclose($h);

      if( $response == "error") return 2;

      $position = strpos($response, $pattern);
      $result = substr($response, $position+strlen($pattern)+1, 1);
      
      if(!is_numeric($result))
      {
         $result = substr($response, $position+strlen($pattern)+1+6, 1);
      }

      if($result > 1)
      {
         return 1;
      }
    }
/*
    return false; // fixed return code
*/
    return 0;
}

/* not needed in our CCcamInfoPHP, functionality has been moved to payserver.php

   // Include CCcamPHPInfo stuff
   include "common.php";
   include "meniu.php";

   $floodprotection = "off";

   // Download YaPS database
   YaPSDBDownload($yaps["server"], $save_path.$yaps["db"], $yaps["secure"]);

   // print YaPS version
   format1("YaPS", $yaps["version"]);

   // print YaPS local database version
   format1("Database version", YaPSInfo("date", $save_path.$yaps["db"]));

   // print YaPS local database rows
   format1("Database rows", YaPSInfo("rows", $save_path.$yaps["db"]));

   // print YaPS secure connection option
   $yaps["secure"] == true ? $SSLStatus = "enabled" : $SSLStatus = "disabled";
   format1("Secure connection", $SSLStatus);

   // print YaPS update info if YaPS needs to be updated
   if(YaPSInfo("needupdate", $save_path.$yaps["db"], $yaps["server"], $yaps["secure"], $yaps["version"]) == 1)
   {
      echo "<br>";
      format1("Updates", YaPSInfo("update", $save_path.$yaps["db"], $yaps["server"], $yaps["secure"]));
   }
   
   // print Donate button
   echo "<br>If You like this service please <b><a href=\"http://yaps.mine.nu?donate\" target=\"_blank\">Donate!</a></b><br>";
   
   // CCcamPHPInfo stuff
   loadServersHosts();
   ksort($ServerHost_Conectat);
   echo "<br>";	  
   echo "<table border=0 cellpadding=1 cellspacing=1>";
   echo "<tr>";
   echo "<td width=250 class=\"Node_ID\">Server</td>";
   echo "<td width=50 class=\"Node_ID\" style=\"text-align:center\">Status</td>";
   echo "<td width=50 class=\"Node_ID\" style=\"text-align:center\">Public</td>";
   echo "</tr>";
   echo "</table>"; 
   
   $oldserver = "";
   $yaps["secure"] == true ? $prefix = "https" : $prefix = "http";
   foreach ($ServerHost_Conectat as $sh_host => $server_Time)
   {
      ob_flush();
      flush();
      
      list($host_DNS, $host_PORT) = explode(":", $sh_host);
      $newserver = $host_DNS;

      if($newserver != $oldserver && !ereg("(192\.168\.[0-9]{1,3}\.[0-9]{1,3})", $host_DNS) && "localhost" != $host_DNS && "127.0.0.1" != $host_DNS)
      {
         if ($host_PORT > 0)
         {
            // YaPS
            $result = YaPSCheck($host_DNS, $save_path.$yaps["db"], $yaps["server"]);

            if($floodprotection == "on"){
               $gresult = "Google flood protection, try again later";  
            }
            else
            {
               $google=YaPSGoogleResult($host_DNS, $host_PORT);

               if($google == 1 && $google != 2 )
               {
                  $gresult = "<a href=\"http://www.google.com/#q=%22".urlencode($host_DNS."+".$host_PORT)."%22\" target=\"_blank\"><font color=\"red\">! Risk !</font></A>";
               }
               else if($google == 2)
               {
                  $gresult = "Google flood protection, try again later";
                  $floodprotection = "on";
               }
               else
               {
                  $gresult = "&nbsp;";
               }
            }

            usleep(100000);
  	 }
  	 echo "<table border=0 cellpadding=1 cellspacing=1>";
         echo "<tr>";
  	 echo "<td width=250 class=\"Node_ID\"><A HREF=".$pagina."?nodeDns=$sh_host>".$sh_host."</A></td>";	
  	 echo "<td width=50 class=\"tabel_normal\" style=\"text-align:center\">".$result."</td>";
  	 echo "<td width=50 class=\"tabel_normal\" style=\"text-align:center\">".$gresult."</td>";
  	 echo "</tr>";
  	 echo "</table>";
      }

      $oldserver = $newserver;
   }

   ENDPage();
*/

?>
