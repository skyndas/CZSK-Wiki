<?php
//---------------------------------------
// DEFINES
//---------------------------------------

define('DEFINES',"defines.php");

//-------- TAGS
define("TAG_SECURITY_PORTSCAN",1);					// flag for security portscan tags
define("TAG_SECURITY_PORTSCAN_EXTENDED",2);				// flag for security portscan tags extended
define("TAG_PORTSCAN_EXCLUDED",4);					// flag for portscan excluded tags
define("TAG_PORTSCAN_EXCLUDED_EXTENDED", 8);				// flag for portscan excluded tags extended
define("TAG_LOCAL_IP",16);						// flag for local ip tags
define("TAG_LOCAL_IP_EXTENDED",32);					// flag for local ip tags extended
define("TAG_KNOWN_BY_GOOGLE",64);					// flag for known by google
define("TAG_KNOWN_BY_GOOGLE_EXTENDED",128);				// flag for known by google tags extended
define("TAG_WEBINTERFACE_LINK",256);					// flag for web interface tags
define("TAG_PAYSERVER",512);						// flag for payserver tags
define("TAG_PAYSERVER_EXTENDED",1024);					// flag for payserver tags extended

//-------- SECURITY/PORTSCAN RESULTS
define("SECURITY_UNKNOWN",0);						// portcheck security unknown
define("SECURITY_SECURE",1);						// portcheck security secure, only CCcam port open
define("SECURITY_MODERATE_SECURE",2);					// portcheck security moderate secure, only CCcam port, SSH port, HTTPS port open
define("SECURITY_UNSECURE",3);						// portcheck security unsecure, other ports open

//-------- GOOGLE CHECK RESULT
define("NOT_KNOWN_BY_GOOGLE",0);					// DynDns address not found on Google
define("KNOWN_BY_GOOGLE",1);						// DynDns address found on Google

//-------- SECURITY/PORTSCAN CROND EXCLUDED
define("PORTCHECK_CROND_NOT_EXCLUDED",0);				// not excluded from cron portcheck
define("PORTCHECK_CROND_EXCLUDED",1);					// excluded from cron portcheck

//-------- PORTSCAN RESULT
define("PORTSCAN_PORT_NO_RESULT",0);					// portcheck, no result available for port
define("PORTSCAN_PORT_OPENED",1);					// portcheck, port opened
define("PORTSCAN_PORT_CLOSED",2);					// portcheck, port closed

//-------- IDTABLES							// idtables for spans
$idtable['YAPSSTATUS'] = "yapsstatus";					// idtable for YaPS status (common.php)
$idtable['LOCALSTATUS'] = "localstatus";				// idtable for local status (common.php)
$idtable['PROFILES'] = "profiles";					// idtable for profiles (meniu.php)
$idtable['REFRESH'] = "refresh";					// idtable for refresh (meniu.php)
$idtable['CRONUPDATE'] = "cronupdate";					// idtable for cronupdate (meniu.php)
$idtable['CRONSECURITYCHECK'] = "cronsecuritycheck";			// idtable for cronportcheck (meniu.php)
$idtable['LANGUAGES'] = "languages";					// idtable for languages (meniu.php)
$idtable['SETTINGS'] = "settings";					// idtable for settings (meniu.php)
$idtable['CHANGELOG'] = "changelog";					// idtable for changelog (meniu.php)
$idtable['TIMEUPDATE'] = "timeupdate";					// idtable for time for update (meniu.php)
$idtable['UNKNOWNSIDS'] = "unknownsids";				// idtable for unknown sids (client.php, index.php)
$idtable['KNOWNSIDS'] = "knownsids";					// idtable for actual known SIDs (index.php)
$idtable['CLIENTCONFIGURATION'] = "clientconfiguration";		// idtable for clientconfiguration (client.php)
$idtable['CCCAMWEBIF'] = "cccamwebif";					// idtable for client CCcam web interface (client.php, server.php)
$idtable['PORTSCAN'] = "portscan";					// idtable for portscan (server.php)
$idtable['NEWCAMDWEBIF'] = "newcamdwebif";				// idtable for NewCamd web interface (server.php)
$idtable['CLINESIDFILTER'] = "clinesidfilter";				// idtable for C: line SID filter (editor.php)
$idtable['FLINESIDFILTER'] = "flinesidfilter";				// idtable for F: line SID filter (editor.php)
$idtable['RELOADONBUTTON'] = "reloadonbutton";				// idtable for reload on button (meniu.php)

//-------- PING ALL SORT ORDER
define("SORT_NONE",0);							// do not sort server nodes for ping all
define("SORT_ASCENDING",1);						// sort server nodes ascending for ping all
define("SORT_DESCENDING",2);						// sort server nodes descending for ping all
define("SORT_RANDOM",3);						// sort server nodes randomly ascending or descending for ping all

if (file_exists("nonpublic/defines_nonpublic.php") && !defined('DEFINES_NONPUBLIC'))
	include "nonpublic/defines_nonpublic.php";

?>
