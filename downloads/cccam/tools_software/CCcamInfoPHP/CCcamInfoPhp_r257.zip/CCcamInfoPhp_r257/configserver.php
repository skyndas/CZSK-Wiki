<HTML><HEAD><LINK HREF="cccam.css" REL="Stylesheet" TYPE="text/css">
<style type="text/css">
<!--
.style1 {color: #AFCC00}
-->
</style>
</HEAD><BODY>
<script language=javascript> 
function InitialPage(pagina)
{
    location.href=pagina + ".php";
}
</script>

<?php

   include "common.php"; // New (DT2)

   $myfile = "config_userspecific.php";

   if (file_exists($myfile))
   {
      $config_data = file ($myfile);

      $profile = $_GET['profile'];
      $server = $_GET['server'];
      $port = $_GET['port'];
      $user = $_GET['user'];
      $pass = $_GET['pass'];
      $cccamconfigfilepath = $_GET['cccamconfigfilepath'];
      $keyfilepath = $_GET['keyfilepath'];
      $ftpuser = $_GET['ftpuser'];
      $ftppassword = $_GET['ftppass'];

      $config_line = "";
      $seek_line = "";

      if (($profile == "new") || ($profile == "edit"))
      {
         if ($profile == "new")
         {
            $seek_line = "\$work_path";
         }
         else
         {
            $seek_line = "\$CCCamWebInfo[] = array(\"".$CCCamWebInfo[$active_profie][0]."\"";
         }

         $config_line = "\$CCCamWebInfo[] = array(\"".$server."\",\"".$port."\",\"".$user."\",\"".$pass."\",\"".$cccamconfigfilepath."\",\"".$keyfilepath."\",\"".$ftpuser."\",\"".$ftppassword."\");";
         $config_line = $config_line."\n";
      }
      elseif ($profile == "delete")
      {
         $seek_line = "\$CCCamWebInfo[] = array(\"".$server."\",\"".$port."\",\"".$user."\",\"".$pass."\",\"".$cccamconfigfilepath."\",\"".$keyfilepath."\",\"".$ftpuser."\",\"".$ftppassword."\");";

      }
      elseif ($profile == "client")
      {
         $seek_line = "\$clientmessageport[] = array(\"".$server;
         $seek_line_default = "\$clientmessageport[]";
         $config_line = "\$clientmessageport[] = array(\"".$server."\",\"".$port."\",\"".$user."\",\"".$pass."\");";
         $config_line = $config_line."\n";
      }

      $index_message = -1;
      $index_server = -1;
      $index = -1;
      foreach ($config_data as $currentline) 
      {
         $index++;
         if (strstr($currentline,$seek_line))
         {
            if ($index_server == -1)
               $index_server = $index;
         }
         if ($profile == "client")
         {
            if (strstr($currentline,$seek_line_default))
            {
               if ($index_message == -1)
                  $index_message = $index;
            }
         }
      }

      $new_message_line=false;
      if ($index_server == -1)
      {
         $index_server = $index;
         if ($profile == "client")
         {
            if ($index_message == -1)
            {
               echo "Upssss!!! config.php is corrupt! Please, re-install the application";
               exit;
            }
            else
               $new_message_line=true;
         }
      }

      $fh = fopen($myfile, 'w') or die("can't open file");

      $index = -1;
      foreach ($config_data as $currentline) 
      {
         $index++;
         if ($profile == "new")
         {
            if ($index == $index_server)
            {
               fwrite($fh, $config_line);	
            }
            fwrite($fh, $currentline);	
         }
         elseif ($profile == "edit")
         {
            if ($index == $index_server)
               fwrite($fh, $config_line);
            else	
               fwrite($fh, $currentline);	
         }
         elseif ($profile == "delete")
         {
            if ($index != $index_server)
            {
               fwrite($fh, $currentline);
            }
         }
         elseif ($profile == "client")
         {
            if ($new_message_line==true)
            {
               if ($index == $index_message)
               {
                  fwrite($fh, $config_line);
               }
               fwrite($fh, $currentline);
            }
            else
            {
               if ($index == $index_server)
               {
                  if ($port != "")
                     fwrite($fh, $config_line);	
               }
               else
               {
                  fwrite($fh, $currentline);
               }
            }
         }
      }
      fclose($fh);

      if ($profile == "client")
         echo "<script>InitialPage(\"clientstats\");</script>";		
      else
         echo "<script>InitialPage(\"index\");</script>";		
   }

?>
  
<BR></BODY></HTML>

