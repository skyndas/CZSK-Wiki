<?php
   include "config.php";
   include "payservercheck.php";

   // include jump to top functionality
   if ($use_jump_to_top)
   {
?>
<script type="text/javascript" src="javascript/jumptop.js"></script>
<?php
   }

   /* obsolete, support for old YaPS version
   $yapsserviceavailable = yapsAvailable($yapservice, "date", $secure);
   */

   $yapsserviceavailable = yapsAvailable();

   if ($yapsserviceavailable)
      format1($common_lv_yapservice, $common_lv_yapsavailable);

   if ($use_yaps && $yapsserviceavailable)
      yapsStatus();

   if (!$use_yaps || localStatus($yaps["humanreadablever"]))
   {
      if ($use_yaps && !$yapsserviceavailable)
         echo "<br><FONT COLOR=red>".$serverstats_lv_yapsserviceoffline."</FONT><br>";
      if ($yapsserviceavailable && !yapsUptodate())
         echo "<br><FONT COLOR=red>".$serverstats_lv_updatelocalcopyfirst."</FONT><br>";

      loadServersHosts();
      ksort($ServerHost_Conectat);

      echo "<br>";
      echo "<table border=0 cellpadding=2 cellspacing=1>";
      echo "<tr>";
      echo "<th class=\"tabel_headerc\">#</th>";
      echo "<th class=\"tabel_header\">Server</th>";
      echo "<th class=\"tabel_headerc\">Status</th>";
      echo "</tr>";

      $oldserver = "";

      $i = 1;

      $ps_lops_exists = file_exists($lops["db"]);

      foreach ($ServerHost_Conectat as $sh_host => $server_Time)
      {
         ob_flush();
         flush();

         list($host_DNS, $host_PORT) = explode(":", $sh_host);
         $newserver = $host_DNS;

         if(!$unique_payserver || $newserver != $oldserver)
         {
            if ($host_PORT > 0)
            {
               if ($use_yaps)
               {
                  $ps_yaps = yapsCheck($yaps["humanreadabledb"], $host_DNS);

                  /* obsolete, used for old YaPS version
                  $yaps = yapsCheck($yaps_payserver, $host_DNS, $secure);
                  */

                  /* debug information
                  var_dump($yaps);
                  echo $yaps["humanreadabledb"]." ".$host_DNS." ".$yaps["secure"]."<br>";
                  */
               }

               if ($ps_lops_exists)
                  $ps_lops = yapsCheck($lops["db"], $host_DNS);
            }

            echo "<td class=\"Node_count\">".$i."</td>";
            echo "<td class=\"Node_ID\">";
            echo "<A HREF=".$pagina."?nodeDns=$sh_host>".$sh_host."</A>";
            echo "&nbsp;&nbsp;&nbsp;";
            echo "</td>";
            echo "<td class=\"tabel_hop_total2\">";
            echo "&nbsp;&nbsp;&nbsp;";


            if(!($ps_yaps || $ps_lops))
            {
               echo "<font color=\"green\">".$serverstats_lv_nopayserver."</font>";
            }
            else
            {
//             echo "<a href=\"".$host."/?q=".$host_DNS."\" target=\"_blank\"><font color=\"red\">".$serverstats_lv_payserver." (";
               echo "<font color=\"red\">".$serverstats_lv_payserver." (";

               if ($ps_yaps) // payserver found in YaPS database
               {
                  echo $serverstats_lv_payserveryaps;
               }

               if ($ps_yaps && $ps_lops) // payserver found in both YaPS and local private payserver database
               {
                  echo ", ";
               }

               if ($ps_lops) // payserver found in local private payserver database
               {
                  echo $serverstats_lv_payserverprivate;
               }
               echo ")</font></A>";
            }

            echo "&nbsp;&nbsp;&nbsp;";
            echo "</td>";
            echo "</tr>";

         }

         $oldserver = $newserver;
         $i++;
      }

      echo "</tr>";
      echo "</table>";
   }
   else
   {
      if ($use_yaps)
         echo "<br><FONT COLOR=red>".$serverstats_lv_updatelocalcopyfirst."</FONT><br>";
   }

// echo "<br>";

   ENDPage();
?>
