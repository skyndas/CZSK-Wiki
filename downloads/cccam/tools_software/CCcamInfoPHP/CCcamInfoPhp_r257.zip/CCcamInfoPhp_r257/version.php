<?php
//-------------------------------------
// SVN - REVISION
//-------------------------------------

$svn_revision = "(svn_r257)";

//___________________________________________________________________________________________________   
function change_revision($newrevision)
{
	$myfile = "version.php";
	$config_data = file ($myfile);
	$found = false;

	$fh = fopen($myfile, 'w') or die("can't open file");

	$seek_line1 = "\$svn_revision = \"";
	$seek_line2 = "\$svn_revision=\"";
	$config_line = "\$svn_revision = \"(svn_r".$newrevision.")\";";
	$config_line = $config_line."\n";

	foreach ($config_data as $currentline)
	{
		if ((strstr($currentline,$seek_line1) || strstr($currentline,$seek_line2)) && !$found)
		{
			fwrite($fh, $config_line);
			$found = true;
		}
		else
		{
			fwrite($fh, $currentline);
		}
	}
	fclose($fh);
	return 0;
}

$svn_path = ".svn/entries";

if(file_exists($svn_path))
{
	$svn = file($svn_path);
	$revision = trim($svn[3]);
	if($svn_revision != "(svn_r".$revision.")")
	{
		change_revision($revision);
		$svn_revision = "(svn_r".$revision.")";
	}
	unset($svn);
}

?>

