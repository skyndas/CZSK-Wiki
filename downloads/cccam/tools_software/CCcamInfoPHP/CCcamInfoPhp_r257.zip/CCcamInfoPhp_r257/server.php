<script type="text/javascript" language="Javascript"> 
function doExclude(pagina)
{
	if (document.excludeForm.excludeportscan.checked == true)
		location.href = pagina + "&exclude_portcheck=yes";
	else
		location.href = pagina + "&exclude_portcheck=no";
}
</script>

<?php
   
   include "config.php";

   if(file_exists("payservercheck.php") && !defined('PAYSERVERCHECK')) include "payservercheck.php";

   if ($use_jump_to_top)
   {
?>
<script type="text/javascript" src="javascript/jumptop.js"></script>
<?php
   }
   
   if (file_exists($servers_file))
      $servers_data = file ($servers_file);
      
   if (!isset($servers_data))
   {
      echo "<FONT COLOR=red>".$generic_lv_serverdown." !</FONT>";
      exit;
   }
   
   if (file_exists($shares_file))
      $shares_data = file ($shares_file);
      
   if (!isset($shares_data))
   {
      echo "<FONT COLOR=red>".$generic_lv_serverdown." !</FONT>";
      exit;
   }  
   
   loadOnlineData();
   loadSecuritycheckData();

   //___________________________________________________________________________________________________
   
   $index = 0;
   $lastServer = "";
   $ServerSelectat = "";
   foreach ($servers_data as $currentline)
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,2);
      
      if ($inceput1 == "|" && $inceput2 != " H")
      {
         $server = explode("|", $currentline);
         $server_Host   = trim($server[1]);
         $server_Time   = trim($server[2]);
         $server_Type   = trim($server[3]);
         $server_Ver    = trim($server[4]);
         $server_Nodeid = trim($server[5]);
         $server_Cards  = trim($server[6]);
         $server_Idents = trim($server[7]);
         
         if ($server_Host != "")
         {
            $index++;
            $lastServer = $server_Host;
            $servers[$lastServer]["Info"] = array ($server_Time,$server_Type,$server_Ver,$server_Nodeid,$server_Cards);  
            
            if ($server_Host == $server_nodeDns) $ServerSelectat = $lastServer;

         }
         
         $servers[$lastServer]["Info"]["Idents"][] = $server_Idents;  
      }
   }
   

   //___________________________________________________________________________________________________
   $total_shares["total"] = 0;
   $maxhop = 0;
   

   foreach ($shares_data as $currentline) 
   {
      $inceput1 = substr($currentline,0,1);
      $inceput2 = substr($currentline,1,1);
      
      if ($inceput1 == "|" && $inceput2 != " ")
      {
         $share = explode("|", $currentline);
         
         $share_Host = trim($share[1]);
         $share_Type = trim($share[2]);
         $share_Caid = trim($share[3]);
         $share_System = trim($share[4]);
         
         $share_ProvidersList = trim($share[5]);
         if ($share_ProvidersList == "0,1,2,3,0") $share_ProvidersList= "0,1,2,3"; // pt premiere
         if ($share_ProvidersList == "") $share_ProvidersList = $str_empty;
         $share_Providers = explode(",", $share_ProvidersList); 
         
         list($share_Hop,$share_Reshare) = explode("   ", trim($share[6]));
         $share_Nodes = explode(",", trim($share[7]));  
         $share_Node = $share_Nodes[count($share_Nodes)-1];
         
         $share_Caid = adaug0($share_Caid,4);
         
         $share_Node = sterg0($share_Node);
         
         if ($share_Node == "")
            $share_NodeUnic = $share_Caid."|".$share_System."|".$share_ProvidersList."|".$share_Host;
         else
            $share_NodeUnic = $share_Caid."|".$share_System."|".$share_ProvidersList."|".sterg0($share_Node);
         
         $route = (isset($nodes))?count($nodes[$share_NodeUnic]):0;
         $servers[$share_Host][$share_NodeUnic]["total"] = $route;
         if ($route == 0) $servers[$share_Host][$share_NodeUnic]["total"] = 1;
         $servers[$share_Host][$share_NodeUnic][$route] = array ($share_Host,$share_Type,$share_Caid,$share_System,$share_ProvidersList,$share_Providers,$share_Hop,$share_Reshare,$share_Nodes,$share_Node);  
         
         
         if (!isset($total_shares["total"]))                $total_shares["total"] = 0;
         if (!isset($total_shares[$share_Hop]))             $total_shares[$share_Hop] = 0;
         if (!isset($share_nodes[$share_NodeUnic]))         $share_nodes[$share_NodeUnic] = 0;
         if (!isset($share_nodes_minhop[$share_NodeUnic]))  $share_nodes_minhop[$share_NodeUnic] = 9;
         
         $share_nodes[$share_NodeUnic]++;
         $share_nodes_minhop[$share_NodeUnic] = min( $share_nodes_minhop[$share_NodeUnic], $share_Hop );
         $total_shares["total"]++;
         $total_shares[$share_Hop]++;
         
         if (!isset($host_hop[$share_Host][$share_NodeUnic][$share_Hop]))  $host_hop[$share_Host][$share_NodeUnic][$share_Hop] = 0;
         if (!isset($total_host_shares[$share_Host]["total"]))             $total_host_shares[$share_Host]["total"] = 0;
         if (!isset($total_host_shares[$share_Host][$share_Hop]))          $total_host_shares[$share_Host][$share_Hop] = 0;      
         if (!isset($total_reshare[$share_Host]["total"]))                 $total_reshare[$share_Host]["total"] = 0;    
         if (!isset($re[$share_Host][$share_NodeUnic][$share_Hop]))        $re[$share_Host][$share_NodeUnic][$share_Hop] = 0;
         if (!isset($re[$share_Host][$share_NodeUnic]["reshare"]))         $re[$share_Host][$share_NodeUnic]["reshare"] = 0;     
         
         $host_hop[$share_Host][$share_NodeUnic][$share_Hop]++;
         $total_host_shares[$share_Host]["total"]++;
         $total_host_shares[$share_Host][$share_Hop]++;
         
         if (((int)$share_Reshare)>0) 
         {
            $total_reshare[$share_Host]["total"]++;
            $re[$share_Host][$share_NodeUnic][$share_Hop] = max($re[$share_Host][$share_NodeUnic][$share_Hop],((int)$share_Reshare));
            $re[$share_Host][$share_NodeUnic]["reshare"] = max($re[$share_Host][$share_NodeUnic]["reshare"],((int)$share_Reshare));          
         }
         $maxhop = max($maxhop,$share_Hop);
      } 
   }
//___________________________________________________________________________________________________
function nodeID($NodeUnic,$Host,$Total,$Hop)
{
   global $share_nodes;
   global $share_nodes_minhop;
   
   $nodSh = explode("|",$NodeUnic); 
   
   $Server = $nodSh[3];
   
   $Server2 = explode("_",$Server); 
   
   $Server_Host = "";
   $Server_Host2 = "";

   $Server = nodeIdName($Server);
   
   $extra = $share_nodes[$NodeUnic] - $Total + 1;
   
   if ($Server_Host == $Host)
   {
      $ret = "<font color=Fuchsia><B>".$Server."</B></font>";
   }
   else
   if ($extra > 1)
   {
      if ($share_nodes_minhop[$NodeUnic] == $Hop)
         $ret = "<font color=brown>".$Server."</font>";
      else
         $ret = $Server;
   }
   else
   {
      $ret = "<font color=Crimson>".$Server."</font>";
   }
   
   if ($extra > 1)
         $ret.=" (".$extra.")";
         
   global $pagina;
   global $serverindex;
   $ret = linkNod($NodeUnic,$ret,"node",false);

   return $ret;
}
//___________________________________________________________________________________________________

if ($server_nodeDns != "") 
   $sh_host = $server_nodeDns;
else
   $sh_host = $ServerSelectat;
   
if ($sh_host != "") $nodes = $servers[$sh_host];

if (isset($nodes) && count($nodes))
{ 
   $info_total = 0;  
   if (isset($total_host_shares[$sh_host]["total"]))
      $info_total = $total_host_shares[$sh_host]["total"];
      
   $info_total_unic = count($nodes) - 1;
   
   $info_uniqueIndex = 0;
   if ($info_total!=0)
      $info_uniqueIndex = (int)($info_total_unic/$info_total *100);
   //$info_total_reshare = $total_reshare[$sh_host]["total"];
   //$info_reshareIndex = (int)($info_total_reshare/$info_total_unic *100);
   
   list($host_DNS, $host_PORT) = explode(":", $sh_host);
   
   $host_IP    = trim(getHostIP($host_DNS));
   $tara_host  = taraNameSaved($sh_host);
   $IPServer   = trim($tara_host[1]); 
   $tara_code  = tara($host_IP,$sh_host);


   if ($host_IP !="" && $IPServer !="" && $host_IP != $IPServer)
   {
      loadGlobalServers();
      $globalServers[$sh_host][1] = $IPServer;
      saveGlobalServers();
   }


   if ($country_whois == true) 
      $tara_nume = taraName($tara_code["tara"]);
      
   echo "<table border=0 cellpadding=0 cellspacing=0>";
   echo "<tr>";
   echo "<td VALIGN = \"top\">";

   $node = "";

   // show payserver tag
   if ($use_tags)
   {
      $node .= linkTag("", $sh_host, "", true, "", TAG_PAYSERVER|TAG_PAYSERVER_EXTENDED);
      format1($generic_lv_server,$sh_host,-1,false);
      echo $node."<br>";
   }
   else
      format1($generic_lv_server,$sh_host);

   if ($host_IP=="unknown")
   	format1($server_lv_ipclients,$host_IP);
   else
   	format1($server_lv_ipclients,$host_IP." / ".clientIP($host_IP,$sh_host));

   $reverseDNS = gethostbyaddr($host_IP);

   if ($reverseDNS != $host_IP)
        format1($server_lv_reverse_lookup,$reverseDNS);
   else
        format1($server_lv_reverse_lookup,"<FONT color=red>missing</FONT>");

   if ($country_whois == true)
   {
      if ($tara_code["tara"]=="??")
         format1($generic_lv_country,$server_lv_unresolvedip);
      else
      if ($tara_code["tara"]=="<>")
         format1($generic_lv_country,$server_lv_localprivateip);
      else
      {
         if ($use_country_flags && file_exists($country_flags_path.$tara_code["tara"].".gif"))
            format2($generic_lv_country,$tara_code["tara"],$tara_nume);
         else
            format1($generic_lv_country,$tara_code["tara"]." , ".$tara_nume);
      }
   }
   //format1("Connected from IP",clientIP($host_IP,$sh_host));
   
   if ($nodes["Info"][3] != "")
      format1($generic_lv_nodeid, $nodes["Info"][3]); 
      
   if ($nodes["Info"][3] != "")
      format1($server_lv_typever, $nodes["Info"][1]." / ".$nodes["Info"][2] );
   else
      format1($generic_lv_type, $nodes["Info"][1] ); 

   if ($nodes["Info"][0] != "")
   	format1($server_lv_connected,$nodes["Info"][0]);
   else
   {
      $text_offline = "-- OFFLINE --";
      if (isset($OnlineServers[$sh_host]) && $OnlineServers[$sh_host]["time"]!="")
      {
         $last_online = $OnlineServers[$sh_host]["time"];
	 $text_offline = get_formatted_timediff($last_online)." ago";
      }
      format1($server_lv_connected,"<FONT color=red>$text_offline</FONT>");
   }

   //format1("Type",$nodes["Info"][1]);
   //format1("Version",$nodes["Info"][2]);
   //format1("Shares",$info_total);

   // server node notice   
   echo "</td>";
   echo "<td VALIGN = \"top\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$generic_lv_note." :&nbsp;&nbsp;";
   echo "</td>";
   echo "<td VALIGN = \"top\">";
   
   $notes_saved = "";
   $notes_save_path   = $notes_path.$host_DNS.".".$host_PORT.".note";   
   if (file_exists($notes_save_path)) 
   {
      if (filesize($notes_save_path) == 0)
         unlink($notes_save_path);
      else
      {
         $fh = fopen($notes_save_path, 'r');
         $notes_saved = fread($fh, filesize($notes_save_path));
         fclose($fh);
      }
   }
   ?>
   <FORM NAME="formularNotes" METHOD="post" ACTION="
   <?php 
   echo $pagina;
   ?>
   "><TEXTAREA CLASS="TEXTAREANORMAL" COLS="58" name="saveNotes" ID="saveNotes" ROWS="11" TABINDEX="1" value=""><?php echo $notes_saved ?></TEXTAREA>
   <DIV ALIGN = "right"><INPUT TYPE="submit" VALUE=<?php echo $server_lv_save?> TABINDEX="2" class="savetextbutton"></DIV>
      <input type="hidden" name="nodeDns" ID="nodeDns" value="<?php echo $server_nodeDns ?>">
   </FORM>
   <?php

   if ($use_contacts)
   {
      echo "</td></tr><tr><td height=8></td></tr><tr><td>";

      // contact notice
      echo "</td>";
      echo "<td VALIGN = \"top\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$generic_lv_contact." :&nbsp;&nbsp;";
      echo "</td>";
      echo "<td VALIGN = \"top\">";

      $contacts_saved = "";
      $contacts_save_path = $contacts_path.$host_DNS.".".$host_PORT.".server.contact";
      if (file_exists($contacts_save_path))
      {
         if (filesize($contacts_save_path) == 0)
            unlink($contacts_save_path);
         else
         {
            $fh = fopen($contacts_save_path, 'r');
            $contacts_saved = fread($fh, filesize($contacts_save_path));
            fclose($fh);
         }
      }
   ?>
   <FORM NAME="formularContacts" METHOD="post" ACTION="
   <?php
      echo $pagina;
   ?>
   "><TEXTAREA CLASS="TEXTAREANORMAL" COLS="58" name="saveContacts" ID="saveContacts" ROWS="2" TABINDEX="1" value=""><?php echo $contacts_saved ?></TEXTAREA>
   <DIV ALIGN = "right"><INPUT TYPE="submit" VALUE=<?php echo $server_lv_save?> TABINDEX="2" class="savetextbutton"></DIV>
      <input type="hidden" name="nodeDns" ID="nodeDns" value="<?php echo $server_nodeDns ?>">
   </FORM>
   <?php
   }

   echo "</td>";
   echo "</tr>";
   echo "</table>";
   
   // online history
   $online_saveTime = $OnlineServers["savetime"]["time"];
   $online_lastseen = $OnlineServers[$sh_host]["time"];
   $online_history  = $OnlineServers[$sh_host]["log"];
/* 
   if ($online_saveTime != $online_lastseen && $online_lastseen!="")
   {
      $timediff = ($online_saveTime - $online_lastseen);
      $minuteLastSave  = (int) intval($timediff / INT_MINUTE);
      $online_history = "-".$minuteLastSave.".".$online_history;
   }
*/
   
   $logtime = explode(".", $online_history);
   $history_off = 0;
   $history_on = 0;
   foreach ($logtime as $log)
   {
      if (strstr($log,"-"))
      {
         $history_off = $history_off + substr($log,1);
      }
      else 	
      {
         $history_on = $history_on + $log;
      }
   } 
	
   $DIV_history_off = "";
   if ($history_off >0) $DIV_history_off = "<FONT color=red>".formatted_timediff($history_off*60)."</FONT>";
	
   $DIV_history_total = formatted_timediff(($history_off + $history_on)*60);
   
   if ($history_off >0)
      format1($generic_lv_uptime,procentColor(procentOnline($sh_host))." [ ".$DIV_history_off." / ".$DIV_history_total." ]");
   else
      format1($generic_lv_uptime,procentColor(procentOnline($sh_host))." [ ".$DIV_history_total." ]");

   // internet service provider info   	
   if ($country_whois == true && $tara_code["tara"]!="<>")
   {
      format1($server_lv_ispinfo,$tara_code["info"]);
   }

   echo "<BR>";
   
   ob_flush();
   flush();

   $LastPingError = $server_lv_lastpingerror;
   $pingCount = 5;
   $pingCountOK = 0;
   $pingLast = 0;
   $pingTimeTotal = 0;
   
   //echo "<table border=0 cellpadding=0 cellspacing=0>";
   $ping_text_try = "";

   // check ping
   $_SERVER['QUERY_STRING'] = "nodeDns=".$sh_host;
   $stringquerry = $_SERVER['QUERY_STRING'];
   if (!strstr($stringquerry,"&checkPing=1")) 
      $stringquerry = $stringquerry."&checkPing=1";
   $ping_text_try_check = "&nbsp;<A class=\"tabel_header\" HREF=".$pagina."?".$stringquerry.">&nbsp;".$server_lv_pingnow."&nbsp;&nbsp;</A>";
   
   $pingTryMax = 0;
   if ($server_checkPing != "")
   {
      for ($k = 1; $k <= $pingCount; $k++) 
      {
         usleep(1000000);
         $pingTry = -1;
         $pingTry = pingDomain($host_IP,$host_PORT,3);
         
         if ($pingTryMax == 0)
            $pingTryMax = $pingTry;
         else
            if ($pingTryMax < $pingTry) $pingTryMax = $pingTry;

         if ($k>1) $ping_text_try = $ping_text_try." , ";
         if ($pingTry>0) 
         {
            $pingCountOK++;
            
            $ping_text_try = $ping_text_try.$pingTry."ms";
         }
         else
         {
            $ping_text_try = $ping_text_try."<FONT color=red>--</FONT>";
            if ($pingLast==-1)
            {
               $pingTimeTotal = -1;
               break;
            }
         }

         $pingTime[] = $pingTry;
         $pingLast = $pingTry; 
      }
      $ping_text_try = " : {".$ping_text_try."}";
   }
   
   //echo "</table>";
   
   $textPingCurent = "";

   if ($pingTimeTotal == 0)
   {
      $lost = $pingCount - $pingCountOK;
      
      $rezultatPing = $ping_text_try_check."<FONT color=gray>".$ping_text_try."</FONT>";
         		
      if ($lost == 0)
      {
      	 for ($k = 0; $k < $pingCount; $k++)
            if ($pingTime[$k] >0) $pingTimeTotal = $pingTimeTotal + $pingTime[$k];
      
      	 $pingTimeTotal = $pingTimeTotal - $pingTryMax;
         $pingTimeFinal = (int)($pingTimeTotal/($pingCountOK-1));
      
      	 SavePing($sh_host,$pingTimeFinal);
      	 $textPingCurent  = " = ".$pingTimeFinal."ms ";
      }
      else
      if ($server_checkPing != "")
      	$textPingCurent  = " = NOT SAVED";
	
   }
   else   
   if ($server_checkPing != "")
   {
      $rezultatPing = $ping_text_try_check.": ".$LastPingError;
   }
   else
      $rezultatPing = $ping_text_try_check;

   // check ports
/*
   $_SERVER['QUERY_STRING'] = "nodeDns=".$sh_host;
   $stringquerry = $_SERVER['QUERY_STRING'];
   if (!strstr($stringquerry,"&checkPort=1"))
      $stringquerry = $stringquerry."&checkPort=1";
*/
   $stringquerry = "nodeDns=".$sh_host."&checkPort=1";
   $port_check = "&nbsp;<A class=\"tabel_header\" HREF=".$pagina."?".$stringquerry.">&nbsp;".$server_lv_scannow."&nbsp;&nbsp;</A>";
/*
   $_SERVER['QUERY_STRING'] = "nodeDns=".$sh_host;
   $stringquerry = $_SERVER['QUERY_STRING'];
   if (!strstr($stringquerry,"&checkPortrecent=1"))
      $stringquerry = $stringquerry."&checkPortrecent=1";
*/
   $stringquerry = "nodeDns=".$sh_host."&checkPortrecent=1";
   $port_check_recent = "&nbsp;<A class=\"tabel_header\" HREF=".$pagina."?".$stringquerry.">&nbsp;".$server_lv_shownow."&nbsp;&nbsp;</A>";
  
   $stringquerry = "nodeDns=".$sh_host."&searchDynDnsonGoogle=1";
   $search_dyndns_on_google = "&nbsp;<A class=\"tabel_header\" HREF=".$pagina."?".$stringquerry.">&nbsp;".$server_lv_dyndns_checknow."&nbsp;&nbsp;</A>";
 
   $bestPingSaved = SavedPing($sh_host);
   
   $textPingAverage = pingResultColor($bestPingSaved[0],1);
   $textPingBest    = pingResultColor($bestPingSaved[2],1);
   
   $diffPing = $bestPingSaved[0] - $bestPingSaved[2];
   $diffMargin = (int)($bestPingSaved[2] * 50/100);
   if ($diffMargin < 50) $diffMargin  = 50;
   
   if ($diffPing > $diffMargin ) $textPingAverage = "<FONT COLOR=red><B>! </B></FONT>".$textPingAverage;
   
   format1($server_lv_besteverresponse." ",$textPingBest);
   format1($server_lv_averageresponse." ",$textPingAverage);
   format1($server_lv_currentresponse." ",$rezultatPing.$textPingCurent);

   // exclude from security check and from Google DynDns check
   if ($use_securitycheck)
   {
      if ($exclude_portcheck != "")
      {
         if ($exclude_portcheck == "yes")
            excludefromPortcheck($sh_host,true,true);
         else if ($exclude_portcheck == "no")
            excludefromPortcheck($sh_host,false,true);
      }
   }

   flush_buffers();

   // check ports
   if($server_checkPort != "")
      checkPorts($sh_host,$nodes["Info"][1],$tara_code["tara"]);


   // determine if server node DynDns address is known by Google
   if($server_search_dyndns_on_google != "")
   {
      list($host_DNS, $host_PORT) = explode(":", $sh_host);

      if (!$use_google_dyndns_check_server_node)
         $host_PORT = "";
/*
      if ($host_PORT > 0)
      {
*/
         if ($floodprotection == "on")
         {
            $gresult = $generic_lv_google_flood_protection;
         }
         else
         {
            $google=YaPSGoogleResult($host_DNS, $host_PORT);

            if ($google == 1 && $google != 2 )
            {
               if ($host_PORT != "")
                  $gresult = "&nbsp;<a href=\"http://www.google.com/search?hl=en&q=%22".urlencode($host_DNS."+".$host_PORT)."%22\" target=\"_blank\"><img border=\"0\" src=\"images/google.png\" title='".$generic_lv_known_by_google."' align='top' width='12' height='12'>&nbsp;<font color=\"red\">".$generic_lv_known_by_google."</font></A>&nbsp;";
               else
                  $gresult = "&nbsp;<a href=\"http://www.google.com/search?hl=en&q=%22".urlencode($host_DNS)."%22\" target=\"_blank\"><img border=\"0\" src=\"images/google.png\" title='".$generic_lv_known_by_google."' align='top' width='12' height='12'>&nbsp;<font color=\"red\">".$generic_lv_known_by_google."</font></A>&nbsp;";
               setKnownByGoogle($sh_host,KNOWN_BY_GOOGLE,true);
            }
            else if ($google == 2)
            {
               $gresult = "&nbsp;".$generic_lv_google_flood_protection."&nbsp;";
               $floodprotection = "on";
            }
            else
            {
               $gresult = "<font color=\"green\">".$generic_lv_not_known_by_google."&nbsp;</font>";
               setKnownByGoogle($sh_host,NOT_KNOWN_BY_GOOGLE,true);
            }
         }
/*
      }
*/
   }

   $security_result = "";
   if(function_exists('checkSecurityAll'))
      $security_result .= linkTag("", $sh_host, "", true, $tara_code["tara"], TAG_SECURITY_PORTSCAN|TAG_SECURITY_PORTSCAN_EXTENDED|TAG_PORTSCAN_EXCLUDED|TAG_PORTSCAN_EXCLUDED_EXTENDED|TAG_LOCAL_IP|TAG_LOCAL_IP_EXTENDED|TAG_KNOWN_BY_GOOGLE|TAG_KNOWN_BY_GOOGLE_EXTENDED);
   else
      $security_result .= linkTag("", $sh_host, "", true, $tara_code["tara"], TAG_SECURITY_PORTSCAN|TAG_SECURITY_PORTSCAN_EXTENDED|TAG_LOCAL_IP|TAG_LOCAL_IP_EXTENDED|TAG_KNOWN_BY_GOOGLE|TAG_KNOWN_BY_GOOGLE_EXTENDED);
   echo "<br>";
   format1($server_lv_security_check_result,"",-1,false);
   echo $security_result."<br>";

   if ($use_securitycheck)
   {
      echo "<table border=0 cellpadding=0 cellspacing=0>";
      echo "<tr>";
      echo "<td style=\"height:18px\">";
      echo $server_lv_recent_portcheck_result." : ";
      echo "</td>";
      echo "<td>";
      echo "<B><FONT COLOR=white>".$port_check_recent."</FONT></B>";
      echo "</td>";
      echo "</tr>";
      echo "<tr>";
      echo "<td style=\"height:18px\">";
      echo $server_lv_securitycheck_portscan." : ";
      echo "</td>";
      echo "<td>";
      echo "<B><FONT COLOR=white>".$port_check."</FONT></B>";
      echo "</td>";
      echo "</tr>";

      // Google DynDns check
      if ($use_google_dyndns_check && $tara_code["tara"] != "<>")
      {
         echo "<tr>";
         echo "<td>";
         echo $server_lv_securitycheck_dyndns." : ";
         echo "</td>";
         echo "<td>";
         echo "<B><FONT COLOR=white>".$search_dyndns_on_google."</FONT></B>";
         echo "</td>";
         echo "</tr>";
      }

      echo "<tr>";
      echo "<td></td>";

      // exclude from security check and from Google DynDns check form
      if ($tara_code["tara"] != "<>" && function_exists('checkSecurityAll'))
      {
         echo "<td>";
?>
<FORM NAME="excludeForm" METHOD="GET" ACTION="
<?php
         echo $pagina;
?>
"><input type="checkbox" valign="center" name="excludeportscan" value="yes" onclick=doExclude("<?php echo $pagina."?nodeDns=".$sh_host ?>") 
<?php
         if (isExludedfromPortcheck($sh_host))   echo "checked";
?>
> 
<?php
         echo $server_lv_cron_exclude;
?>
</FORM>
<?php
         echo "</td>";
      }

      echo "</tr>";
      echo "</table>";

      // show portcheck results
      if($server_checkPort != "" || $server_checkPort_recent != "")
         showPortCheckResult($sh_host,$nodes["Info"][1]);

      // show if server node DynDns address is known by Google
      if($server_search_dyndns_on_google != "")
      {
         format1($server_lv_dyndns_check_result,"",-1,false);
         echo "<table border=0 cellpadding=2 cellspacing=1>";
         echo "<tr>";
         echo "<th class=\"tabel_headerc\">#</th>";
         echo "<th class=\"tabel_header\">Server</th>";
         echo "<th class=\"tabel_headerc\">Status</th>";
         echo "</tr>";
         echo "<tr>";
         echo "<td class=\"Node_count\">1</td>";
         echo "<td class=\"Node_ID\">".$sh_host."&nbsp;&nbsp;&nbsp;</td>";
         echo "<td class=\"Node_ID\" style=\"text-align:center\">".$gresult."</td>";
         echo "</tr>";
         echo "</table>";
      }
   }

   // CCcam web interface link
   $nodetype = $nodes["Info"][1];
   if ($use_cccam_webif && $nodetype == "CCcam-s2s")
   {
      if (!$only_local_ip || ($only_local_ip && $tara_code["tara"] == "<>"))
      {
         echo "<br>CCcam Web Interface Link<br>";
         echo "<table border=0 cellpadding=2 cellspacing=1>";
         echo "<tr>";
         echo "<th class=\"tabel_headerc\">#</th>";
         echo "<th class=\"tabel_header\">".$generic_lv_cccam_webif_link."</th>";
         echo "<th class=\"tabel_header\">".$generic_lv_webif_link_status."</th>";
         echo "</tr>";
         echo "<td class=\"Node_count\">1</td>";

         // web interface link for CCcam-s2s nodes

         $webif_link_saved = "";
         $webif_link_save_path = $cccam_host."/webiflinks/".$host_DNS.".".$host_PORT.".CCcam-s2s.server.link";

         if (file_exists($webif_link_save_path))
         {
            $fh = fopen($webif_link_save_path, 'r');
            $webif_link_saved = fread($fh, filesize($webif_link_save_path));
            fclose($fh);
         }
         if ($webif_link_saved != "")
         {
            $weblink = explode(":",$webif_link_saved);
            $webhost_IP = ltrim($weblink[1], "/");
            $webhost_PORT = $weblink[2];
            $webinterface = pingDomain($webhost_IP,$webhost_PORT,1);

            if ($webinterface!=-1)
            {
               if ($use_webif_tag)
                  $webinterface_status = "<img border='0' src='images/webif_available.png' align='top' title='".$generic_lv_cccam_webif_available."'>";
               else
                  $webinterface_status = "<FONT COLOR='green'><b>(".$generic_lv_cccam_webif_available.")</b></FONT>";
            }
            else
            {
               if ($use_webif_tag)
                  $webinterface_status = "<img border='0' src='images/webif_unavailable.png' align='top' title='".$generic_lv_cccam_webif_not_available."'>";
               else
                  $webinterface_status = "<FONT COLOR='red'><b>(".$generic_lv_cccam_webif_not_available.")</b></FONT>";
            }
            echo "<td class=\"WebIf_Link\"><A HREF=".$webif_link_saved.">".$webhost_IP.":".$webhost_PORT."</A></td>";
            echo "<td class=\"WebIf_Link\">".$webinterface_status."</td>";
         }
         else
         {
            echo "<td class=\"WebIf_Link\"><FONT COLOR=red>".$generic_lv_cccam_webif_link_not_defined."</FONT></td>";
            echo "<td class=\"WebIf_Link\">";
            if ($use_webif_tag)
               echo "<img border='0' src='images/webif_disabled.png' align='top' title='".$generic_lv_cccam_webif_link_not_defined."'>";
            echo "</td>";

            if ($tara_code["tara"] == "<>")
               $http_DNS = $host_IP;
            else
               $http_DNS = $host_DNS;

            $webif_link_saved = "http://".$http_DNS.":";
         }
         echo "</table>";

         echo "<br>";
         echo "<SPAN onclick='toggleDisplay(\"".$idtable['CCCAMWEBIF']."\");' style='cursor:hand;'><FONT COLOR='white'>".$generic_lv_define_cccam_webif_link."</FONT> <img border=\"0\" src=\"images/arrow.gif\"  width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
         echo "<table id=\"".$idtable['CCCAMWEBIF']."\" style='display:none;' border=0 cellpadding=4 cellspacing=0>";
         echo "<tr><td>";
//         echo "<br>";
         ?>
         <FORM NAME="formularcccamwebif" METHOD="post" ACTION="
         <?php
         echo $pagina;
         ?>
         "><TEXTAREA CLASS="TEXTAREANORMAL" COLS="60" name="saveCCcamWebIfLink" ID="saveCCcamWebIfLink" ROWS="2" TABINDEX="1" value=""><?php echo $webif_link_saved ?></TEXTAREA>
         <DIV ALIGN = "right"><INPUT TYPE="submit" VALUE=<?php echo $server_lv_save?> TABINDEX="2" class="savetextbutton"></DIV>
            <input type="hidden" name="nodeDns" ID="nodeDns" value="<?php echo $server_nodeDns ?>">
         </FORM>
         <?php

         echo "</td></tr>";
         echo "</table>";
         echo "<br>";
      }
   }

   //format1("Unique",$info_total_unic,$info_total);
   //format1("Reshare",$info_total_reshare,$info_total_unic);

   $ecm_total = 0;
   $ecmOK_total = 0;
   foreach ($servers[$sh_host]["Info"]["Idents"] as $hit_data)
   {
      $hit_array = explode(" ",$hit_data);
      if ($hit_array[0] != "")
      {
         $hit_provider = explode(":",$hit_array[1]);
         $hit_exact = explode("(",$hit_array[2]);
         $hit_exact2 = explode(")",$hit_exact[1]);
         
         $hit_ecm = $hit_exact[0];
         $hit_ecmOK = $hit_exact2[0];
         
         $ecm_total = $ecm_total+$hit_ecm;
         $ecmOK_total = $ecmOK_total+$hit_ecmOK;
         
         $key = adaug0($hit_ecmOK,20).adaug0($hit_ecm,20).$hit_array[1];
         $ecmok_sortat[$key] = $hit_data;
      }
   }
   loadECMServers(true);
   echo "<BR>";   
   $record_ECM = $ECMservers[$sh_host]["Info"]["ECM_SAVED"]["ECM"];
   $record_ECMOK = $ECMservers[$sh_host]["Info"]["ECM_SAVED"]["ECMOK"];
   
   if (($ecm_total == $record_ECM) && ($ecmOK_total == $record_ECMOK))
      format1($server_lv_handledecm,$record_ECMOK,$record_ECM);
   else
   {
      if ($record_ECM !="")
         format1($server_lv_handledecmsaved,$record_ECMOK,$record_ECM);
         
      format1($server_lv_handledecmnow,$ecmOK_total,$ecm_total);
   }
   
   if ($ecm_total)
   {
      // echo "<BR>"; 
      echo "<table border=0 cellpadding=2 cellspacing=1>";
      echo "<tr>";
      echo "<th class=\"tabel_headerc\">#</th>";
      echo "<th class=\"tabel_headerc\">".$generic_lv_type."</th>";
      echo "<th class=\"tabel_header\">ECM</th>";
      echo "<th class=\"tabel_header\">OK</th>";
      echo "<th class=\"tabel_header\">".$generic_lv_caidident."</th>";
      echo "</tr>";
   }
   
   if (isset($ecmok_sortat))
   {
      krsort($ecmok_sortat);

      $counthits = 0;
      if ($ecmok_sortat)
         foreach ($ecmok_sortat as $key => $hit_data)
         {
            $hit_array = explode(" ",$hit_data);
            if ($hit_array[0] != "")
            {
               $counthits++;
               $hit_provider = explode(":",$hit_array[1]);
               $hit_exact = explode("(",$hit_array[2]);
               $hit_exact2 = explode(")",$hit_exact[1]);

               $hit_ecm = $hit_exact[0];
               $hit_ecmOK = $hit_exact2[0];

               echo "<tr>";
               echo "<td class=\"Node_Provider\">".$counthits."</td>";
               echo "<td class=\"tabel_hop_total1\">".$hit_array[0]."</td>";

               echo "<td class=\"tabel_hop_total\"><FONT COLOR=white>".$hit_ecm."</FONT></td>";

               if ($hit_ecmOK == 0)
                  echo "<td class=\"tabel_hop_total\"><FONT COLOR=red>".$hit_ecmOK."</FONT></td>";
               else
               if ($hit_ecmOK != $hit_ecm)  echo "<td class=\"tabel_hop_total\"><FONT COLOR=yellow>".$hit_ecmOK."</FONT></td>";
               else
                  echo "<td class=\"tabel_hop_total\">".$hit_ecmOK."</td>";
         
               echo "<td class=\"Node_Provider\">".Providerid($hit_provider[0],$hit_provider[1],true,"Node_Provider",false)."</td>";
               echo "</tr>";
            }
         }
   }
	
   if ($ecm_total)
      echo "</table>";
   echo "<BR>";
   
   $total_nodes = 0;
   for($k = 0; $k <= $maxhop; $k++)
   {
      if (isset($total_host_shares[$sh_host][$k]))
         $total_nodes += $total_host_shares[$sh_host][$k];
   }

   if ($total_nodes>0)
   {
      format1($generic_lv_nodes,$info_total_unic);
      echo "<table border=0 cellpadding=2 cellspacing=1>";
      echo "<tr>";
      echo "<th class=\"tabel_headerc\">#</th>";
      echo "<th class=\"tabel_header\">".$server_lv_nodeidserver."</th>";
      echo "<th class=\"tabel_header\">".$generic_lv_shares."</th>";

      for ($k = 1; $k <= $maxhop; $k++) echo "<th class=\"tabel_headerc\">hop".$k."</th>"; 
      echo "<th class=\"tabel_headerc\">".$generic_lv_reshare."</th>";
      echo "<th class=\"tabel_header\">".$generic_lv_caididents."</th>";
      echo "</tr>";
   
      //$info_total = $total_host_shares[$sh_host]["total"];
      //$info_total_unic = count($nodes) - 1;
      //$info_uniqueIndex = (int)($info_total_unic/$info_total *100);
      //$info_total_reshare = $total_reshare[$sh_host]["total"];
      //$info_reshareIndex = (int)($info_total_reshare/$info_total_unic *100);
   
      echo "<tr>";
      echo "<td class=\"tabel_total\"></td>";
      echo "<td class=\"tabel_total\"></td>";
      echo "<td class=\"tabel_total\">".$total_host_shares[$sh_host]["total"]."</td>";
      for ($k = 1; $k <= $maxhop; $k++) echo "<td class=\"tabel_total\">".$total_host_shares[$sh_host][$k]."</td>"; 
      echo "<td class=\"tabel_total\">".$total_reshare[$sh_host]["total"]."</td>";
      echo "<td class=\"tabel_total\"></td>";
      echo "</tr>";
   
      $i=1;
   
      // HOP1
      if (isset($total_shares[1]))
         foreach ($nodes as $node=>$data) 
            if (!isset($host_hop[$sh_host][$node][0]) && isset($host_hop[$sh_host][$node][1]))
            {
               $nodetype = $nodes[$node][0][1];
               $caid = $nodes[$node][0][2];
               $providers = $nodes[$node][0][4];
               $nodSh = explode("|",$node);  
      
               $total = 0;for($k = 0; $k <= $maxhop; $k++) 
               if (isset($host_hop[$sh_host][$node][$k]))
                  $total += $host_hop[$sh_host][$node][$k];
      
               $reshare = "<FONT COLOR=red>! ".$generic_lv_noreshare." !</FONT>";if ($re[$sh_host][$node]["reshare"] >0) if ($total==1) $reshare = $re[$sh_host][$node]["reshare"]; else $reshare = "<FONT COLOR=yellow>".$re[$sh_host][$node]["reshare"]."</FONT>";

               echo "<tr>";
               echo "<td class=\"Node_Count\">".$i."</td>";

               echo "<td class=\"Node_ID_hop1\">".nodeID($node,$sh_host,$total,1)."</td>";
               echo "<td class=\"tabel_total\">".$total."</td>";

               for ($k = 1; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     echo "<td class=\"tabel_hop\">".$host_hop[$sh_host][$node][$k]."</td>";
                  else
                     echo "<td class=\"tabel_hop\"></td>";
      
               echo "<td class=\"tabel_total\">".$reshare."</td>";
               echo "<td class=\"Node_Provider\">".providerID($caid,$providers,true,"Node_Provider",false)."</td>";
               echo "</tr>";
               $i++;
            }

      // HOP2
      if (isset($total_shares[2]))
         foreach ($nodes as $node=>$data) 
            if (!isset($host_hop[$sh_host][$node][0]) && !isset($host_hop[$sh_host][$node][1]) && isset($host_hop[$sh_host][$node][2]))
            {
               $nodetype = $nodes[$node][0][1];
               $caid = $nodes[$node][0][2];
               $providers = $nodes[$node][0][4];
               $nodSh = explode("|",$node);  

               $total = 0;
               for($k = 0; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     $total += $host_hop[$sh_host][$node][$k];
            
               $reshare = "<FONT COLOR=red>! ".$generic_lv_noreshare." !</FONT>";if ($re[$sh_host][$node]["reshare"] >0) if ($total==1) $reshare = $re[$sh_host][$node]["reshare"]; else $reshare = "<FONT COLOR=yellow>".$re[$sh_host][$node]["reshare"]."</FONT>";
      
               echo "<tr>";
               if (strstr($node,"*"))
                  echo "<td class=\"tabel_normal_type\">".$i."</td>";
               else
                  echo "<td class=\"Node_Count\">".$i."</td>";

               echo "<td class=\"Node_ID_hop2\">".nodeID($node,$sh_host,$total,2)."</td>";
               echo "<td class=\"tabel_total\">".$total."</td>";

               for ($k = 1; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     echo "<td class=\"tabel_hop\">".$host_hop[$sh_host][$node][$k]."</td>";
                  else
                     echo "<td class=\"tabel_hop\"></td>";
            
               echo "<td class=\"tabel_total\">".$reshare."</td>";
               echo "<td class=\"Node_Provider\">".providerID($caid,$providers,true,"Node_Provider",false)."</td>";
               echo "</tr>";
               $i++;
            }
   
      // HOP3
      if (isset($total_shares[3]))
         foreach ($nodes as $node=>$data) 
            if (!isset($host_hop[$sh_host][$node][0]) && !isset($host_hop[$sh_host][$node][1]) && !isset($host_hop[$sh_host][$node][2]) && isset($host_hop[$sh_host][$node][3]))
            {
               $nodetype = $nodes[$node][0][1];
               $caid = $nodes[$node][0][2];
               $providers = $nodes[$node][0][4];
               $nodSh = explode("|",$node);
      
               $total = 0;
               for($k = 0; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     $total += $host_hop[$sh_host][$node][$k];
            
               $reshare = "<FONT COLOR=red>! ".$generic_lv_noreshare." !</FONT>";if ($re[$sh_host][$node]["reshare"] >0) if ($total==1) $reshare = $re[$sh_host][$node]["reshare"]; else $reshare = "<FONT COLOR=yellow>".$re[$sh_host][$node]["reshare"]."</FONT>";

               echo "<tr>";
               if (strstr($node,"*"))
                  echo "<td class=\"tabel_normal_type\">".$i."</td>";
               else
                  echo "<td class=\"Node_Count\">".$i."</td>";
               echo "<td class=\"Node_ID_hop3\">".nodeID($node,$sh_host,$total,3)."</td>";
               echo "<td class=\"tabel_total\">".$total."</td>";

               for ($k = 1; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     echo "<td class=\"tabel_hop\">".$host_hop[$sh_host][$node][$k]."</td>";
                  else
                     echo "<td class=\"tabel_hop\"></td>";
            
               echo "<td class=\"tabel_total\">".$reshare."</td>";
               echo "<td class=\"Node_Provider\">".providerID($caid,$providers,true,"Node_Provider",false)."</td>";
               echo "</tr>";
               $i++;
            }

      // HOP4
      if (isset($total_shares[4]))
         foreach ($nodes as $node=>$data) 
            if (!isset($host_hop[$sh_host][$node][0]) && !isset($host_hop[$sh_host][$node][1]) && !isset($host_hop[$sh_host][$node][2]) && !isset($host_hop[$sh_host][$node][3]) && isset($host_hop[$sh_host][$node][4]))
            {
               $nodetype = $nodes[$node][0][1];
               $caid = $nodes[$node][0][2];
               $providers = $nodes[$node][0][4];
               $nodSh = explode("|",$node);

               $total = 0;
               for($k = 0; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     $total += $host_hop[$sh_host][$node][$k];

               $reshare = "<FONT COLOR=red>! ".$generic_lv_noreshare." !</FONT>";if ($re[$sh_host][$node]["reshare"] >0) if ($total==1) $reshare = $re[$sh_host][$node]["reshare"]; else $reshare = "<FONT COLOR=yellow>".$re[$sh_host][$node]["reshare"]."</FONT>";

               echo "<tr>";
               if (strstr($node,"*"))
                  echo "<td class=\"tabel_normal_type\">".$i."</td>";
               else
                  echo "<td class=\"Node_Count\">".$i."</td>";
               echo "<td class=\"Node_ID_hop4\">".nodeID($node,$sh_host,$total,4)."</td>";
               echo "<td class=\"tabel_total\">".$total."</td>";

               for ($k = 1; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     echo "<td class=\"tabel_hop\">".$host_hop[$sh_host][$node][$k]."</td>";
                  else
                     echo "<td class=\"tabel_hop\"></td>";
            
               echo "<td class=\"tabel_total\">".$reshare."</td>";
               echo "<td class=\"Node_Provider\">".providerID($caid,$providers,true,"Node_Provider",false)."</td>";
               echo "</tr>";
               $i++;
            }

      // HOP5 sau mai mult
      foreach ($nodes as $node=>$data) 
         if ($node != "Info")
            if (!isset($host_hop[$sh_host][$node][0]) && !isset($host_hop[$sh_host][$node][1]) && !isset($host_hop[$sh_host][$node][2]) && !isset($host_hop[$sh_host][$node][3]) && !isset($host_hop[$sh_host][$node][4]))
            {
               $nodetype = $nodes[$node][0][1];
               $caid = $nodes[$node][0][2];
               $providers = $nodes[$node][0][4];
               $nodSh = explode("|",$node);

               $total = 0;
               for($k = 0; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     $total += $host_hop[$sh_host][$node][$k];

               $reshare = "<FONT COLOR=red>! ".$generic_lv_noreshare." !</FONT>";if ($re[$sh_host][$node]["reshare"] >0) if ($total==1) $reshare = $re[$sh_host][$node]["reshare"]; else $reshare = "<FONT COLOR=yellow>".$re[$sh_host][$node]["reshare"]."</FONT>";

               echo "<tr>";
               if (strstr($node,"*"))
                  echo "<td class=\"tabel_normal_type\">".$i."</td>";
               else
                  echo "<td class=\"Node_Count\">".$i."</td>";
               echo "<td class=\"Node_ID_hop5\">".nodeID($node,$sh_host,$total,5)."</td>";
               echo "<td class=\"tabel_total\">".$total."</td>";

               for ($k = 1; $k <= $maxhop; $k++) 
                  if (isset($host_hop[$sh_host][$node][$k]))
                     echo "<td class=\"tabel_hop\">".$host_hop[$sh_host][$node][$k]."</td>";
                  else
                     echo "<td class=\"tabel_hop\"></td>";
            
               echo "<td class=\"tabel_total\">".$reshare."</td>";
               echo "<td class=\"Node_Provider\">".providerID($caid,$providers,true,"Node_Provider",false)."</td>";
               echo "</tr>";
               $i++;
            }
   
      echo "</table>";
   }

   // web interface link for newcamd and camd3 nodes
   $nodetype = $nodes["Info"][1];

   if ($use_webif_link && ($nodetype == "newcamd" || $nodetype == "camd3"))
   {
      echo "<br>NewCS/OSCam/SBox Web Interface Link<br>";
      echo "<table border=0 cellpadding=2 cellspacing=1>";
      echo "<tr>";
      echo "<th class=\"tabel_headerc\">#</th>";
      echo "<th class=\"tabel_header\">".$generic_lv_newcs_webif_link."</th>";
      echo "<th class=\"tabel_header\">".$generic_lv_webif_link_status."</th>";
      echo "</tr>";
      echo "<td class=\"Node_count\">1</td>";

      $webif_link_saved = "";
      $webif_link_save_path   = $cccam_host."/webiflinks/".$host_DNS.".".$host_PORT.".newcamd.link";
   
      if (file_exists($webif_link_save_path))
      {
         $fh = fopen($webif_link_save_path, 'r');
         $webif_link_saved = fread($fh, filesize($webif_link_save_path));
         fclose($fh);
      }
      if ($webif_link_saved != "")
      {
         $weblink = explode(":",$webif_link_saved);
         $webhost_PORTPARAMS = explode("?", $weblink[2]);
         $webhost_PORT = $webhost_PORTPARAMS[0];

         if ($tara_code["tara"] == "<>")
            $webhost_DNS = $host_DNS;
         else
	    $webhost_DNS = ltrim($weblink[1], "/");

         $webinterface = pingDomain($webhost_DNS,$webhost_PORT,1);

         if ($webinterface!=-1)
         {
            if ($use_webif_tag)
               $webinterface_status = "<img border='0' src='images/webif_available.png' align='top' title='".$generic_lv_newcamd_webif_available."'>";
            else
               $webinterface_status = "<FONT COLOR='green'><b>(".$generic_lv_newcamd_webif_available.")</b></FONT>";
         }
         else
         {
            if ($use_webif_tag)
               $webinterface_status = "<img border='0' src='images/webif_unavailable.png' align='top' title='".$generic_lv_newcamd_webif_not_available."'>";
            else
               $webinterface_status = "<FONT COLOR='red'><b>(".$generic_lv_newcamd_webif_not_available.")</b></FONT>";
         }
         echo "<td class=\"WebIf_Link\"><A HREF=".$webif_link_saved.">".$webhost_DNS.":".$webhost_PORT."</A></td>";
         echo "<td class=\"WebIf_Link\">".$webinterface_status."</td>";
      }
      else
      {
         echo "<td class=\"WebIf_Link\"><FONT COLOR=red>".$generic_lv_newcamd_webif_link_not_defined."</FONT></td>";
         echo "<td class=\"WebIf_Link\">";
         if ($use_webif_tag)
            echo "<img border='0' src='images/webif_disabled.png' align='top' title='".$generic_lv_newcamd_webif_link_not_defined."'>";
         echo "</td>";

         if ($tara_code["tara"] == "<>")
            $http_DNS = $host_IP;
         else
            $http_DNS = $host_DNS;

         $webif_link_saved = "http://".$http_DNS.":";
      }
      echo "</table>";

      echo "<br>";
      echo "<SPAN onclick='toggleDisplay(\"".$idtable['NEWCAMDWEBIF']."\");' style='cursor:hand;'><FONT COLOR='white'>".$generic_lv_define_newcs_webif_link."</FONT> <img border=\"0\" src=\"images/arrow.gif\"  width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
      echo "<table id=\"".$idtable['NEWCAMDWEBIF']."\" style='display:none;' border=0 cellpadding=4 cellspacing=0>";

      echo "<br>";
      echo "<tr><td>";
      ?>
      <FORM NAME="formularwebif" METHOD="post" ACTION="
      <?php
      echo $pagina;
      ?>
      "><TEXTAREA CLASS="TEXTAREANORMAL" COLS="60" name="saveWebIfLink" ID="saveWebIfLink" ROWS="2" TABINDEX="1" value=""><?php echo $webif_link_saved ?></TEXTAREA>
      <DIV ALIGN = "right"><INPUT TYPE="submit" VALUE=<?php echo $server_lv_save?> TABINDEX="2" class="savetextbutton"></DIV>
         <input type="hidden" name="nodeDns" ID="nodeDns" value="<?php echo $server_nodeDns ?>">
      </FORM>
      <?php

      echo "</td></tr>";
      echo "</table>";
      echo "<br>"; 
   }
}

ENDPage();
?>
