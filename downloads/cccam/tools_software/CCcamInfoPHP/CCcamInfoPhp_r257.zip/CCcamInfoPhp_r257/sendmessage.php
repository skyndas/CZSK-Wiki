<html>

<head> 

</head> 
 
<BODY>

<script language=javascript> 
	function confirmsendmessage(messagetext)
	{
		alert(messagetext);
 		location.href="clientstats.php";
	}
</script> 

<?php include "common.php"?>
<?php
	include "meniu.php";	

	$fromhost = $_GET['fromhost'];
	$toclient = $_GET['toclient'];
	$messagetext = $_GET['message'];
	$messagetext = $sendmessage_lv_from.": ".$fromhost.": ".$messagetext;
	$messagetext = str_replace(" ","%20",$messagetext);		

	$sendtoclient = "";
		
	$messagesent = false;
	$messageerror = false;
	
	$index=-1;
	$found=false;
	$myfile="config.php";
	if (file_exists($myfile))
	{
		$seek_line = "\$server_username";
		$config_data = file ($myfile);
		foreach ($config_data as $currentline) 
		{
			$index++;
			if (strstr($currentline,$seek_line))
			{
				$found=true;
				$config_data[$index]=$seek_line." = "."\"".$fromhost."\";"."\n";
			}
		}
		
		if ($found == false)
		{
			echo "Upssss!!! config.php is corrupt! \$server_username is missing. Please, re-install the application";
			exit;
		}
		
		$fh = fopen($myfile, 'w') or die("can't open file");
		foreach ($config_data as $currentline) 
		{
			fwrite($fh, $currentline);
		}
		fclose($fh);	
	
		echo "<FONT COLOR=yellow>".$sendmessage_lv_from.":</FONT><br>".$fromhost;
		echo "<br>";
		echo "<FONT COLOR=yellow>".$sendmessage_lv_message.":</FONT><br>".str_replace("%20"," ",$messagetext);
		echo "<br><br>";
		
		if ($toclient == "ALL")
		{
			echo "<FONT COLOR=yellow>".$sendmessage_lv_messagetoall."</FONT><br>";
		}
		else
		{
			echo "<FONT COLOR=yellow>".$sendmessage_lv_messagetoclients."</FONT><br>";
		}
		echo "<br>";
		
		checkFile($clients_file);
		$clients_data = file ($clients_file);
		loadUsageData();
		
		foreach ($clients_data as $currentline) 
		{
			$inceput1 = substr($currentline,0,1);
			$inceput2 = substr($currentline,1,2);
			if (strstr($currentline,"| Shareinfo")) break; 	
	
			if ($inceput1 == "|" && $inceput2 != " U")
			{
				$active_client 		= explode("|", $currentline);
				$ac_Username 			= trim($active_client[1]);
				$ac_IP 					= trim($active_client[2]);
				$ac_Connected 			= trim($active_client[3]);
				$ac_Idle 				= trim($active_client[4]);
				$ac_ECM 				= trim($active_client[5]);
				$ac_EMM 				= trim($active_client[6]);
				$ac_Version				= trim($active_client[7]);
				$ac_LastShare			= trim($active_client[8]);
				
				$clientConectat[$ac_Username]["Info"] = array ($ac_IP,$ac_Connected,$ac_Idle,$acEcm,$acEcmOk,$acEmm,$acEmmOk,$ac_Version,$ac_LastShare,$ac_EcmTime);  
				tara($ac_IP,$ac_Username);
				
				$sendtoclient = $toclient;
				$process = false;
				if ($toclient == "ALL")
				{
					$sendtoclient = $ac_IP;
					$process = true;
				}
				elseif ($ac_IP == $toclient)
				{
					$process = true;
				}
	
				if ($process == true)
				{					
					
					$index = seek_client($clientmessageport, $ac_Username);
	
					if ($index == -1)
					{
						$clientport = "";
						$clientusername = "";
						$clientpassword = "";
					}
					else
					{
						$clientport = $clientmessageport[$index][1];
						$clientusername = $clientmessageport[$index][2];
						$clientpassword = $clientmessageport[$index][3];
					}
					
					if ($clientport != "" )
					{
						echo $sendmessage_lv_to.":&nbsp".$ac_Username."&nbsp=>&nbsp";
	
						if ($clientusername == "")
							$command = "http://".$sendtoclient.":".$clientport."/cgi-bin/xmessage?caption=Info&timeout=0&body=".$messagetext;	//Enigma1 without authentication
						else
							$command = "http://".$clientusername.":".$clientpassword."@".$sendtoclient.":".$clientport."/cgi-bin/xmessage?caption=Info&timeout=0&body=".$messagetext;	//Enigma1 with authentication
							
						echo $sendmessage_lv_messageE1."...";
	
						flush();
						$var = file_get_contents("$command");
						if ($var ==true)
						{
							$messagesent = true;
							echo ":&nbsp<FONT COLOR=green>".$sendmessage_lv_messagesent.".</FONT>";
						}
						else
						{
							if ($clientusername == "")
								$command = "http://".$sendtoclient.":".$clientport."/web/message?text=".$messagetext."&type=3&timeout=0";	//Enigma2 without authentication
							else
								$command = "http://".$clientusername.":".$clientpassword."@".$sendtoclient.":".$clientport."/web/message?text=".$messagetext."&type=3&timeout=0";	//Enigma2 with authentication
	
							echo ":&nbsp<FONT COLOR=red>".$sendmessage_lv_errorE1."</FONT>,&nbsp".$sendmessage_lv_tryingE2."...";
							flush();
							$var = file_get_contents("$command");
							if ($var ==true)
							{
								$messagesent = true;
								echo ":&nbsp<FONT COLOR=green>".$sendmessage_lv_messagesent.".</FONT>";
							}
							else
							{
								$messageerror = true;
								echo ":&nbsp<FONT COLOR=red>".$sendmessage_lv_messagenotsent.".</FONT>";	
							}
	
						}
										
						echo "<br>";					
						flush();
					}
	
				}
			}
		}
	
		$messagetext = $sendmessage_lv_messagesent.".";
		
		if ($messagesent == true)
		{
			if ($messageerror == true)
				$messagetext = $sendmessage_lv_messagesentwitherrors.".";
		}
		else
			$messagetext = $sendmessage_lv_messagenotsent.".";
			
		echo "<br>";
		flush();
		echo "<script language=javascript>confirmsendmessage('$messagetext')</script>";

	}
?>
  
<BR></BODY></HTML>


