<?php
//---------------------------------------
// CONFIG User specific
//
// Important: rename this file to config_userspecific.php!
//
//---------------------------------------

define('CONFIG_USERSPECIFIC',"config_userspecific.php");

//examples of server definitions
$CCCamWebInfo[] = array("server","16001","cccam","password","/var/etc","/var/keys","ftpuser","ftppassword");	// for CCcam webinterface with user and pass

$work_path = "";							// set this if you want working folder separate
									// Example $work_path = "/tmp/";

$clientmessageport[] = array("","","","");

//-------- EMBEDDED WEBSERVER : START
$use_embedded_webserver = false;					// set to true if you use an embedded webserver under windows
//-------- EMBEDDED WEBSERVER : END

?>

