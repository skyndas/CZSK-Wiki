<html>

<head> 

</head> 
 
<BODY>

<script language=javascript> 
	function trim(string)
	{
		while(string.substr(0,1)==" ")
			string = string.substring(1,string.length) ;
		
		while(string.substr(string.length-1,1)==" ")
			string = string.substring(0,string.length-2) ;
		
		return string;
	}
		
	function SaveClientParam(client)
	{
		port = trim(document.all("clientport").value);
		user = trim(document.all("clientusername").value);
		password = trim(document.all("clientpassword").value);
		
		location.href="configserver.php?profile=client&server=" + client + "&port=" + port + "&user=" + user + "&pass=" + password;	
	}

	function setFocus()
	{
		document.clientparam.clientport.focus();
	}

</script> 

<?php

   if ($use_jump_to_top)
   {
?>
<script type="text/javascript" src="javascript/jumptop.js"></script>
<?php
   }

   checkFile($clients_file);
   
   if (file_exists($clients_file))
      $clients_data = file ($clients_file);
      
   if (!isset($clients_data))
   {
      echo "<FONT COLOR=red>".$generic_lv_serverdown." !</FONT>";
      exit;
   }

	loadUsageData();	
   
   //___________________________________________________________________________________________________
   
   $user_shareinfo = false;
   $lastUsername = "";
   foreach ($clients_data as $currentline) 
	{
		$inceput1 = substr($currentline,0,1);
		$inceput2 = substr($currentline,1,2);
		
		
		if (strstr($currentline,"| Shareinfo")) 
			$user_shareinfo = true;

		if ($user_shareinfo == false && $inceput1 == "|" && $inceput2 != " U")
		{
			$active_client 		= explode("|", $currentline);
			$ac_Username 			= trim($active_client[1]);
			$ac_IP 					= trim($active_client[2]);
			$ac_Connected 			= trim($active_client[3]);
			$ac_Idle 				= trim($active_client[4]);
			$ac_ECM 					= trim($active_client[5]);
			$ac_EMM 					= trim($active_client[6]);
			$ac_Version				= trim($active_client[7]);
			$ac_LastShare			= trim($active_client[8]);
			
			$ac_EcmTime	= "";  
			if (isset($active_client[9]))	
				$ac_EcmTime	= trim($active_client[9]);
			
			list($acEcm,$acEcmOk) = explode("(", $ac_ECM);
			list($acEcmOk,$temp) = explode(")", $acEcmOk);
			
			list($acEmm,$acEmmOk) = explode("(", $ac_EMM);
			list($acEmmOk,$temp) = explode(")", $acEmmOk);
			
			$clientConectat[$ac_Username]["Info"] = array ($ac_IP,$ac_Connected,$ac_Idle,$acEcm,$acEcmOk,$acEmm,$acEmmOk,$ac_Version,$ac_LastShare,$ac_EcmTime);  
			tara($ac_IP,$ac_Username);
			
		}
		else
		if ($user_shareinfo == true && $inceput1 == "|" )
		{
			$share_client 		= explode("|", $currentline);
			$share_Username 	= trim($share_client[1]);
			$share_Idents 	   = trim($share_client[2]);
			
			if ($share_Username!="")
				$lastUsername = $share_Username;
				
			$clientConectat[$lastUsername]["Info"]["Idents"][] = $share_Idents;  
			//echo "<BR>".$lastUsername."-".$share_Idents;
			
		} 
	}
	
	//___________________________________________________________________________________________________

   if (!isset($clientConectat[$username]))
   {
   	format1($generic_lv_connected,$client_lv_offline);
   }
   else
   {
   	
   	$username_IP = $clientConectat[$username]["Info"][0]; 
   	$tara_user  = taraNameSaved($username);
   	$tara_code  = tara($username_IP,$username);
   	if ($country_whois == true) 
      	$tara_nume = taraName($tara_code["tara"]);
   
      format1($generic_lv_username,$username." (".$username_IP.")");

      $reverseDNS = gethostbyaddr($username_IP);

      if ($reverseDNS != $username_IP)
           format1($server_lv_reverse_lookup,$reverseDNS);
      else
           format1($server_lv_reverse_lookup,"<FONT color=red>missing</FONT>");

      if ($country_whois == true)
	   {
	      if ($tara_code["tara"]!="<>")
              {
                 if ($use_country_flags && file_exists($country_flags_path.$tara_code["tara"].".gif"))
                    format2($generic_lv_country,$tara_code["tara"],$tara_nume);
                 else
                    format1($generic_lv_country,$tara_code["tara"]." , ".$tara_nume);
              }
	      else
	         format1($generic_lv_country,$client_lv_localprivateip);
	   }
   
   	format1($generic_lv_connected,$clientConectat[$username]["Info"][1]);
   	format1($generic_lv_idletime,$clientConectat[$username]["Info"][2]);
   	format1($client_lv_cccamversion,$clientConectat[$username]["Info"][7]);

	// client message configuration

   	$index=seek_client($clientmessageport, $username);
	$clientport=$clientmessageport[$index][1];
	$clientusername=$clientmessageport[$index][2];
	$clientpassword=$clientmessageport[$index][3];

	echo "<br>";
	echo "<SPAN onclick='toggleDisplay(\"".$idtable['CLIENTCONFIGURATION']."\");' style='cursor:hand;'><FONT COLOR=white>$client_lv_configuration</FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
	echo "<br>";
	echo "<table id=\"".$idtable['CLIENTCONFIGURATION']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
	echo "<tr><td>";

	echo "<form name='clientparam' method='post' action=''><br>$getconfigserver_lv_port:<input type='text' name='clientport' value='$clientport' $size 10> $getconfigserver_lv_user:<input type='text' name='clientusername' value='$clientusername' $size 40> $getconfigserver_lv_pass:<input type='password' name='clientpassword' value='$clientpassword' $size 40> <input type='button' name='buttonsaveconfig' value='$getconfigserver_lv_saveconfiguration' style='width:120px;height:18px;font-family: Tahoma;font-size : 9px' onclick=\"SaveClientParam('$username')\">
	</form>";

//	echo "<script>setFocus();</script>";
	echo "</td></tr>";
	echo "</table>";

   	if ($country_whois == true && $tara_code["tara"]!="<>")
	{
	   echo "<BR>";
	   format1($client_lv_ispinfo,$tara_code["info"]);
	}

   if ($use_cccam_webif)
   {
      if (!$only_local_ip || ($only_local_ip && $tara_code["tara"] == "<>"))
      {
         echo "<br>CCcam Web Interface Link<br>";
         echo "<table border=0 cellpadding=2 cellspacing=1>";
         echo "<tr>";
         echo "<th class=\"tabel_headerc\">#</th>";
         echo "<th class=\"tabel_header\">".$generic_lv_cccam_webif_link."</th>";
         echo "<th class=\"tabel_header\">".$generic_lv_webif_link_status."</th>";
         echo "</tr>";
         echo "<td class=\"Node_count\">1</td>";

         $webif_link_saved = "";
         $webif_link_save_path = $cccam_host."/webiflinks/".$username.".CCcam-s2s.client.link";

         if (file_exists($webif_link_save_path))
         {
            $fh = fopen($webif_link_save_path, 'r');
            $webif_link_saved = fread($fh, filesize($webif_link_save_path));
            fclose($fh);
         }
         if ($webif_link_saved != "")
         {
            $weblink = explode(":",$webif_link_saved);
            $webhost_IP = ltrim($weblink[1], "/");
            $webhost_PORT = $weblink[2];
            $webinterface = pingDomain($webhost_IP,$webhost_PORT,1);

            if ($webinterface!=-1)
            {
               if ($use_webif_tag)
                  $webinterface_status = "<img border='0' src='images/webif_available.png' align='top' title='".$generic_lv_cccam_webif_available."'>";
               else
                  $webinterface_status = "<FONT COLOR='green'><b>(".$generic_lv_cccam_webif_available.")</b></FONT>";
            }
            else
            {
               if ($use_webif_tag)
                  $webinterface_status = "<img border='0' src='images/webif_unavailable.png' align='top' title='".$generic_lv_cccam_webif_not_available."'>";
               else
                  $webinterface_status = "<FONT COLOR='red'><b>(".$generic_lv_cccam_webif_not_available.")</b></FONT>";
            }
            echo "<td class=\"WebIf_Link\"><A HREF=".$webif_link_saved.">".$webhost_IP.":".$webhost_PORT."</A></td>";
            echo "<td class=\"WebIf_Link\">".$webinterface_status."</td>";
         }
         else
         {
            echo "<td class=\"WebIf_Link\"><FONT COLOR=red>".$generic_lv_cccam_webif_link_not_defined."</FONT></td>";
            echo "<td class=\"WebIf_Link\">";
            if ($use_webif_tag)
               echo "<img border='0' src='images/webif_disabled.png' align='top' title='".$generic_lv_cccam_webif_link_not_defined."'>";
            echo "</td>";
            $webhost_IP = $username_IP;

            $webif_link_saved = "http://".$webhost_IP.":";
         }
         echo "</table>";

         echo "<br>";
         echo "<SPAN onclick='toggleDisplay(\"".$idtable['CCCAMWEBIF']."\");' style='cursor:hand;'><FONT COLOR='white'>".$generic_lv_define_cccam_webif_link."</FONT> <img border=\"0\" src=\"images/arrow.gif\"  width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'></SPAN>";
         echo "<table id=\"".$idtable['CCCAMWEBIF']."\" style='display:none;' border=0 cellpadding=4 cellspacing=0>";
         echo "<tr><td>";
//         echo "<br>";
         ?>
         <FORM NAME="formularcccamwebif" METHOD="post" ACTION="
         <?php
         echo $pagina;
         ?>
         "><TEXTAREA CLASS="TEXTAREANORMAL" COLS="60" name="saveCCcamWebIfLink" ID="saveCCcamWebIfLink" ROWS="2" TABINDEX="1" value=""><?php echo $webif_link_saved ?></TEXTAREA>
         <DIV ALIGN = "right"><INPUT TYPE="submit" VALUE=<?php echo $server_lv_save?> TABINDEX="2" class="savetextbutton"></DIV>
            <input type="hidden" name="username" ID="username" value="<?php echo $username ?>">
         </FORM>
         <?php

         echo "</td></tr>";
         echo "</table>";
         echo "<br>";
      }
   }
	   
	   echo "<BR>";
	   
	   $lastused_Share = explode(" ", $clientConectat[$username]["Info"][8]);
	   $lastused_ShareCount = count($lastused_Share);
		$text_lastshare = "";for ($k = 0; $k <= $lastused_ShareCount-2; $k++) $text_lastshare = $text_lastshare.$lastused_Share[$k]." ";
		$text_lastshare = trim($text_lastshare);
		
		$text_lastshare_ok = "";
		
		if ($lastused_ShareCount >1)
		{
			$text_lastshare_ok = trim($lastused_Share[$lastused_ShareCount-1]);
			if ($text_lastshare_ok == "(ok)")
			{
                                if ($use_ecm_status_icons)
                                        $text_lastshare_ok = "<img border=\"0\" src=\"images/ecm_ok.png\" width='".$icon_width."' height='".$icon_height."' title='".$text_lastshare_ok."'>";
                                else
					$text_lastshare_ok = "<FONT COLOR=\"green\">".$text_lastshare_ok."</FONT>";
			}
			else
                        {
                                if ($use_ecm_status_icons)
                                        $text_lastshare_ok = "<img border=\"0\" src=\"images/ecm_not_ok.png\" width='".$icon_width."' height='".$icon_height."' title='".$text_lastshare_ok."'>";
                                else
					$text_lastshare_ok = "<FONT COLOR=\"red\">".$text_lastshare_ok."</FONT>";
			}
		}
	   
	  $SaveIndexECM = $UsageUsers[$username]["usage"];
		list($lastIndexEcm,$averageIndexEcm) = explode(".", $SaveIndexECM,2);
	  $indexclient = $lastIndexEcm;
		
		if ($indexclient <99) $usageClient = "<FONT COLOR=gray>".$indexclient."</FONT>";
	 	else
	 	if ($indexclient <249) $usageClient = "<FONT COLOR=green>".$indexclient."</FONT>";
	 	else
	 	if ($indexclient <499) $usageClient = "<FONT COLOR=yellow>".$indexclient."</FONT>";
	 	else
	 	if ($indexclient <999) $usageClient = "<FONT COLOR=orange>".$indexclient."</FONT>";
	 	else
	 		$usageClient = "<FONT COLOR=red>".$indexclient."</FONT>";
	 		
	 	format1($client_lv_currentusage,$usageClient." ".$client_lv_ecm_per_hour);
	 	
	 	if ($averageIndexEcm == "") $averageIndexEcm = 0;
		$indexclient = (int)(($lastIndexEcm + $averageIndexEcm*3)/4);
			
		if ($indexclient <99) $usageClient = "<FONT COLOR=gray>".$indexclient."</FONT>";
	 	else
	 	if ($indexclient <249) $usageClient = "<FONT COLOR=green>".$indexclient."</FONT>";
	 	else
	 	if ($indexclient <499) $usageClient = "<FONT COLOR=yellow>".$indexclient."</FONT>";
	 	else
	 	if ($indexclient <999) $usageClient = "<FONT COLOR=orange>".$indexclient."</FONT>";
	 	else
	 		$usageClient = "<FONT COLOR=red>".$indexclient."</FONT>";
	 		
	 	format1($client_lv_averageusage,$usageClient. " ".$client_lv_ecm_per_hour);
		echo "<BR>"; 	
			
   	format1($generic_lv_lastusedshare,format3($text_lastshare)." ".$text_lastshare_ok);
   	format1($generic_lv_ecmtime,$clientConectat[$username]["Info"][9]);
	   
	   $ecm_total = 0;
	   $ecmOK_total = 0;
	   foreach ($clientConectat[$username]["Info"]["Idents"] as $hit_data)
	   {
	      $hit_array = explode(" ",$hit_data);
	      if ($hit_array[0] != "")
	      {
	         $hit_provider = explode(":",$hit_array[1]);
	         $hit_exact = explode("(",$hit_array[2]);
	         $hit_exact2 = explode(")",$hit_exact[1]);
	         
	         $hit_ecm = $hit_exact[0];
	         $hit_ecmOK = $hit_exact2[0];
	         
	         $ecm_total = $ecm_total+$hit_ecm;
	         $ecmOK_total = $ecmOK_total+$hit_ecmOK;
	         
	         $key = adaug0($hit_ecmOK,20).adaug0($hit_ecm,20).$hit_array[1];
	         $ecmok_sortat[$key] = $hit_data;
	         
	      }
	   }
	   
	   
	   if ($ecm_total)
	   {
	      echo "<BR>"; 
	     	format1($client_lv_handledecm,$ecmOK_total,$ecm_total);
	     	
	      echo "<table border=0 cellpadding=2 cellspacing=1>";
	      echo "<tr>";
	      echo "<th class=\"tabel_headerc\">#</th>";
	      echo "<th class=\"tabel_headerc\">".$generic_lv_type."</th>";
	      echo "<th class=\"tabel_header\">ECM</th>";
	      echo "<th class=\"tabel_header\">OK</th>";
	      echo "<th class=\"tabel_header\">".$generic_lv_caidident."</th>";
	      echo "</tr>";
	   }
	   
	   krsort($ecmok_sortat);
	   
	   $counthits = 0;
	   foreach ($ecmok_sortat as $key => $hit_data)
	   {
	      $hit_array = explode(" ",$hit_data);
	      if ($hit_array[0] != "")
	      {
	         $counthits++;
	         $hit_provider = explode(":",$hit_array[1]);
	         $hit_exact = explode("(",$hit_array[2]);
	         $hit_exact2 = explode(")",$hit_exact[1]);
	         
	         $hit_ecm = $hit_exact[0];
	         $hit_ecmOK = $hit_exact2[0];
	         
	         echo "<tr>";
	         echo "<td class=\"Node_Provider\">".$counthits."</td>";
	         echo "<td class=\"tabel_hop_total1\">".$hit_array[0]."</td>";
	         
	         
	         echo "<td class=\"tabel_hop_total\"><FONT COLOR=white>".$hit_ecm."</FONT></td>";
	         
	         if ($hit_ecmOK == 0)  echo "<td class=\"tabel_hop_total\"><FONT COLOR=red>".$hit_ecmOK."</FONT></td>";
	         else
	         if ($hit_ecmOK != $hit_ecm)  echo "<td class=\"tabel_hop_total\"><FONT COLOR=yellow>".$hit_ecmOK."</FONT></td>";
	         else
	            echo "<td class=\"tabel_hop_total\">".$hit_ecmOK."</td>";
	         
	         echo "<td class=\"Node_Provider\">".Providerid($hit_provider[0],$hit_provider[1],true,"Node_Provider",false)."</td>";
	         echo "</tr>";
	      }
	   }
	
	   if ($ecm_total)
	      echo "</table>";
	   echo "<BR>";
  	}

        // show unknown requested SIDs for user

	if ($use_unknown_sids)
	{
           if (!file_exists($unknownsids_file))
           {
              $count_unknownsids = "n/a";
              echo $index_lv_unknownsids." <FONT COLOR=\"white\"><b>".$count_unknownsids."</b></FONT><br>";
           }
           else
           {
              if (!isset($unknownSids))
                 LoadUnknownSids();

              // count unknown SIDs for specific user

              $count_unknownsids = 0;
              if( reset($unknownSids) !== false)
                 foreach ($unknownSids as $unknownSid => $used)
                    foreach ($used[1] as $client)
                       if ($client[0] == $username)
                          $count_unknownsids++;

              if ($count_unknownsids == 0)
              {
                 $count_unknownsids = "n/a";
                 echo $index_lv_unknownsids." <FONT COLOR=\"white\"><b>".$count_unknownsids."</b></FONT><br>";
              }
              else
              {
                 echo "<SPAN onclick='toggleDisplay(\"".$idtable['UNKNOWNSIDS']."\");' style='cursor:hand;'>".$index_lv_unknownsids." <FONT COLOR=\"white\"><b>".$count_unknownsids."</b></FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'><br></SPAN>";
                 echo "<table id=\"".$idtable['UNKNOWNSIDS']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
                 echo "<tr>";
                 echo "<th class=\"tabel_headerc\">#</th>";
                 echo "<th class=\"tabel_headerc\">CAId/ProviderId</th>";
                 echo "<th class=\"tabel_headerc\">Service ID</th>";
                 echo "<th class=\"tabel_headerc\"># ".$index_lv_found_unknownsid."</th>";
                 echo "<th class=\"tabel_headerc\">Client</th>";
                 echo "</tr>";

                 $count = 1;
                 foreach ($unknownSids as $unknownSid => $used)
                 {
                    $requested_by_user = false;
                    list($short_caid, $short_providerid, $short_sid) = explode(":", $unknownSid);
                    $short_caid = ltrim($short_caid, "0");
                    if (ltrim($short_providerid, "0") == "")
                       $short_providerid = "0";
                    else
                       $short_providerid = ltrim($short_providerid, "0");
                    foreach ($used[1] as $client)
                    {
                       if ($client[0] == $username)
                       {
                          $requested_by_user = true;
                          break;
                       }
                    }

                    if ($requested_by_user)
                    {
                       echo "<tr>";
                       echo "<td class=\"Node_count\">".$count."</td>";
                       echo "<td class=\"Node_Provider\">";
                       echo providerID($short_caid, $short_providerid);
                       echo "</td>";
                       echo "<td class=\"Node_Provider\"><div align='center'><FONT COLOR=\"white\">".$short_sid."</FONT></div></td>";
                       echo "<td class=\"Node_Provider\"><div align='center'><FONT COLOR=\"white\">".$used[0]."</FONT></div></td>";
                       echo "<td class=\"Node_Provider\"><div align='left'><FONT COLOR=\"white\">";
                       foreach ($used[1] as $client)
                          if ($client[0] == $username)
                             echo "<b>".$client[0]."</b> <FONT COLOR=\"grey\">(".$client[1].")</FONT>";

                       echo "</FONT></div></td>";
                       echo "</tr>";
                       $count++;
                    }
                 }
                 echo "</table>";
              }
           }
        }

ENDPage();
?>
