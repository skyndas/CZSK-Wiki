<?php
//-------------------------------------
// PAYSERVERCHECK - Payserver Check - YaPS wrapper
//-------------------------------------

define('PAYSERVERCHECK', "payservercheck.php");

if (!defined('LOPS')) include "lops.php";	// local payserver service
if (!defined('YAPS')) include "yaps.php";	// Yet another payserver service

//-------------------------------------
// YaPSDBDownload($yaps["server"], $yaps["db"], $yaps["secure"], $yaps["humanreadable"], $yaps["humanreadabledb"], $yaps["humanreadablever"]);
//-------------------------------------

//-------------------------------------
/*
if (YaPSInfo("available", $yaps["db"], $yaps["server"], $yaps["secure"]) != "")
   echo "YaPS is online!<br>";
else
   echo "YaPS is offline!<br>";
*/
//-------------------------------------

//-------------------------------------
// FUNCTIONS
//-------------------------------------

//___________________________________________________________________________________________________

function yapsAvailable()
{
   global $yaps;

   $ssl = hasHTTPSwrapper() ? $yaps["secure"] : false;

   $yapsserviceavailable = YaPSInfo("available", $yaps["db"], $yaps["server"], $ssl) != "" ? true : false;
   return $yapsserviceavailable;
}

//___________________________________________________________________________________________________
function yapsCheck($file, $dns)
{
   global $common_lv_fileopenerror;
   global $common_lv_checkpermissions;

   $payserver = false;
   if (!$fp = fopen($file,"r"))
   {
      echo "<h5>".$common_lv_fileopenerror." ".$file.". ".$common_lv_checkpermissions.".\n</h5>";
   }
   else
   {
      $myDNS = explode(".", $dns);
      $myDNS_elements = count($myDNS);
      $length = strlen($dns);

      while(!feof($fp))
      {
         $entry = fgets($fp, 128);

         $yapsDNS = explode(".", $entry);
         if((($yapsDNS[0] == $myDNS[0]) && similar_text($entry, $dns) > 12) || (substr($entry,0,$length) == $dns) && $myDNS_elements > 1)
         {
            $payserver = true;
            break;
         }
      }
      fclose($fp);

//    switch($payserver)
//    {
//       case true : return "<a href=\"".$host."/?q=".$dns."\" target=\"_blank\"><font color=\"red\">Payserver!</font></A>";
//       case true : return "<a href=\"".$host."/?q=".$dns."\" target=\"_blank\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_not_ok.gif\" width=\"12\" height=\"12\"></A>";
//          break;
//       case false : return "<font color=\"green\">no Payserver</font>";
//       case false : return "<div align=\"center\"><img border=\"0\" src=\"images/ecm_ok.gif\" width=\"12\" height=\"12\">";
//          break;
//       default : return "Unknown Error";
//      }
      return $payserver;
   }
}

//___________________________________________________________________________________________________

function yapsStats($mode)
{
   global $yaps;

   $ssl = hasHTTPSwrapper() ? $yaps["secure"] : false;

   return YaPSInfo($mode, $yaps["db"], $yaps["server"], $ssl);
}

//___________________________________________________________________________________________________

function yapsStatus()
{
   global $yaps;
   global $common_lv_yapsdatabasestatus;
   global $common_lv_yapsdatabaseversion;
   global $common_lv_yapsdatabaserows;
   global $common_lv_yapspayserverhits;
   global $common_lv_yapssecureconnection;
   global $common_lv_yapssecureenabled;
   global $common_lv_yapssecuredisabled;
   global $generic_lv_collexp;
   global $icon_height;
   global $icon_width;
   global $idtable;


   // init variables
   $ssl = hasHTTPSwrapper() ? $yaps["secure"] : false;
  
   $ssl == true ? $host = "https://".$yaps["server"].":443" : $host = "http://".$yaps["server"].":80";
   $version  = $host."/?db";

   $ssl == true ? $sslstatus = $common_lv_yapssecureenabled : $sslstatus = $common_lv_yapssecuredisabled;

   echo "<br>";

   echo "<SPAN onclick='toggleDisplay(\"".$idtable['YAPSSTATUS']."\");' style='cursor:hand;'>$common_lv_yapsdatabasestatus <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'><br></SPAN>";

   echo "<table id=\"".$idtable['YAPSSTATUS']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
   echo "<tr><td>";
   format1("Yet Another Payserver Service", yapsStats("available"));
   $result = file_get_contents($version);
   $date = date("d.m.Y", "$result");
   format1($common_lv_yapsdatabaseversion, $date);
   format1($common_lv_yapsdatabaserows, yapsStats("rows"));
   format1($common_lv_yapssecureconnection, $sslstatus);
   echo "</td></tr>";
   echo "</table>";
}
//___________________________________________________________________________________________________

function yapsUpdate()
{
   global $yaps;

   $ssl = hasHTTPSwrapper() ? $yaps["secure"] : false;

   YaPSDBDownload($yaps["server"], $yaps["db"], $ssl, $yaps["humanreadable"], $yaps["humanreadabledb"], $yaps["humanreadablever"]);
   return YaPSInfo("rows", $yaps["db"]); // return rows
}

//___________________________________________________________________________________________________

function yapsUptodate()
{
   global $yaps;

   // init variables
   $ssl = hasHTTPSwrapper() ? $yaps["secure"] : false;

   $ssl == true ? $host = "https://".$yaps["server"].":443" : $host = "http://".$yaps["server"].":80";
   $version  = $host."/?db";

   // check if YaPS needs to download database  
   if(YaPSInfo("dbver", $yaps["db"]) < file_get_contents($version))
      return false;
   else
      return true;
}
//___________________________________________________________________________________________________
function localStatus($file)
{
   global $common_lv_fileopenerror;
   global $common_lv_checkpermissions;
   global $common_lv_localdatabasestatus;
   global $common_lv_localdatabaseversion;
   global $generic_lv_collexp;
   global $icon_height;
   global $icon_width;
   global $idtable;

   $status = false;

   if (!$fp = fopen($file,"r"))
   {
      echo "<h5>".$common_lv_fileopenerror." ".$file.". ".$common_lv_checkpermissions.".\n</h5>";
   }
   else
   {
      $status = true;
      $localdate = fgets($fp, 128);
      fclose($fp);

      echo "<br>";

      echo "<SPAN onclick='toggleDisplay(\"".$idtable['LOCALSTATUS']."\");' style='cursor:hand;'>$common_lv_localdatabasestatus <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'><br></SPAN>";

      echo "<table id=\"".$idtable['LOCALSTATUS']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
      echo "<tr><td>";
      format1($common_lv_localdatabaseversion, $localdate);

      /* debug
      echo $file."<br>";
      */

      echo "</td></tr>";
      echo "</table>";
   }

   return $status;
}

/*
// Download YaPS database
YaPSDBDownload($yaps["server"], $yaps["db"], $yaps["secure"]);

// print YaPS version
format1("YaPS", $yaps["version"]);

// print YaPS local database version
format1("Database version", YaPSInfo("date", $yaps["db"]));

// print YaPS local database rows
format1("Database rows", YaPSInfo("rows", $yaps["db"]));

// print YaPS secure connection option
$yaps["secure"] == true ? $SSLStatus = "enabled" : $SSLStatus = "disabled";
format1("Secure connection", $SSLStatus);
*/

?>
