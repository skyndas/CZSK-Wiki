<HTML>
<HEAD>
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<LINK HREF="cccam.css" REL="Stylesheet" TYPE="text/css">
<style type="text/css">
<!--
.style1 {color: #AFCC00}
-->
</style>
</HEAD>
<BODY>

<?php include "common.php"?>

<?php include "refresh.php"?>

<?php
	if ($use_jump_to_top)
	{
?>
<script type="text/javascript" src="javascript/jumptop.js"></script>
<?php
	}
?>

<?php

	if (!$update_from_button && $use_reload_on_button && isReloadActive())
	{
		$update_info = true;
		$update_servers = true;
		$update_activeclients = true;
	}

	include "meniu.php";

	if (file_exists($entitlements_file))
		$entitlements_data = file ($entitlements_file);
		
	$localecm = 0;
	$localecmOK= 0;
	foreach ($entitlements_data as $currentline) 
	if (!strstr($currentline,"</H2>")) 		
	{
		if (strstr($currentline,"handled ")) 
		{
			
			$liniesplit = explode(" ", $currentline);
			list($xlocalecm,$xlocalecmOK) = explode("(", substr($liniesplit[1],0,-1),2);
			
			$localecm   = $localecm+$xlocalecm;
			$localecmOK = $localecmOK+$xlocalecmOK;
		}	
	}
	
	if (isset($caminfo_data) && count($caminfo_data)>0)
	foreach ($caminfo_data as $currentline) 
	{
		$liniesplit = explode("<BR>", $currentline);
		foreach ($liniesplit as $linie) 
		{
			if (strstr($linie,"Current time")) 
			{
				$temp = explode(" ",$linie);
				format1($index_lv_currenttime,$temp[2]);
			}
			else
			if (strstr($linie,"Uptime"))
			{
				$temp = explode(" ",$linie);
				format1($generic_lv_uptime,$temp[1]." ".$temp[2]);
			}
			else
			{
				$linieafis = explode(":",$linie);
				
				if (strstr($linie,"NodeID"))
				{
					//format1($linieafis[0],$linieafis[1]);
					format1($generic_lv_nodeid,$linieafis[1]);
				}
				if (strstr($linie,"Connected clients"))
				{
					//format1($linieafis[0],$linieafis[1]);
					format1($generic_lv_connectedclients,$linieafis[1]);
				}
				//if (strstr($linie,"Active clients")) 					format1($linieafis[0],$linieafis[1]);
				if (strstr($linie,"Total handled client ecm's"))
				{
					//format1($linieafis[0],$linieafis[1]);
					format1($index_lv_totalhandledecm,$linieafis[1]);
				}
				if (strstr($linie,"Total handled client emm's")) 	
				{
					//format1($linieafis[0],$linieafis[1]);
					format1($index_lv_totalhandledemm,$linieafis[1]);
					//format1("Total handled LOCAL ecm's",$localecmOK,$localecm);
					format1($index_lv_totalhandledlocal,$localecmOK,$localecm);
				}
				if (strstr($linie,"Peak load"))
				{
					//format1($linieafis[0],$linieafis[1]);
					format1($index_lv_peakload,$linieafis[1]);
				}
			}

			
		}
	}
	

	checkFile($activeclients_file);
	$activeclients_data = file ($activeclients_file);
	
	foreach ($activeclients_data as $currentline) 
	{
		$inceput1 = substr($currentline,0,1);
		$inceput2 = substr($currentline,1,2);
		if (strstr($currentline,"| Shareinfo")) break; 	

		if ($inceput1 == "|" && $inceput2 != " U")
		{
			$active_client = explode("|", $currentline);
			$ac_Username 			= trim($active_client[1]);
			$ac_IP 					= trim($active_client[2]);
			$ac_Connected 			= trim($active_client[3]);
			$ac_Idle 				= trim($active_client[4]);
			$ac_ECM 					= trim($active_client[5]);
			$ac_EMM 					= trim($active_client[6]);
			$ac_Version				= trim($active_client[7]);
			$ac_LastShare			= trim($active_client[8]);
			
			$ac_EcmTime	= "";  
			if (isset($active_client[9]))	
				$ac_EcmTime	= trim($active_client[9]);
			
			$clientActiv[$ac_Username]["Info"] = array ($ac_IP,$ac_Connected,$ac_Idle,$ac_ECM,$ac_EMM,$ac_Version,$ac_LastShare,$ac_EcmTime);  
			
		}
	}
	
	echo "<br>";

	if ($use_detect_newer_cccam_version && function_exists('showNewerCCcamVersions'))
		showNewerCCcamVersions();
	
if ( isset($clientActiv) && count($clientActiv)>0 )
{	
	if ($use_most_activeclients)
	{
		format1($generic_lv_activeclients,count($clientActiv),-1,false);
		echo "  (";
		format1($generic_lv_most_activeclients,getMostActiveClients(),-1,false);
		echo ")<br>";
	}
	else
		format1($generic_lv_activeclients,count($clientActiv));
	echo "<table border=0 cellpadding=2 cellspacing=1>";
	echo "<tr>";
	echo "<th class=\"tabel_headerc\">#</th>";
	echo "<th class=\"tabel_headerc\">".$generic_lv_username."</th>";
	if ($country_whois == true) 
		echo "<th class=\"tabel_headerc\" COLSPAN=\"2\">".$generic_lv_host."</th>";	
	else
		echo "<th class=\"tabel_headerc\">".$generic_lv_host."</th>";	

	echo "<th class=\"tabel_headerc\">".$generic_lv_connected."</th>";	
	echo "<th class=\"tabel_headerc\">".$generic_lv_idletime."</th>";	
	echo "<th class=\"tabel_headerc\">ECM</th>";	
	echo "<th class=\"tabel_headerc\">EMM</th>";	
	echo "<th class=\"tabel_headerc\">".$generic_lv_version."</th>";	
	echo "<th class=\"tabel_headerc\" COLSPAN=\"2\">".$generic_lv_lastusedshare."</th>";	
	echo "<th class=\"tabel_headerc\">".$generic_lv_ecmtime."</th>";	
	echo "</tr>";
	
	$i=0;
	foreach ($clientActiv as $username => $client) 
	{
		$i++;
		echo "<tr>";
		echo "<td class=\"Node_count\">".$i."</td>";
		echo "<td class=\"tabel_ecm\"><A HREF=".$pagina."?username=$username>".$username."</A></td>";
		if ($country_whois == true) 
		{
			$tara = tara($client["Info"][0],$username);
                        if ($use_country_flags == true && $tara["tara"] != "<>" && file_exists($country_flags_path.$tara["tara"].".gif"))
                        {      
                                echo "<td class=\"tabel_ecm\"><img border='0' src='".$country_flags_path.$tara["tara"].".gif' alt='".$tara["tara"]."'></td>";
                        }
                        else 
				echo "<td class=\"tabel_ecm\">".$tara["tara"]."</td>";		
		}
		echo "<td class=\"tabel_hop_total2\">".$client["Info"][0]."</td>"; // ip address
		echo "<td class=\"tabel_hop_total2\">".$client["Info"][1]."</td>"; // connected time
		echo "<td class=\"tabel_hop_total2\">".$client["Info"][2]."</td>"; // idle time
		echo "<td class=\"tabel_hop_total2\">".$client["Info"][3]."</td>"; // ECM
		echo "<td class=\"tabel_hop_total2\">".$client["Info"][4]."</td>"; // EMM
		echo "<td class=\"tabel_hop_total2\">".$client["Info"][5]."</td>"; // version
		
		$lastused_Share = explode(" ", $client["Info"][6]);
		$lastused_ShareCount = count($lastused_Share);
		$text_lastshare = "";for ($k = 0; $k <= $lastused_ShareCount-2; $k++) $text_lastshare = $text_lastshare.$lastused_Share[$k]." ";

		echo "<td class=\"tabel_normal\">".format3(trim($text_lastshare))."</td>";		
		
		if ($lastused_ShareCount >1)
		{
			$text_ok = trim($lastused_Share[$lastused_ShareCount-1]);
			if ($text_ok == "(ok)")
			{
				if ($use_ecm_status_icons)
					echo "<td class=\"tabel_hop_total2\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_ok.png\" width='".$icon_width."' height='".$icon_height."' title='".$text_ok."'></td>";
				else
					echo "<td class=\"tabel_hop_total2\"><FONT COLOR=\"green\">".$text_ok."</FONT></td>";
			}
			else
			{
				if ($use_ecm_status_icons)
					echo "<td class=\"tabel_hop_total2\"><div align=\"center\"><img border=\"0\" src=\"images/ecm_not_ok.png\" width='".$icon_width."' height='".$icon_height."' title='".$text_ok."'></td>";
				else
					echo "<td class=\"tabel_hop_total2\"><FONT COLOR=\"red\">".$text_ok."</FONT></td>";
			}
		}
		else
			echo "<td class=\"tabel_hop_total2\"></td>";

		echo "<td class=\"tabel_hop_total2\">".$client["Info"][7]."</td>";
		echo "</tr>";
	}
}
	echo "</table>";

	echo "<br>";

	checkFile($servers_file);
	$servers_data = file ($servers_file);
	
	foreach ($servers_data as $currentline) 
	{
		$inceput1 = substr($currentline,0,1);
		$inceput2 = substr($currentline,1,2);
		
		if ($inceput1 == "|" && $inceput2 != " H")
		{
			$server = explode("|", $currentline);
			$server_Idents = trim($server[7]);
			
			$hit_array = explode(" ",$server_Idents);
			if ($hit_array[0] != "")
			{
				$hit_caid = $hit_array[1];
				$hit_provider = explode(":",$hit_caid);
				$hit_exact = explode("(",$hit_array[2]);
				$hit_exact2 = explode(")",$hit_exact[1]);
				
				$hit_ecm = $hit_exact[0];
				$hit_ecmOK = $hit_exact2[0];
				
				if (!isset($ecm_hit[$hit_array[0]][$hit_caid]["Info"]["ECM"])) 		$ecm_hit[$hit_array[0]][$hit_caid]["Info"]["ECM"] = 0;
				if (!isset($ecm_hit[$hit_array[0]][$hit_caid]["Info"]["ECMOK"])) 		$ecm_hit[$hit_array[0]][$hit_caid]["Info"]["ECMOK"] = 0;
				
				$ecm_hit[$hit_array[0]][$hit_caid]["Info"]["ECM"] 		+= $hit_ecm;
				$ecm_hit[$hit_array[0]][$hit_caid]["Info"]["ECMOK"] 	+= $hit_ecmOK;
				
				
				if (!isset($ecm_hit[$hit_array[0]]["total"]["Info"]["ECM"])) 			$ecm_hit[$hit_array[0]]["total"]["Info"]["ECM"] = 0;
				if (!isset($ecm_hit[$hit_array[0]]["total"]["Info"]["ECMOK"])) 		$ecm_hit[$hit_array[0]]["total"]["Info"]["ECMOK"] = 0;
				
				$ecm_hit[$hit_array[0]]["total"]["Info"]["ECM"] 		+= $hit_ecm;
				$ecm_hit[$hit_array[0]]["total"]["Info"]["ECMOK"] 		+= $hit_ecmOK;

			}
		}
	}

	if ( isset($ecm_hit) && count($ecm_hit)>0 )
	{
		ksort($ecm_hit);
	
		foreach ($ecm_hit as $tip_ecmhit => $ecmhit)
		{
			$totalECM = 0;
			$ecmhit_ECMOK = 0;
		
			if (isset($ecmhit["total"]["Info"]["ECM"]))  	$totalECM = $ecmhit["total"]["Info"]["ECM"];
			if (isset($ecmhit["total"]["Info"]["ECMOK"]))  	$ecmhit_ECMOK = $ecmhit["total"]["Info"]["ECMOK"];
		
		 	$procentEcm = 0; if ($totalECM > 0) $procentEcm = (int)($ecmhit_ECMOK/$totalECM *100);
		 	$procentEcmAfisat = procentColor($procentEcm);
	 		
		 	if ($totalECM == 0)
		 	{
		 		$totalECM = "<FONT COLOR=red>".$totalECM."</FONT>";
		 		$procentEcmAfisat = "-";
		 	}
	 	
		 	echo $index_lv_recent." <B><FONT COLOR=\"white\">".$tip_ecmhit."</FONT></b> ".$index_lv_ecmhandled." :<B> ";
		 	echo "<FONT COLOR=\"white\">".$ecmhit_ECMOK."</FONT>/".$totalECM." (".$procentEcmAfisat.")";
			echo "</b><BR>";
	
		
			echo "<table border=0 cellpadding=2 cellspacing=1>";
			echo "<tr>";
			echo "<th class=\"tabel_headerc\">#</th>";
			echo "<th class=\"tabel_headerc\">ECM</th>";
			echo "<th class=\"tabel_headerc\">".$generic_lv_handled."</th>";	
			echo "<th class=\"tabel_headerc\">%</th>";	
			echo "<td class=\"tabel_header\">".$index_lv_providername."</th>";
			echo "</tr>";
		
			$i=1;
			if (count($ecmhit)>0)
			{
				//ksort($ecmhit);
			
				foreach ($ecmhit as $caid => $info) 
				if ($caid != "total")
				{
				
		
					$ecmhit_ECMOK = 0;
					if (isset($ecmhit[$caid]["Info"]["ECMOK"]))  	$ecmhit_ECMOK = $ecmhit[$caid]["Info"]["ECMOK"];
				
					$key = adaug0($ecmhit_ECMOK,20)."_".$caid;
				
					$servers_sortat[$tip_ecmhit][$key] = $caid;
				
					//echo $key."<BR>";
				}
			
				krsort($servers_sortat[$tip_ecmhit]);
			
	
				foreach ($servers_sortat[$tip_ecmhit] as $key => $caid) 
				//if ($caid != "total")
				{
					$info = $ecmhit[$caid];
					echo "<tr>";
				
					$hit_provider = explode(":",$caid);
					$caidECM = $hit_provider[0];
					$pECM    = $hit_provider[1];
				
					echo "<td class=\"Node_count\">".$i."</td>";
				
					//------------- ECM
					
		
					$totalECM = 0;
					$ecmhit_ECMOK = 0;
				
					if (isset($ecmhit[$caid]["Info"]["ECM"]))  		$totalECM = $ecmhit[$caid]["Info"]["ECM"];
					if (isset($ecmhit[$caid]["Info"]["ECMOK"]))  	$ecmhit_ECMOK = $ecmhit[$caid]["Info"]["ECMOK"];
				
				 	$procentEcm = 0; if ($totalECM > 0) $procentEcm = (int)($ecmhit_ECMOK/$totalECM *100);
				 	$procentEcmAfisat = procentColor($procentEcm);
			 		
				 	if ($totalECM == 0)
				 	{
				 		$totalECM = "<FONT COLOR=red>-</FONT>";
				 		$procentEcmAfisat = "-";
				 	}
			 	
					echo "<td class=\"tabel_ecm\"><FONT COLOR=\"gray\">".$totalECM."</FONT></td>";
					echo "<td class=\"tabel_ecm\"><FONT COLOR=\"white\">".$ecmhit_ECMOK."</FONT></td>";
					echo "<td class=\"tabel_ecm\">".$procentEcmAfisat."</td>";

					echo "<td class=\"Node_Provider\">".providerID($caidECM,$pECM)."</td>";		
//					echo "<td class=\"Node_Provider\">".providerID($caidECM,$pECM,true,"Node_Provider",false,true)."</td>";
					echo "</tr>";
					$i++;
				}
				echo "</table>";
			}
		}
	}

	if ($use_known_sids)
	{
		echo "<br>";

		unset($known_sids);
		if ( isset($clientActiv) && count($clientActiv)>0 )
		{
			$i=0;
			foreach ($clientActiv as $username => $client) 
			{
				$i++;
				$lastused_Share = explode(" ", $client["Info"][6]);
				$lastused_ShareCount = count($lastused_Share);
				$text_lastshare = "";for ($k = 0; $k <= $lastused_ShareCount-2; $k++) $text_lastshare = $text_lastshare.$lastused_Share[$k]." ";

				if ($text_lastshare != "" && !IsUnknownSid($text_lastshare))
				{
					if (!isset($known_sids[$text_lastshare]))
					{
						$known_sids[$text_lastshare] = array(1, array($username));
//						$known_sids[$text_lastshare] = array(1, array($username,trim($lastused_Share[$lastused_ShareCount-1])));
					}
					else
					{
						$known_sids[$text_lastshare][0]++;
						$known_sids[$text_lastshare][1][] = $username;
//						$known_sids[$text_lastshare][1][] = array($username,trim($lastused_Share[$lastused_ShareCount-1]));
					}
				}
			}
			ksort($known_sids);
		}
		$count_known_sids = count($known_sids);

		if ($count_known_sids == 0)
		{
			$count_known_sids = "n/a";
			echo $index_lv_knownsids." <FONT COLOR=\"white\"><b>".$count_known_sids."</b></FONT><br>";
		}
		else
		{
			echo "<SPAN onclick='toggleDisplay(\"".$idtable['KNOWNSIDS']."\");' style='cursor:hand;'>".$index_lv_knownsids." <FONT COLOR=\"white\"><b>".$count_known_sids."</b></FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'><br></SPAN>";
			echo "<table id=\"".$idtable['KNOWNSIDS']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
			echo "<tr>";
			echo "<th class=\"tabel_headerc\">#</th>";
			echo "<th class=\"tabel_headerc\">".$generic_lv_lastusedshare."</th>";
			echo "<th class=\"tabel_headerc\">".$generic_lv_count."</th>";
			echo "<th class=\"tabel_headerc\">".$generic_lv_username."</th>";

			$i=1;

			foreach ($known_sids as $request => $sid)
			{
				echo "<tr>";
				echo "<td class=\"Node_count\">".$i."</td>";
				echo "<td class=\"tabel_lastshare\">".format3(trim($request))."</td>";
				echo "<td class=\"tabel_lastsharenormal\"><div align='center'>".trim($sid[0])."</div></td>";
				echo "<td class=\"Node_Provider\"><div align='left'><FONT COLOR=\"white\">";

				$user_count = 1;
				sort($sid[1]);
				foreach ($sid[1] as $client)
				{
					echo "<A HREF='".$pagina."?username=".$client."'><b>".$client."</b></A>";
					if ($user_count<count($sid[1]))
						echo "<FONT COLOR=\"grey\"><b>, </b></FONT>";
					$user_count++;
				}
				echo "</FONT></div></td>";

				echo "</tr>";
				$i++;
			}
		}

		echo "</table>";
	}

	if ($use_unknown_sids)
	{
		echo "<br>";

		$idtable = "unknownsids";

		if (!file_exists($unknownsids_file))
		{
			$count_unknownsids = "n/a";
			echo $index_lv_unknownsids." <FONT COLOR=\"white\"><b>".$count_unknownsids."</b></FONT><br>";
		}
		else
		{
			if ($delete_unknown_sid != "")
				sid_delete($delete_unknown_sid);

			if (!isset($unknownSids))
				LoadUnknownSids();

			$count_unknownsids = count($unknownSids);
			if ($count_unknownsids == 0)
			{
				$count_unknownsids = "n/a";
				echo $index_lv_unknownsids." <FONT COLOR=\"white\"><b>".$count_unknownsids."</b></FONT><br>";
			}
			else
			{
				echo "<SPAN onclick='toggleDisplay(\"".$idtable['UNKNOWNSIDS']."\");' style='cursor:hand;'>".$index_lv_unknownsids." <FONT COLOR=\"white\"><b>".$count_unknownsids."</b></FONT> <img border=\"0\" src=\"images/arrow.gif\" width='".$icon_width."' height='".$icon_height."' title='".$generic_lv_collexp."'><br></SPAN>";
				echo "<table id=\"".$idtable['UNKNOWNSIDS']."\" style='display:none;' border=0 cellpadding=2 cellspacing=1>";
				echo "<tr>";
				echo "<th class=\"tabel_headerc\">#</th>";
				echo "<th class=\"tabel_headerc\">CAId/ProviderId</th>";
				echo "<th class=\"tabel_headerc\">Service ID</th>";
				echo "<th class=\"tabel_headerc\"># ".$index_lv_found_unknownsid."</th>";
				echo "<th class=\"tabel_headerc\">".$generic_lv_username."</th>";
				echo "<th class=\"tabel_headerc\">".$index_lv_action_unknownsid."</th>";
				echo "</tr>";

				$count = 1;
				foreach ($unknownSids as $unknownSid => $used)
				{
					list($short_caid, $short_providerid, $short_sid) = explode(":", $unknownSid);
					$short_caid = ltrim($short_caid, "0");
					if (ltrim($short_providerid, "0") == "")
						$short_providerid = "0";
					else
						$short_providerid = ltrim($short_providerid, "0");
					echo "<tr>";
					echo "<td class=\"Node_count\">".$count."</td>";
					echo "<td class=\"Node_Provider\">";
					echo providerID($short_caid, $short_providerid);
					echo "</td>";
					echo "<td class=\"Node_Provider\"><div align='center'><FONT COLOR=\"white\">".$short_sid."</FONT></div></td>";
					echo "<td class=\"Node_Provider\"><div align='center'><FONT COLOR=\"white\">".$used[0]."</FONT></div></td>";
					echo "<td class=\"Node_Provider\"><div align='left'><FONT COLOR=\"white\">";
					$i = 1;
					foreach ($used[1] as $client)
					{
						echo "<A HREF='".$pagina."?username=".$client[0]."'><b>".$client[0]."</b></A> <FONT COLOR=\"grey\">(".$client[1].")</FONT>";
						if ($i<count($used[1]))
							echo "<FONT COLOR=\"grey\"><b>, </b></FONT>";
						$i++;
					}
					echo "</FONT></div></td>";
					if ($use_trashbin_icon)
						$text_sid = linkSid("deleteUnknownSid", $unknownSid, "<img border=\"0\" src=\"images/delete.png\" title='".$index_lv_delete_unknownsid." unknown SID ".$unknownSid."' width='".$icon_width."' height='".$icon_height."'>");
					else
						$text_sid = linkSid("deleteUnknownSid", $unknownSid, "<FONT COLOR=\"red\">".$index_lv_delete_unknownsid."</FONT>");
					echo "<td class=\"Node_Provider\"><div align='center'>".$text_sid."</div></td>";
					echo "</tr>";
					$count++;
				}
				$text_sid = linkSid("deleteUnknownSid", "all", "<img border=\"0\" src=\"images/delete.png\" title='".$index_lv_delete_all_unknownsid."' width='".$icon_width."' height='".$icon_height."'>");
				echo "<tr><td class=\"Node_Provider\" colspan=5><div align='right'><FONT COLOR=\"grey\">".$index_lv_delete_all_unknownsid.":</FONT></div></td><td class=\"Node_Provider\"><div align='center'>".$text_sid."</div></td></tr>";
				echo "</table>";
			}
		}
	}

	if ($use_resetstatistics)
	{
		$_SERVER['QUERY_STRING'] = "server=".$cccam_host;
		$stringquerry = $_SERVER['QUERY_STRING'];
		if (!strstr($stringquerry,"&resetNodeStats=1"))
			$stringquerry = $stringquerry."&resetNodeStats=1";
		$reset_nodestats = "&nbsp;<A class=\"tabel_header\" HREF=".$pagina."?".$stringquerry.">&nbsp;".$index_lv_resetnodenow."&nbsp;&nbsp;</A>";

		echo "<br>";

		format1($index_lv_resetnodestats." ",$reset_nodestats);

		if($index_resetNodeStats != "")
		{
			resetNodeStats($cccam_host);
		}
	}
	ENDPage();
?>

<BR>
</BODY>
</HTML>

