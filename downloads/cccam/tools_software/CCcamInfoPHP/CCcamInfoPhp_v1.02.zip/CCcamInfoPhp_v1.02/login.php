<HTML><HEAD><LINK HREF="cccam.css" REL="Stylesheet" TYPE="text/css"></HEAD><BODY>
<center>
<BR><BR><BR>
<BR><BR><BR>
<table border="0" cellspacing="0" cellpadding="0" width="350" CLASS="tabel_LOGIN">
<tr>
	<td align="center"><BR><BR><font face='Arial' size=6 color=white>CCcamInfoPHP</font</td>
</tr>
<tr>
<td>

	<form action="<?=$_SERVER['PHP_SELF']?>" method="post" name="frmLogin">
	<table border="0" width="350">
	<tr>
		<BR><BR>
		<td align="center"><input type="password" name="form_password">&nbsp;&nbsp;<input type="submit" value=" Login "></td>
	</tr>
	</table>
	</form>

</td>
</tr>
</table>
</center>
</BODY>
