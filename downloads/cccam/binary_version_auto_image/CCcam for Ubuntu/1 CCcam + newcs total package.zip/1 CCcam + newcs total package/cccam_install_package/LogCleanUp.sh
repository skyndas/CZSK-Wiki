#!/bin/sh
# Script to cleanup log files
# Script written by Youknowhoo.

OWNER=share4u
TARGETDIR_1=/tmp
TARGETDIR_2=/var/cccamlog
FILE_1=warning.txt
FILE_2=cccam.check
FILE_3=CCcam.log
FILE_4=newcs.check

echo && date

if test -f $TARGETDIR_1/$FILE_1 ; then
       echo "warning text present!"
       chown $OWNER $TARGETDIR_1/$FILE_1
       rm $TARGETDIR_1/$FILE_1
       else
       echo "No warning text present?!?!Nothing to remove"
       fi

          if test -f $TARGETDIR_2/$FILE_2 ; then
               echo "CCcam Check file present!"
               chown $OWNER $TARGETDIR_2/$FILE_2
               rm $TARGETDIR_2/$FILE_2 
               else
               echo "No CCcam Check File present?!?! Nothing to remove"
               fi
               
          if test -f $TARGETDIR_2/$FILE_3 ; then
               echo "CCcam Debug Log precent!"
               chown $OWNER $TARGETDIR_2/$FILE_3
               rm $TARGETDIR_2/$FILE_3
               else
               echo "No! CCcam Debug file present, CCcam did run perfectly !!"
          if test -f $TARGETDIR_2/$FILE_4 ; then
               echo "NewCS Check file precent!"
               chown $OWNER $TARGETDIR_2/$FILE_4
               rm $TARGETDIR_2/$FILE_4
               else
          echo "No! No NewCS Check File present?!?! Nothing to remove"
fi
exit


