#!/bin/sh 
#this script is written By youknowhoo
#i have added a part that checks if CCcam is responding like it should
#that part is written by CC_share.
#this way you can see if it was off(line) or froozen 
process=`ps auxwww | grep newcs.i686 | grep -v grep | awk '{print $1}'`
if [ -z "$process" ]; then
echo && date >> /var/cccamlog/newcs.check
echo "Couldn't find NewCS running. Restarting NewCS" >> /var/cccamlog/newcs.check 
/usr/local/bin/newcs.i686 -C /var/etc/newcs.xml
else echo "NewCS is still OK!"  
fi 
sleep 2
CHECKNAME="test.txt"
IP="127.0.0.1"
PORT="16000"
process=`ps auxwww | grep CCcam.x86 | grep -v grep | awk '{print $1}'`
if [ -z "$process" ]; then
echo "Couldn't find CCcam.x86 running, Restarting CCcam" >> /var/cccamlog/cccam.check 
echo && date >>/var/cccamlog/cccam.check 
/usr/local/bin/CCcam.x86
else echo "CCcam process is present, now checking if CCcam is froozen"
sleep 6
echo info|nc $IP $PORT >>/tmp/test.txt 
set $(ls -s /tmp/test.txt)
if [ "$1" = "0" ];
then
echo "CCcam is froozen, restarting CCcam" >>/var/cccamlog/cccam.check
echo && date >>/var/cccamlog/cccam.check
/usr/local/bin/CCcam.x86 
else
echo "Cccam is responding like it should"
fi
rm /tmp/$CHECKNAME
fi
