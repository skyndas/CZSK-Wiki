#!/bin/bash
#Script to stop CCcam & newcs
#Script is written by Youknowhoo
echo "stoping NewCS server"
pkill newcs.i686
sleep 1
echo "starting CCcam server"
pkill CCcam.x86
