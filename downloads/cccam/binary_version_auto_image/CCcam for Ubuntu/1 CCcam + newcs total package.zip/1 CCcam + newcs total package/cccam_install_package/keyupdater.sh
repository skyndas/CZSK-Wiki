#!/bin/bash
wget -qO /var/keys/SoftCam.Key http://www.uydu.ws/deneme6.php?file=SoftCam.Key
wget -qO /var/keys/AutoRoll.Key http://www.softcam.tv/deneme6.php?file=AutoRoll.Key

