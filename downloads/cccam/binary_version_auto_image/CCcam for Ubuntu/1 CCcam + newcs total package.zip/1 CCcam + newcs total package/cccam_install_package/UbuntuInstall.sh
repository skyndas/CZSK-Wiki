#!/bin/sh
#Automated Installation script
#Purpose: Installing CCcam on a bare Ubuntu system.
#Written by: Youknowhoo
#
#Requirements: Ubuntu 8.04.1 / 8.04.3
#            Installation Package.
#put the cccam_install_package in /tmp
#put this script in /tmp then chmod 755 this script
echo "Installation script for automated CCcam installation"

OWNER=share4u
chown $OWNER /tmp/cccam_install_package

if [ ! -e  /tmp/cccam_install_package ] ; then
echo "WARNING !!!!!!!"
echo "Install package is not in tmp directory"
echo "please check if its there"
fi
echo "make directorys"

mkdir /var/etc
chown $OWNER /var/etc

mkdir /var/keys
chown $OWNER /var/keys
      
mkdir /var/script
chown $OWNER /var/script

mkdir /var/config
chown $OWNER /var/config
	
mkdir /var/backup
chown $OWNER /var/backup
	
mkdir /var/cccamlog
chown $OWNER /var/cccamlog
     
chown $OWNER /usr/local/bin

mv /tmp/cccam_install_package/CCcam.x86 /usr/local/bin
chmod 755 /usr/local/bin/CCcam.x86

mv /tmp/cccam_install_package/*.sh /var/script
chmod 755 /var/script/configupdate.sh
chmod 755 /var/script/LogCleanUp.sh
chmod 755 /var/script/CCcamCheck.sh
chmod 755 /var/script/keyupdater.sh

chown $OWNER /etc/rc.local
rm /etc/rc.local
mv /tmp/cccam_install_package/rc.local /etc/rc.local
mv /tmp/cccam_install_package/CCcam.channelinfo /var/etc
mv /tmp/cccam_install_package/CCcam.providers /var/etc
mv /tmp/cccam_install_package/CCcam.prio /var/etc
mv /tmp/cccam_install_package/CCcam.cfg /var/etc

echo "56 03 * * * root /killall/CCcam.x86" >> /etc/crontab
echo "57 03 * * * root /var/script/configupdate.sh >> /var/cccamlog/configupdate.log" >> /etc/crontab
echo "58 03 * * * root /var/script/keyupdater.sh" >> /etc/crontab
echo "59 03 * * * root /usr/local/bin/CCcam.x86" >> /etc/crontab
echo "*/5 * * * * root /var/script/CCcamCheck.sh" >> /etc/crontab
echo "03 04 * * 6 root /var/script/LogCleanUp.sh >> /var/cccamlog/CleanUp.log" >> /etc/crontab

apt-get update
apt-get install openssh-server
apt-get install proftpd  
apt-get install apache2 
apt-get install php5 


reboot




