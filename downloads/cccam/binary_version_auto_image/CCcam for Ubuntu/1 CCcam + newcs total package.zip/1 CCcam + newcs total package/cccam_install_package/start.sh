#!/bin/bash
#Script to start CCcam & newcs
#Script is written by Youknowhoo.
echo "starting NewCS server"
/usr/local/bin/newcs.i686 -C /var/etc/newcs.xml
sleep 5
echo "Starting CCcam"
/usr/local/bin/CCcam.x86
