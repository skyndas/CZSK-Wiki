#!/bin/sh
#Automated Installation script
#Purpose: Installing CCcam on a bare Ubuntu system.
#Written by: Youknowhoo
#
#Requirements: Ubuntu 8.04.1 / 8.04.3 new is 10.04 LTS
#            Installation Package.
#put the cccam_install_package in /tmp
#put this script in /tmp then chmod 755 this script

OWNER=
echo "Installation script for automated CCcam installation"
sleep 2
chown $OWNER /tmp/cccam_install_package
sleep 2
if [ ! -e  /tmp/cccam_install_package ] ; then
echo "WARNING !!!!!!!"
echo "Install package is not in tmp directory"
echo "please check if its there"
fi
echo "make directorys and show them to the owner"
sleep 2

mkdir /var/etc
chown $OWNER /var/etc

mkdir /var/keys
chown $OWNER /var/keys
      
mkdir /var/script
chown $OWNER /var/script

mkdir /var/config
chown $OWNER /var/config
	
mkdir /var/backup
chown $OWNER /var/backup
	
mkdir /var/cccamlog
chown $OWNER /var/cccamlog
     
chown $OWNER /usr/local/bin
sleep 2
echo "move the CCcam.x86 to his folder"
mv /tmp/cccam_install_package/CCcam.x86 /usr/local/bin
chmod 755 /usr/local/bin/CCcam.x86
sleep 2
echo "place the newcs.i686 in /usr/local/bin "
mv /tmp/cccam_install_package/newcs.i686 /usr/local/bin
sleep 2
echo "chmod the NewCS"
chmod 755 /usr/local/bin/newcs.i686
sleep 2
echo "move the scripts to /var/script"
mv /tmp/cccam_install_package/*.sh /var/script
echo "chmod 755 the scripts"
sleep 2
chmod 755 /var/script/configupdate.sh
chmod 755 /var/script/LogCleanUp.sh
chmod 755 /var/script/CCcamCheck.sh
chmod 755 /var/script/keyupdater.sh
chmod 755 /var/script/start.sh
chmod 755 /var/script/stop.sh
echo "make rc.local for autostart at boot"
chown $OWNER /etc/rc.local
rm /etc/rc.local
sleep 2
mv /tmp/cccam_install_package/rc.local /etc/rc.local
mv /tmp/cccam_install_package/CCcam.channelinfo /var/etc
mv /tmp/cccam_install_package/CCcam.providers /var/etc
mv /tmp/cccam_install_package/CCcam.prio /var/etc
mv /tmp/cccam_install_package/CCcam.cfg /var/etc
mv /tmp/cccam_install_package/newcs.xml /var/etc
sleep 1
chmod 755 /etc/rc.local
sleep 1
chown root /etc/rc.local
sleep 2
echo "making crontabs in /etc/crontab, remember no crontab -e!!!!"
sleep 3
echo "56 03 * * * root /var/script/stop.sh" >> /etc/crontab
echo "57 03 * * * root /var/script/configupdate.sh >> /var/cccamlog/configupdate.log" >> /etc/crontab
echo "58 03 * * * root /var/script/keyupdater.sh" >> /etc/crontab
echo "59 03 * * * root /var/script/start.sh" >> /etc/crontab
echo "*/5 * * * * root /var/script/CCcamCheck.sh" >> /etc/crontab
echo "03 04 * * 6 root /var/script/LogCleanUp.sh >> /var/cccamlog/CleanUp.log" >> /etc/crontab
sleep 2
echo "installing the software what the server needs"
sleep 2
apt-get update
sleep 4
apt-get install openssh-server
sleep 2
apt-get install proftpd  
sleep 2
apt-get install apache2
sleep 2 
apt-get install php5 
sleep 2
echo "the server is ready for restart"
sleep 2
echo "caution!! the newcs needs a card to run otherwise it will not connect with CCcam!!!"
sleep 8
echo "cowntdown to restart"
sleep 1
echo "3"
sleep 1
echo "2"
sleep 1
echo "1"
echo "rebooting now see you in a minute"

reboot




