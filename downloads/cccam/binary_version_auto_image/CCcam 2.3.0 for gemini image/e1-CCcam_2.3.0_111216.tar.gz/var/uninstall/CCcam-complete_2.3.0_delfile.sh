#!/bin/sh
# Name: CCcam-complete_2.3.0_111216.tar.gz
# Version: 2.3.0
# Type: Cam

kill `pidof newcs_1.67 oscam_1.00 `
killall -9 newcs_1.67 oscam_1.00 CCcam_2.3.0 2>/dev/null
sleep 2
remove_tmp

rm -rf /var/bin/CCcam_2.3.0
rm -rf /var/script/CCcam_2.3.0_cam.sh
rm -rf /var/script/CCcam_2.3.0_newcs_1.67_cam.sh
rm -rf /var/script/CCcam_2.3.0_oscam_1.00_cam.sh
rm -rf /var/uninstall/CCcam_2.3.0-newcs_1.67-script_delfile.sh
rm -rf /var/uninstall/CCcam_2.3.0-oscam_1.00-script_delfile.sh
rm -rf /var/uninstall/CCcam-complete_2.3.0_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
