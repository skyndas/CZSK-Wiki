#!/bin/sh
# Name: newcamd_6.10b_110128.tar.gz
# Version: 6.10b
# Type: Cam

kill `cat /tmp/newcamd.pid 2>/dev/null` 2>/dev/null
killall -9 cardserver_6.10b spider_6.10b betad_6.10b newcamd_6.10b 2>/dev/null

rm -rf /var/bin/betad_6.10b
rm -rf /var/bin/cardserver_6.10b
rm -rf /var/bin/newcamd_6.10b
rm -rf /var/bin/spider_6.10b
rm -rf /var/script/newcamd_6.10b_betad_cam.sh
rm -rf /var/script/newcamd_6.10b_cardserver_cam.sh
rm -rf /var/script/newcamd_6.10b_spider_cam.sh
rm -rf /var/uninstall/newcamd_6.10b_betad_delfile.sh
rm -rf /var/uninstall/newcamd_6.10b_cardserver_delfile.sh
rm -rf /var/uninstall/newcamd_6.10b_complete_delfile.sh
rm -rf /var/uninstall/newcamd_6.10b_spider_delfile.sh
rm -rf /var/lib/libcamdio.so.0

if grep -qs 7020 /proc/bus/dreambox ; then
  rm -rf /usr/lib/libcamdio.so.0
fi

exit 0

