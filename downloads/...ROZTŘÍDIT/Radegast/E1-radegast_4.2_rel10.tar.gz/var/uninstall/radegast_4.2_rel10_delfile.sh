#!/bin/sh
# Name: radegast_4.2_rel10_110128.tar.gz
# Version: 4.2_rel10
# Type: Cam

killall -9 camd rdgd 2>/dev/null

rm -rf /var/bin/camd.rdgd
rm -rf /var/bin/con-webmin
rm -rf /var/bin/dem
rm -rf /var/bin/rdgd
rm -rf /var/script/radegast_4.2_rel10_cam.sh
rm -rf /var/uninstall/radegast_4.2_rel10_delfile.sh

exit 0

