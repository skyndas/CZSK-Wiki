#include <sys/un.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

#if HAVE_DVB_API_VERSION < 3
#include <ost/dmx.h>
#define DEMUX_DEVICE "/dev/dvb/card0/demux0"
#else
#include <linux/dvb/dmx.h>
#define DEMUX_DEVICE "/dev/dvb/adapter0/demux0"
#define dmxSctFilterParams dmx_sct_filter_params
#endif

int debug=0;
int hexdumps=0;
#define dprintf if (debug) printf
#define hprintf if (hexdumps) printf

unsigned char caid_count = 0;
unsigned short caid[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

typedef struct pat_entry_s
{
	unsigned short program_number;
	unsigned short reserved : 3;
	unsigned short pmt_pid : 13;
}pat_entry_t;

char RadegastServer[32]="";
char camdNG[32]="";
char pmt[32]="";
char CamdSocket[32]="";

void ReadConf()
{
	FILE *fd_conf;
	char *ptr;
	char line_buffer[256];
	if (!(fd_conf = fopen("/var/etc/radegaststarter.cfg", "r")))
	{
		printf("[radegaststarter] radegaststarter.cfg not found on /var/etc/\n");
		exit(0);
	}else
	{
		printf("[radegaststarter] Loading config file /var/etc/radegaststarter.cfg\n");
		while(fgets(line_buffer, sizeof(line_buffer), fd_conf))
		{
			if ( *line_buffer == '#' )	continue;
			if((ptr = strstr(line_buffer, "SERVER=")))
			{
				sscanf(ptr + 7, "%s", &RadegastServer[0]);
			}else if((ptr = strstr(line_buffer, "CLIENT=")))
			{
				sscanf(ptr + 7, "%s", &camdNG[0]);
			}else if((ptr = strstr(line_buffer, "SOCKET=")))
			{
				sscanf(ptr + 7, "%s", &CamdSocket[0]);
			}else if((ptr = strstr(line_buffer, "PMT=")))
			{
				sscanf(ptr + 4, "%s", &pmt[0]);
			}
		}
		fclose(fd_conf);
	return;
	}
}

void write_pmt_tmp(unsigned char * buffer ,int len)
{
	FILE * fd;
	fd=fopen(pmt,"wb");
	fwrite(buffer,len,1,fd);
	fclose(fd);
}

int find_pmt_in_pat(unsigned char * buffer,int len,int prognum)
{
	pat_entry_t * pat_entry;
	short section_len;
	int pats,i;
	if (len <1)
	{
		perror ("[radegaststarter] pat parser: pat len is 0 cannot parse\n");
		return -1;
	}
	if (buffer[0]==0)
	{
		section_len=(buffer[1]&0xF)<<8|buffer[2];
		dprintf("section_len -> %x\n",section_len );
		pats =(section_len-4-5)/sizeof(pat_entry_t);
		dprintf("pats -> %d\n",pats );
		for (i=0;i<pats;i++)
		{
			pat_entry=(void*)buffer+8+(sizeof(pat_entry_t)*i);
			hprintf("prgnum %xpid %x\n",pat_entry->program_number,pat_entry->pmt_pid);
			if (prognum==pat_entry->program_number)
				return pat_entry->pmt_pid;
		}
	} else {
		perror ("[radegaststarter] pat parser: the pat is not a pat , table id is not 0\n");
	}
	return -1;
}

int read_from_dmx(int pid,int * len,unsigned char * buffer) {
	int fd,r,i;
	r=*len;
	printf("[radegaststarter] read_from_dmx with pid %x\n",pid);
	if ((fd = open(DEMUX_DEVICE, O_RDONLY)) < 0)
	{
		printf("[radegaststarter] Error open demux device\n");
		return -1;
	}
	struct dmxSctFilterParams flt;
	memset(&flt.filter.filter, 0, DMX_FILTER_SIZE);
	memset(&flt.filter.mask, 0, DMX_FILTER_SIZE);
	flt.pid=pid;
	flt.filter.filter[0]=0;
	flt.filter.mask[0]=0x00;
	flt.timeout=0;
	flt.flags= DMX_IMMEDIATE_START;
	ioctl (fd, DMX_SET_BUFFER_SIZE, 2 * 4096);
	if (ioctl(fd, DMX_SET_FILTER, &flt)<0)
	{
		perror("[radegaststarter] DMX_SET_FILTER");
		return 1;
	}
	if ((r=read(fd, buffer, r))<=0)
	{
		perror("[radegaststarter] read");
		return 1;
	}
	hprintf("\r\n----------------------------------\r\n");
	for (i=0;i<r;i++){
		hprintf("%2.2X ",buffer[i]);
	}
	hprintf("\r\n----------------------------------\r\n");

	close(fd);
	*len = r;
	return 0;
}

unsigned char get_length_field_size (unsigned char * buffer)
{
	if (!(buffer[0] & 0x80))
		return 1;
	else
	{
		if (buffer[0] &0x80)
			return (buffer[0] & 0x7F)+1;
	}
	return 0;
}

unsigned int parse_length_field (unsigned char * buffer)
{
	unsigned char size_indicator = (buffer[0] >> 7) & 0x01;
	unsigned int length_value = 0;
	if (size_indicator == 0)
	{
		length_value = buffer[0] & 0x7F;
	}
	else if (size_indicator == 1)
	{
		unsigned char length_field_size = buffer[0] & 0x7F;
		unsigned int i;

		for (i = 0; i < length_field_size; i++)
		{
			length_value = (length_value << 8) | buffer[i + 1];
		}
	}
	return length_value;
}

int parse_ca_pmt (const unsigned char * buffer, const unsigned int length)
{
	int len,pmt_pid;
	unsigned char dmxbuffer[1024];
	int ca_pmt_list_management = buffer[0];
	int program_number = (buffer[1] << 8) | buffer[2];
	int program_info_length = ((buffer[4] & 0x0F) << 8) | buffer[5];
	dprintf("[radegaststarter] ca_pmt_list_management %d\n",ca_pmt_list_management);
	dprintf("[radegaststarter] program_number %4.4x\n",program_number);
	dprintf("[radegaststarter] program_info_length %d\n",program_info_length);
	len=1000;
	read_from_dmx(0,&len,dmxbuffer);
	dprintf ("[radegaststarter] Readed %d bytes from demux\n",len);
	pmt_pid = find_pmt_in_pat(dmxbuffer,len,program_number);
	if (pmt_pid ==-1)
		perror("[radegaststarter] error fetching for pmt pid\n");
	else
		dprintf("[radegaststarter] Pmt Pid is %x\n",pmt_pid);

	len=1000;
	read_from_dmx(pmt_pid,&len,dmxbuffer);
	write_pmt_tmp(dmxbuffer,len);
	printf ("[radegaststarter] Readed %d bytes from demuxand wrote them to %s\n",len,pmt);
	return 0;
}

void handlesockmsg (unsigned char * buffer, ssize_t len, int connfd)
{
	int i;
	dprintf ("[radegaststarter] Buffer Received on %s: got %zd bytes\r\n",CamdSocket,len);
	for (i=0;i<len;i++)
	{
		hprintf ("%2.2X " , buffer[i]);
	}
	hprintf ("\r\n------------------------------------\r\n");
	switch (buffer[0])
	{
		case 0x9F:
		{
			unsigned int length = parse_length_field(buffer + 3);
 // resource manager, application info, ca support
			if (buffer[1] == 0x80)
			{
// ca_info_enq
				if (buffer[2] == 0x30)
				{
					unsigned char reply[4 + (caid_count << 1)];
					if (length != 0)
					{
						printf("[radegaststarter] warning: invalid length for ca_info_enq\n");
					}
 // ca_info
					reply[0] = 0x9F;
					reply[1] = 0x80;
					reply[2] = 0x31;
					reply[3] = caid_count << 1;
					for (i = 0; i < caid_count; i++)
					{
						reply[(i << 1) + 4] = caid[i] >> 8;
						reply[(i << 1) + 5] = caid[i];
					}
					if (write(connfd, reply, sizeof(reply)) < 0)
					{
						printf("ERR [camd] write");
					}
				}
				else if (buffer[2] == 0x32)// ca_pmt
				{
					if ((3 + get_length_field_size( buffer + 3) + length) == len)
					{
						parse_ca_pmt(buffer + 3 + get_length_field_size(buffer + 3), length);
					}
					else
					{
						printf("[radegaststarter] ca_pmt: invalid length-> %d ls ->%d \n",length,get_length_field_size(buffer + 3));
					}
				}
				else
				{
					printf("[radegaststarter] unknown resource manager, application info or ca support command\n");
				}
			}
			else
			{
				printf("[radegaststarter] unknown apdu tag\n");
			}
			break;
		}
		default:
			printf("[radegaststarter] unknown socket command: %02x\n", buffer[0]);
		break;
	}
}

int StartCamdNG()
{
	printf("[radegaststarter] start %s for Radegast\n",camdNG);
	static int lastpid=-1;
	if (lastpid != -1)
	{
		kill(lastpid, SIGKILL);
		waitpid(lastpid, 0, 0);
		lastpid=-1;
	}
	switch (lastpid=fork())
	{
        case -1:
                printf("[%s] fork",camdNG);
                break;
		case 0:
             	if (execlp(camdNG, "[camdNG]", NULL) < 0)
                {
                	printf("[%s] execlp",camdNG);
                        exit(0);
                }
                break;
	}
	return 0;
}

int main (int argc, char ** argv)
{
	printf("[radegaststarter] Enigma Radegast Starter v1.0 (2008) ripper\n");
	ReadConf();
	unlink(CamdSocket);
	system(RadegastServer);
	int listenfd;
	int connfd;
	struct sockaddr_un servaddr;
	int clilen;
	unsigned char msgbuffer[1024];
	memset(&servaddr, 0, sizeof(struct sockaddr_un));
	servaddr.sun_family = AF_UNIX;
	strcpy(servaddr.sun_path, CamdSocket);
	clilen = sizeof(servaddr.sun_family) + strlen(servaddr.sun_path);
	unlink(CamdSocket);
	if ((listenfd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0)
	{
		perror("[radegaststarter] socket");
		return -1;
	}
	if (bind(listenfd, (struct sockaddr *) &servaddr, clilen) < 0)
	{
		perror("[radegaststarter] bind");
		return -1;
	}
	if (listen(listenfd, 5) < 0)
	{
		perror("[radegaststarter] listen");
		return -1;
	}
	printf("[radegaststarter] listening to %s,starting mainloop\n",CamdSocket);
	while (1)
	{
		connfd = accept(listenfd, (struct sockaddr *) &servaddr, (socklen_t *) &clilen);
		ssize_t length = read(connfd, msgbuffer, sizeof(msgbuffer));
		switch (length)
		{
			case -1:
				perror("[radegaststarter] read");
			break;
			case 0 ... 3:
				printf("[radegaststarter] too short message received\n");
				handlesockmsg(msgbuffer, length, connfd);
				StartCamdNG();
			break;
			default:
				if ((msgbuffer[0] == 0x9F) && ((msgbuffer[1] >> 7) == 0x01) && ((msgbuffer[2] >> 7) == 0x00))
				{
					handlesockmsg(msgbuffer, length, connfd);
					StartCamdNG();		
				}
				else
				{
					unsigned int i;
					printf("[radegaststarter] invalid message received:\n");
					for (i = 0; i < length; i++)
					{
						printf("%02x ", msgbuffer[i]);
					}
					printf("\n");
				}
				break;
		}
		close(connfd);
	}
	return 0;
}
