#!/bin/sh
# CAMD_NAME: scam-complete_3.59_100219.tar.gz
# CAMD_VERSION: 3.59
# Type: Cam

kill `pidof scam_3.59`
sleep 2
remove_tmp

rm -rf /usr/bin/scam_3.59
rm -rf /usr/script/scam_3.59_cam.sh
rm -rf /usr/uninstall/scam-complete_3.59_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
