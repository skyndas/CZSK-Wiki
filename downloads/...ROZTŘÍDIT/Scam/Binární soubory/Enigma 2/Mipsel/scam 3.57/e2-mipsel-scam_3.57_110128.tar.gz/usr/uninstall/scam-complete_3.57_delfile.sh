#!/bin/sh
# CAMD_NAME: scam-complete_3.57_110128.tar.gz
# CAMD_VERSION: 3.57
# Type: Cam

kill `pidof scam_3.57`
sleep 2
remove_tmp

rm -rf /usr/bin/scam_3.57
rm -rf /usr/script/scam_3.57_cam.sh
rm -rf /usr/uninstall/scam-complete_3.57_delfile.sh

exit 0

