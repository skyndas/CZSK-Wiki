#!/bin/sh
# CAMD_NAME: scam-complete_3.58_110128.tar.gz
# CAMD_VERSION: 3.58
# Type: Cam

killall -9 scam_3.58 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/cs_clnt
rm -rf /usr/bin/cs_srv
rm -rf /usr/bin/scamecminfo
rm -rf /usr/bin/scam.ppc_3.58
rm -rf /usr/script/scam_3.58_cam.sh
rm -rf /usr/uninstall/scam-complete_3.58_delfile.sh

exit 0

