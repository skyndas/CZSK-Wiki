#!/bin/sh
# Name: scam-complete_3.59_110128.tar.gz
# Version: 3.59
# Type: Cam

kill `pidof scam_3.59`

rm -rf /usr/bin/scam_3.59
rm -rf /usr/script/scam_3.59_cam.sh
rm -rf /usr/uninstall/scam-complete_3.59_delfile.sh

exit 0

