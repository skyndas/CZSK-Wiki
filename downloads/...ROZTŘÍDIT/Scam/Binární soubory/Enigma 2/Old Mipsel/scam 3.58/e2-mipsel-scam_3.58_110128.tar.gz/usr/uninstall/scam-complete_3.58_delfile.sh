#!/bin/sh
# Name: scam-complete_3.58_110128.tar.gz
# Version: 3.58
# Type: Cam

kill `pidof scam_3.58`

rm -rf /usr/bin/scam_3.58
rm -rf /usr/script/scam_3.58_cam.sh
rm -rf /usr/uninstall/scam-complete_3.58_delfile.sh

exit 0

