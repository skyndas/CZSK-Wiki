#!/bin/sh
# Name: scam-complete_3.58_110128.tar.gz
# Version: 3.58
# Type: Cam

killall -9 cs_clnt cs_srv  scam_3.58 2>/dev/null

rm -rf /var/bin/cs_clnt
rm -rf /var/bin/cs_srv
rm -rf /var/bin/scam_3.58
rm -rf /var/bin/scamecminfo
rm -rf /var/script/scam_3.58_cam.sh
rm -rf /var/script/scam_3.58-ronald-cs_cam.sh
rm -rf /var/uninstall/scam_3.58-ronald-cs-script_delfile.sh
rm -rf /var/uninstall/scam-complete_3.58_delfile.sh

exit 0

