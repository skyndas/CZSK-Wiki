#!/bin/sh
# Name: scam_3.58-ronald-cs-script_110128.tar.gz
# Version: 3.58
# Type: Cam

killall -9 cs_clnt cs_srv scamecminfo scam_3.58 2>/dev/null

rm -rf /var/script/scam_3.58-ronald-cs_cam.sh
rm -rf /var/uninstall/scam_3.58-ronald-cs-script_delfile.sh

exit 0

