#!/bin/sh
# Name: Scam-Config_110128.tar.gz
# Version: 
# Type: Cam-Config

rm -rf /etc/uninstall/Scam-Config_delfile.sh
rm -rf /etc/scam/config
rm -rf /gemini3_mipsel_scam-3.5-r0/gp-conf-scam_3.5-r0_mipsel.ipk
rm -rf /usr/uninstall/Scam-Config_delfile.sh
rm -rf /usr/keys/sc_cryptoworks
rm -rf /usr/keys/sc_nagravision
rm -rf /usr/keys/sc_videoguard

exit 0

