#!/bin/sh
# Name: Scam-Config_090512.tar.gz
# Version: 
# Type: cam-config

rm -rf /usr/scam/config
rm -rf /usr/uninstall/Scam-Config_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
