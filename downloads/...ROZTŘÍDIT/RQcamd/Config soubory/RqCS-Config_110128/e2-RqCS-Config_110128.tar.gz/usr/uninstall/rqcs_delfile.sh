#!/bin/sh
# Name: RqCS-Config_110128.tar.gz
# Version: 
# Type: cam-config

rm -rf /usr/uninstall/rqcs_delfile.sh
rm -rf /usr/keys/rqcs.conf

exit 0

