#!/bin/sh
# Name: Rq-Echo-Client-Config_110128.tar.gz
# Version: 
# Type: cam-config

rm -rf /usr/uninstall/rq-echo-client_delfile.sh
rm -rf /usr/keys/rq-echo-client.conf

exit 0

