#!/bin/sh
# Name: RqCamd-Config_110128.tar.gz
# Version: 
# Type: cam-config

rm -rf /usr/uninstall/rqcamd_delfile.sh
rm -rf /usr/keys/rqcamd.conf

exit 0

