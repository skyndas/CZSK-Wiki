#!/bin/sh
# CAMD_NAME: rqcs_110128.tar.gz
# CAMD_VERSION: 1.10
# Type: Cam

killall -9 rqcs 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/rqcs
rm -rf /usr/script/rqcs_cam.sh
rm -rf /usr/uninstall/rqcs_delfile.sh

exit 0

