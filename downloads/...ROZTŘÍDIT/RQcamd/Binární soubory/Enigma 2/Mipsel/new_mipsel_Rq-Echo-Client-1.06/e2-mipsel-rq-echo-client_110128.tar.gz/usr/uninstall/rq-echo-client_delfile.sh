#!/bin/sh
# CAMD_NAME: rq-echo-client_110128.tar.gz
# CAMD_VERSION: 1.06
# Type: Cam

killall -9 rq-echo-client 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/rq-echo-client
rm -rf /usr/script/rq-echo-client_cam.sh
rm -rf /usr/uninstall/rq-echo-client_delfile.sh

exit 0

