#!/bin/sh
# CAMD_NAME: rqcamd_110128.tar.gz
# CAMD_VERSION: 1.31
# Type: Cam

killall -9 rqcamd 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/rqcamd
rm -rf /usr/script/rqcamd_cam.sh
rm -rf /usr/uninstall/rqcamd_delfile.sh

exit 0

