#!/bin/sh
# Name: rq-echo-client_110128.tar.gz
# Version: 1.06
# Type: Cam

killall -9 rq-echo-client 2>/dev/null

rm -rf /var/bin/rq-echo-client
rm -rf /var/script/rq-echo-client_cam.sh
rm -rf /var/uninstall/rq-echo-client_delfile.sh

exit 0

