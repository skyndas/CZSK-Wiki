#!/bin/sh
# Name: rqcs_110128.tar.gz
# Version: 1.10
# Type: Cam

killall -9 rqcs 2>/dev/null

rm -rf /var/bin/rqcs
rm -rf /var/script/rqcs_cam.sh
rm -rf /var/uninstall/rqcs_delfile.sh

exit 0

