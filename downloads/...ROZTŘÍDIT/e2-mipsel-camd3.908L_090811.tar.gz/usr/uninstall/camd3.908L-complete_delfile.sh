#!/bin/sh
# CAMD_NAME: camd3.908L-complete_090811.tar.gz
# CAMD_VERSION: .908L
# Type: Cam

killall -9 mpcs_1.06_pr3 camd3.908L 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/camd3.908L
rm -rf /usr/bin/pcamd
rm -rf /usr/script/camd3.908L_cam.sh
rm -rf /usr/script/camd3.908L_mpcs_1.06_pr3_cam.sh
rm -rf /usr/uninstall/camd3.908L-complete_delfile.sh
rm -rf /usr/uninstall/camd3.908L-mpcs_1.06_pr3-script_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
