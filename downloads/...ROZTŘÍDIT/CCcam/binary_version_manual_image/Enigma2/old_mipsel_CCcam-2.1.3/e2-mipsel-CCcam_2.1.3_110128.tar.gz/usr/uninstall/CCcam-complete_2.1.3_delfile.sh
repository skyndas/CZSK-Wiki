#!/bin/sh
# Name: CCcam-complete_2.1.3_110128.tar.gz
# Version: 2.1.3
# Type: Cam

kill `pidof oscam_1.00 newcs_1.67 CCcam_2.1.3`
killall -9 oscam_1.00 newcs_1.67 CCcam_2.1.3 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/CCcam_2.1.3
rm -rf /usr/script/CCcam_2.1.3_cam.sh
rm -rf /usr/script/CCcam_2.1.3_newcs_1.67_cam.sh
rm -rf /usr/script/CCcam_2.1.3_oscam_1.00_cam.sh
rm -rf /usr/uninstall/CCcam_2.1.3-newcs_1.67-script_delfile.sh
rm -rf /usr/uninstall/CCcam_2.1.3-oscam_1.00-script_delfile.sh
rm -rf /usr/uninstall/CCcam-complete_2.1.3_delfile.sh

exit 0

