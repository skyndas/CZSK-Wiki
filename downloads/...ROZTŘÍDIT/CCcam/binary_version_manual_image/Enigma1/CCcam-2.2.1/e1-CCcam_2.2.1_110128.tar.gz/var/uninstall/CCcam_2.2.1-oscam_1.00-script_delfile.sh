#!/bin/sh
# Name: CCcam_2.2.1-oscam_1.00-script_110128.tar.gz
# Version: 2.2.1
# Type: Cam

kill `pidof oscam_1.00 `
killall -9 oscam_1.00 CCcam_2.2.1 2>/dev/null
sleep 2
remove_tmp

rm -rf /var/script/CCcam_2.2.1_oscam_1.00_cam.sh
rm -rf /var/uninstall/CCcam_2.2.1-oscam_1.00-script_delfile.sh

exit 0

