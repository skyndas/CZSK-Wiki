#!/bin/sh
# Name: CCcam-complete_2.0.9_080522.tar.gz
# Version: 2.0.9
# Type: Cam

killall -9 newcs_1.60 CCcam_2.0.9 2>/dev/null
sleep 2
remove_tmp

rm -rf /var/bin/CCcam_2.0.9
rm -rf /var/script/CCcam_2.0.9_cam.sh
rm -rf /var/script/CCcam_2.0.9_newcs_1.60_cam.sh
rm -rf /var/uninstall/CCcam_2.0.9-newcs_1.60-script_delfile.sh
rm -rf /var/uninstall/CCcam-complete_2.0.9_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
