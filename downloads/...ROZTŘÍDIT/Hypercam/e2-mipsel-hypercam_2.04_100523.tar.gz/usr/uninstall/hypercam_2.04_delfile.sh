#!/bin/sh
# CAMD_NAME: hypercam_2.04_100523.tar.gz
# CAMD_VERSION: 2.04
# Type: Cam

killall -9 hypercam_2.04 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/hypercam_2.04
rm -rf /usr/script/hypercam_2.04_cam.sh
rm -rf /usr/uninstall/hypercam_2.04_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
