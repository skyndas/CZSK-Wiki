#!/bin/sh
# Name: hypercam_2.11_110128.tar.gz
# Version: 2.11
# Type: Cam

killall -9 hypercam_2.11 2>/dev/null

rm -rf /var/bin/hypercam_2.11
rm -rf /var/script/hypercam_2.11_cam.sh
rm -rf /var/uninstall/hypercam-Complete_2.11_delfile.sh

exit 0

