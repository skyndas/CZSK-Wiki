#!/bin/sh
# CAMD_NAME: hypercam_2.11_110128.tar.gz
# CAMD_VERSION: 2.11
# Type: Cam

killall -9 hypercam_2.11 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/hypercam_2.11
rm -rf /usr/script/hypercam_2.11_cam.sh
rm -rf /usr/uninstall/hypercam_2.11_delfile.sh

exit 0

