#!/bin/sh
# Name: Hypercam-Config_100418.tar.gz
# Version: 
# Type: cam-config

rm -rf /usr/bin/hypercam.cfg
rm -rf /usr/uninstall/Hypercam-Config_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
