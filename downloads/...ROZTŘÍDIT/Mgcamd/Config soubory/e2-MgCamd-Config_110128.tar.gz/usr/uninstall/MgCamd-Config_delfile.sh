#!/bin/sh
# Name: MgCamd-Config_110128.tar.gz
# Version: 
# Type: Cam-Config

rm -rf /etc/tuxbox/config/newcamd.conf
rm -rf /gemini3_mipsel_mgcamd-1.0-r0/gp-conf-mgcamd_1.0-r0_mipsel.ipk
rm -rf /usr/uninstall/MgCamd-Config_delfile.sh
rm -rf /usr/keys/cccamd.list
rm -rf /usr/keys/ignore.list
rm -rf /usr/keys/mg_cfg
rm -rf /usr/keys/newcamd.list
rm -rf /usr/keys/peer.cfg
rm -rf /usr/keys/priority.list
rm -rf /usr/keys/replace.list

exit 0

