#!/bin/sh
# Name: mgcamd_1.35a_ronald-cs-script_100126.tar.gz
# Version: 1.35a
# Type: Cam

killall -9 cs_clnt cs_srv mgcamd_1.35a 2>/dev/null

rm -rf /var/script/mgcamd_1.35a-ronald-cs_cam.sh
rm -rf /var/uninstall/mgcamd_1.35a_ronald-cs-script_DELFILE1.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
