#!/bin/sh
# Name: mgcamd_1.35a_newcs_1.67-script_110128.tar.gz
# Version: 1.35a
# Type: Cam

killall -9 newcs_1.67 mgcamd_1.35a 2>/dev/null

rm -rf /var/script/mgcamd_1.35a_newcs_1.67_cam.sh
rm -rf /var/uninstall/mgcamd_1.35a_newcs_1.67-script_delfile.sh

exit 0

