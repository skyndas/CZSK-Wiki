#!/bin/sh
# Name: mgcamd_1.31_ronald-cs-script_081031.tar.gz
# Version: 1.31
# Type: Cam

killall -9 cs_clnt cs_srv mgcamd_1.31 2>/dev/null

rm -rf /var/script/mgcamd_1.31-ronald-cs_cam.sh
rm -rf /var/uninstall/mgcamd_1.31_ronald-cs-script_DELFILE1.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
