#!/bin/sh
# Name: mgcamd_1.31_newcs_1.62-script_081031.tar.gz
# Version: 1.31
# Type: Cam

killall -9 newcs_1.62 mgcamd_1.31 2>/dev/null

rm -rf /var/script/mgcamd_1.31_newcs_1.62_cam.sh
rm -rf /var/uninstall/mgcamd_1.31_newcs_1.62-script_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
