#!/bin/sh
# Name: mgcamd-complete_1.31_081031.tar.gz
# Version: 1.31
# Type: Cam

killall -9 cs_clnt cs_srv newcs_1.62 mgcamd_1.31 2>/dev/null

rm -rf /var/bin/mgcamd_1.31
rm -rf /var/script/mgcamd_1.31_cam.sh
rm -rf /var/script/mgcamd_1.31_newcs_1.62_cam.sh
rm -rf /var/script/mgcamd_1.31-ronald-cs_cam.sh
rm -rf /var/uninstall/mgcamd_1.31_newcs_1.62-script_delfile.sh
rm -rf /var/uninstall/mgcamd_1.31_ronald-cs-script_delfile.sh
rm -rf /var/uninstall/mgcamd-complete_1.31_delfile.sh

exit 0

######################################
####### Powered by Gemini Team #######
## http://www.i-have-a-dreambox.com ##
######################################
