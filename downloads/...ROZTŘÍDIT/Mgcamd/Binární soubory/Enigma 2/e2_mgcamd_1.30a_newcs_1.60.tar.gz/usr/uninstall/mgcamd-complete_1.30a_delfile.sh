#!/bin/sh
# Name: mgcamd-complete_1.30a_delfile.sh
# Version: 1.30a
# Type: Cam

killall -9   newcs_1.60 mgcamd_1.30a 2>/dev/null

rm -rf /usr/bin/mgcamd_1.30a
rm -rf /usr/bin/newcs_1.60
rm -rf /usr/script/mgcamd_1.30a_cam.sh
rm -rf /usr/script/mgcamd_1.30a_newcs_1.60_cam.sh
rm -rf /usr/keys/mg_cfg
rm -rf /usr/keys/newcamd.list
rm -rf /usr/keys/ignore.list
rm -rf /usr/keys/priority.list
rm -rf /etc/tuxbox/config/newcs.xml
rm -rf /usr/uninstall/mgcamd-complete_1.30a_delfile.sh

exit 0