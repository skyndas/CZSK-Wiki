#!/bin/sh
# CAMD_NAME: mgcamd-complete_1.35a_110128.tar.gz
# CAMD_VERSION: 1.35a
# Type: Cam

killall -9 newcs_1.67 mgcamd_1.35a 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/mgcamd_1.35a
rm -rf /usr/script/mgcamd_1.35a_cam.sh
rm -rf /usr/script/mgcamd_1.35a_newcs_1.67_cam.sh
rm -rf /usr/script/mgcamd_1.35a_newcs_1.67_oscam_0.99.4_cam.sh
rm -rf /usr/uninstall/mgcamd_1.35a-newcs_1.67-oscam_0.99.4-script_delfile.sh
rm -rf /usr/uninstall/mgcamd_1.35a-newcs_1.67-script_delfile.sh
rm -rf /usr/uninstall/mgcamd-complete_1.35a_delfile.sh

exit 0

